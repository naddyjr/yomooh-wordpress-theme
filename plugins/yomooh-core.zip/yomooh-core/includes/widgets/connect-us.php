<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class Yomooh_Social_Connect_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct(
            'yomooh_social_connect',
            __('Yomooh Social Connect', 'yomooh-core'),
            array(
                'description' => __('Display social media connections with counters.', 'yomooh-core'),
                'customize_selective_refresh' => true,
            )
        );
    }

    public function widget($args, $instance) {
        $title = apply_filters('widget_title', empty($instance['title']) ? '' : $instance['title'], $instance, $this->id_base);
        
        $social_platforms = array(
            'facebook' => array('label' => 'Likes', 'icon' => 'fab fa-facebook-f'),
            'twitter' => array('label' => 'Followers', 'icon' => 'fab fa-twitter'),
            'telegram' => array('label' => 'Members', 'icon' => 'fab fa-telegram-plane'),
            'instagram' => array('label' => 'Followers', 'icon' => 'fab fa-instagram'),
            'youtube' => array('label' => 'Subscribers', 'icon' => 'fab fa-youtube'),
            'tiktok' => array('label' => 'Followers', 'icon' => 'fab fa-tiktok'),
            'pinterest' => array('label' => 'Followers', 'icon' => 'fab fa-pinterest-p'),
            'vkontakte' => array('label' => 'Followers', 'icon' => 'fab fa-vk'),
            'whatsapp' => array('label' => 'Members', 'icon' => 'fab fa-whatsapp'),
            'googlenews' => array('label' => 'Readers', 'icon' => 'fab fa-google'),
            'linkedin' => array('label' => 'Followers', 'icon' => 'fab fa-linkedin-in'),
            'medium' => array('label' => 'Followers', 'icon' => 'fab fa-medium-m'),
            'flipboard' => array('label' => 'Followers', 'icon' => 'fab fa-flipboard'),
            'twitch' => array('label' => 'Followers', 'icon' => 'fab fa-twitch'),
            'steam' => array('label' => 'Members', 'icon' => 'fab fa-steam'),
            'tumblr' => array('label' => 'Followers', 'icon' => 'fab fa-tumblr'),
            'discord' => array('label' => 'Members', 'icon' => 'fab fa-discord'),
            'soundcloud' => array('label' => 'Followers', 'icon' => 'fab fa-soundcloud'),
            'vimeo' => array('label' => 'Followers', 'icon' => 'fab fa-vimeo-v'),
            'dribbble' => array('label' => 'Followers', 'icon' => 'fab fa-dribbble'),
            'snapchat' => array('label' => 'Followers', 'icon' => 'fab fa-snapchat-ghost'),
            'spotify' => array('label' => 'Listeners', 'icon' => 'fab fa-spotify'),
            'truthsocial' => array('label' => 'Followers', 'icon' => 'fas fa-comment-alt'),
            'threads' => array('label' => 'Followers', 'icon' => 'fas fa-comments'),
            'rss' => array('label' => 'Readers', 'icon' => 'fas fa-rss')
        );

        echo $args['before_widget'];

        if ($title) {
            echo $args['before_title'] . esc_html($title) . $args['after_title'];
        }

        echo '<div class="yomooh-social-connect">';

        foreach ($social_platforms as $platform => $data) {
            $url = empty($instance[$platform.'_url']) ? '' : $instance[$platform.'_url'];
            $name = empty($instance[$platform.'_name']) ? '' : $instance[$platform.'_name'];
            $count = empty($instance[$platform.'_count']) ? '' : $instance[$platform.'_count'];
            
            if ($url) {
                echo '<a href="'.esc_url($url).'" class="social-connect-item '.esc_attr($platform).'" target="_blank" rel="noopener noreferrer">';
                echo '<div class="social-connect-icon"><i class="'.esc_attr($data['icon']).'"></i></div>';
                echo '<div class="social-connect-details">';
                echo '<div class="social-connect-action">'.esc_html($this->get_action_label($platform)).'</div>';
                if ($count) {
                    echo '<div class="social-connect-count">'.esc_html($this->format_count($count)).' '.esc_html($data['label']).'</div>';
                }
                echo '</div>';
                echo '</a>';
            }
        }

        echo '</div>';
        echo $args['after_widget'];
    }

    private function get_action_label($platform) {
        $actions = array(
            'facebook' => 'Like',
            'twitter' => 'Follow',
            'telegram' => 'Join',
            'instagram' => 'Follow',
            'youtube' => 'Subscribe',
            'tiktok' => 'Follow',
            'pinterest' => 'Follow',
            'vkontakte' => 'Follow',
            'whatsapp' => 'Join',
            'googlenews' => 'Read',
            'linkedin' => 'Follow',
            'medium' => 'Follow',
            'flipboard' => 'Follow',
            'twitch' => 'Follow',
            'steam' => 'Join',
            'tumblr' => 'Follow',
            'discord' => 'Join',
            'soundcloud' => 'Follow',
            'vimeo' => 'Follow',
            'dribbble' => 'Follow',
            'snapchat' => 'Add',
            'spotify' => 'Listen',
            'truthsocial' => 'Follow',
            'threads' => 'Follow',
            'rss' => 'Subscribe'
        );
        return $actions[$platform] ?? 'Follow';
    }

    private function format_count($count) {
        if (is_numeric($count)) {
            if ($count >= 1000000) {
                return round($count / 1000000, 1) . 'M';
            } elseif ($count >= 1000) {
                return round($count / 1000, 1) . 'K';
            }
        }
        return $count;
    }

    public function form($instance) {
        $title = !empty($instance['title']) ? $instance['title'] : '';
        
        $social_platforms = array(
            'facebook' => 'Facebook',
            'twitter' => 'X (Twitter)',
            'telegram' => 'Telegram',
            'instagram' => 'Instagram',
            'youtube' => 'YouTube',
            'tiktok' => 'TikTok',
            'pinterest' => 'Pinterest',
            'vkontakte' => 'VKontakte',
            'whatsapp' => 'WhatsApp',
            'googlenews' => 'Google News',
            'linkedin' => 'LinkedIn',
            'medium' => 'Medium',
            'flipboard' => 'Flipboard',
            'twitch' => 'Twitch',
            'steam' => 'Steam',
            'tumblr' => 'Tumblr',
            'discord' => 'Discord',
            'soundcloud' => 'SoundCloud',
            'vimeo' => 'Vimeo',
            'dribbble' => 'Dribbble',
            'snapchat' => 'Snapchat',
            'spotify' => 'Spotify',
            'truthsocial' => 'Truth Social',
            'threads' => 'Threads',
            'rss' => 'RSS'
        );
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:', 'yomooh-core'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" 
                   name="<?php echo $this->get_field_name('title'); ?>" type="text" 
                   value="<?php echo esc_attr($title); ?>" />
        </p>

        <?php foreach ($social_platforms as $slug => $name) : ?>
        <div class="social-platform-section" style="margin-bottom: 15px; padding: 10px; background: #f5f5f5;">
            <h4><?php echo esc_html($name); ?></h4>
            
            <p>
                <label for="<?php echo $this->get_field_id($slug.'_url'); ?>"><?php _e('URL:', 'yomooh-core'); ?></label>
                <input class="widefat" id="<?php echo $this->get_field_id($slug.'_url'); ?>" 
                       name="<?php echo $this->get_field_name($slug.'_url'); ?>" type="url" 
                       value="<?php echo esc_url(!empty($instance[$slug.'_url']) ? $instance[$slug.'_url'] : ''); ?>" />
            </p>
            
            <p>
                <label for="<?php echo $this->get_field_id($slug.'_name'); ?>"><?php _e('Page Name:', 'yomooh-core'); ?></label>
                <input class="widefat" id="<?php echo $this->get_field_id($slug.'_name'); ?>" 
                       name="<?php echo $this->get_field_name($slug.'_name'); ?>" type="text" 
                       value="<?php echo esc_attr(!empty($instance[$slug.'_name']) ? $instance[$slug.'_name'] : ''); ?>" />
            </p>
            
            <p>
                <label for="<?php echo $this->get_field_id($slug.'_count'); ?>"><?php _e('Count Value:', 'yomooh-core'); ?></label>
                <input class="widefat" id="<?php echo $this->get_field_id($slug.'_count'); ?>" 
                       name="<?php echo $this->get_field_name($slug.'_count'); ?>" type="text" 
                       value="<?php echo esc_attr(!empty($instance[$slug.'_count']) ? $instance[$slug.'_count'] : ''); ?>" />
            </p>
        </div>
        <?php endforeach; ?>
        <?php
    }

    public function update($new_instance, $old_instance) {
        $instance = array();
        $instance['title'] = sanitize_text_field($new_instance['title']);
        
        $social_platforms = array(
            'facebook', 'twitter', 'telegram', 'instagram', 'youtube', 'tiktok', 
            'pinterest', 'vkontakte', 'whatsapp', 'googlenews', 'linkedin', 
            'medium', 'flipboard', 'twitch', 'steam', 'tumblr', 'discord', 
            'soundcloud', 'vimeo', 'dribbble', 'snapchat', 'spotify', 
            'truthsocial', 'threads', 'rss'
        );
        
        foreach ($social_platforms as $platform) {
            $instance[$platform.'_url'] = esc_url_raw($new_instance[$platform.'_url']);
            $instance[$platform.'_name'] = sanitize_text_field($new_instance[$platform.'_name']);
            $instance[$platform.'_count'] = sanitize_text_field($new_instance[$platform.'_count']);
        }
        
        return $instance;
    }
}