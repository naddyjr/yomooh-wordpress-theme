<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Background;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

if (!defined('ABSPATH')) exit;

class Yomooh_Widget_Post_Listing extends Widget_Base {

    public function get_name() {
        return 'yomooh_post_listing';
    }

    public function get_title() {
        return __('Yomooh Post Listing', 'yomooh-core');
    }

    public function get_icon() {
        return 'eicon-post-list';
    }

    public function get_categories() {
        return ['yomooh-elements'];
    }

    protected function register_controls() {
        // Layout Section
        $this->start_controls_section(
            'section_layout',
            [
                'label' => __('Layout', 'yomooh-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_responsive_control(
            'columns',
            [
                'label' => __('Columns', 'yomooh-core'),
                'type' => Controls_Manager::SELECT,
                'default' => '1',
                'options' => [
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                ],
                'prefix_class' => 'elementor-grid%s-',
                'frontend_available' => true,
            ]
        );

        $this->add_responsive_control(
            'column_gap',
            [
                'label' => __('Column Gap', 'yomooh-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .yomooh-listpost-listing' => 'grid-column-gap: {{SIZE}}{{UNIT}}',
                    '{{WRAPPER}} .yomooh-listpost-listing' => 'column-gap: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'row_gap',
            [
                'label' => __('Row Gap', 'yomooh-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .yomooh-listpost-listing' => 'grid-row-gap: {{SIZE}}{{UNIT}}',
                    '{{WRAPPER}} .yomooh-listpost-listing' => 'row-gap: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_control(
            'column_border',
            [
                'label' => __('Column Border', 'yomooh-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'yomooh-core'),
                'label_off' => __('No', 'yomooh-core'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'bottom_border',
            [
                'label' => __('Bottom Border', 'yomooh-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'yomooh-core'),
                'label_off' => __('No', 'yomooh-core'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_responsive_control(
            'featured_image_spacing',
            [
                'label' => __('Featured Image Spacing', 'yomooh-core'),
                'description' => __('Input 1/2 value of the custom gap between the featured image and list post content (in px). The spacing will be 2x your input value.', 'yomooh-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .yomooh-listpost-item .yomooh-listpost-thumbnail img' => 'margin-bottom: calc(2 * {{SIZE}}{{UNIT}})',
                ],
            ]
        );

        $this->add_control(
            'centering_content',
            [
                'label' => __('Centering Content', 'yomooh-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'yomooh-core'),
                'label_off' => __('No', 'yomooh-core'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->end_controls_section();

        // Content Section - Query Settings
        $this->start_controls_section(
            'section_content',
            [
                'label' => __('Content', 'yomooh-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'post_type',
            [
                'label' => __('Post Type', 'yomooh-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'post',
                'options' => $this->get_post_types(),
            ]
        );

        $this->add_control(
            'post_format',
            [
                'label' => __('Post Format', 'yomooh-core'),
                'type' => Controls_Manager::SELECT,
                'default' => '',
                'options' => [
                    '' => __('All', 'yomooh-core'),
                    'standard' => __('Standard', 'yomooh-core'),
                    'video' => __('Video', 'yomooh-core'),
                    'audio' => __('Audio', 'yomooh-core'),
                    'gallery' => __('Gallery', 'yomooh-core'),
                ],
            ]
        );

        $this->add_control(
            'author_filter',
            [
                'label' => __('Author Filter', 'yomooh-core'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'multiple' => true,
                'options' => $this->get_authors(),
            ]
        );

        $this->add_control(
            'category_filter',
            [
                'label' => __('Category Filter', 'yomooh-core'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'multiple' => true,
                'options' => $this->get_post_categories(),
            ]
        );

        $this->add_control(
            'exclude_categories',
            [
                'label' => __('Exclude Category IDs', 'yomooh-core'),
                'type' => Controls_Manager::TEXT,
                'description' => __('Comma separated list of category IDs to exclude', 'yomooh-core'),
            ]
        );

        $this->add_control(
            'exclude_posts',
            [
                'label' => __('Exclude Post IDs', 'yomooh-core'),
                'type' => Controls_Manager::TEXT,
                'description' => __('Comma separated list of post IDs to exclude', 'yomooh-core'),
            ]
        );

        $this->add_control(
            'orderby',
            [
                'label' => __('Order By', 'yomooh-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'date',
                'options' => [
                    'date' => __('Date', 'yomooh-core'),
                    'title' => __('Title', 'yomooh-core'),
                    'rand' => __('Random', 'yomooh-core'),
                    'comment_count' => __('Comment Count', 'yomooh-core'),
                    'modified' => __('Modified', 'yomooh-core'),
                    'menu_order' => __('Menu Order', 'yomooh-core'),
                ],
            ]
        );

        $this->add_control(
            'order',
            [
                'label' => __('Order', 'yomooh-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'DESC',
                'options' => [
                    'ASC' => __('Ascending', 'yomooh-core'),
                    'DESC' => __('Descending', 'yomooh-core'),
                ],
            ]
        );

        $this->add_control(
            'posts_per_page',
            [
                'label' => __('Number of Posts', 'yomooh-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => 6,
                'min' => 1,
                'max' => 50,
            ]
        );

        $this->end_controls_section();

        // Pagination Subsection
        $this->start_controls_section(
            'section_pagination',
            [
                'label' => __('Pagination', 'yomooh-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'pagination_type',
            [
                'label' => __('Pagination Type', 'yomooh-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'none',
                'options' => [
                    'none' => __('None', 'yomooh-core'),
                    'numeric' => __('Numbers', 'yomooh-core'),
					'loadmore' => __('Load More', 'yomooh-core'),
                    'standard' => __('Numbers + Previous/Next', 'yomooh-core'),
                ],
            ]
        );

        $this->add_control(
            'load_more_text',
            [
                'label' => __('Load More Text', 'yomooh-core'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Load More', 'yomooh-core'),
                'condition' => [
                    'pagination_type' => 'loadmore',
                ],
            ]
        );

        $this->add_responsive_control(
            'pagination_align',
            [
                'label' => __('Alignment', 'yomooh-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'yomooh-core'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'yomooh-core'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'yomooh-core'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .yomooh-pagination' => 'text-align: {{VALUE}}',
                ],
                'condition' => [
                    'pagination_type!' => 'none',
                ],
            ]
        );

        $this->end_controls_section();

        // Style Tab - Featured Image
        $this->start_controls_section(
            'section_style_featured_image',
            [
                'label' => __('Featured Image', 'yomooh-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_control(
			'hide_featured_image',
			[
				'label' => __('Hide Featured Image', 'yomooh-core'),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => __('Yes', 'yomooh-core'),
				'label_off' => __('No', 'yomooh-core'),
				'return_value' => 'yes',
				'default' => '',
				'separator' => 'before',
			]
		);

        $this->add_control(
            'featured_image_size',
            [
                'label' => __('Image Size', 'yomooh-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'large',
				'condition' => [
                    'hide_featured_image!' => 'yes',
                ],
                'options' => $this->get_image_sizes(),
            ]
        );

        $this->add_control(
            'featured_image_ratio',
            [
                'label' => __('Image Ratio', 'yomooh-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0.1,
                        'max' => 2,
                        'step' => 0.01,
                    ],
                ],
				'condition' => [
                    'hide_featured_image!' => 'yes',
                ],
                'selectors' => [
                    '{{WRAPPER}} .yomooh-listpost-thumbnail img' => 'aspect-ratio: {{SIZE}}; object-fit: cover;',
                ],
            ]
        );

        $this->add_responsive_control(
            'featured_image_width',
            [
                'label' => __('Image Width', 'yomooh-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['%', 'px'],
                'range' => [
                    '%' => [
                        'min' => 10,
                        'max' => 100,
                    ],
                    'px' => [
                        'min' => 100,
                        'max' => 1000,
                    ],
                ],
				'condition' => [
                    'hide_featured_image!' => 'yes',
                ],
                'selectors' => [
                    '{{WRAPPER}} .yomooh-listpost-thumbnail' => 'width: {{SIZE}}{{UNIT}}',
                ],
            ]
        );
		$this->add_responsive_control(
            'featured_image_height',
            [
                'label' => __('Image Height', 'yomooh-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['%', 'px'],
                'range' => [
                    '%' => [
                        'min' => 10,
                        'max' => 100,
                    ],
                    'px' => [
                        'min' => 100,
                        'max' => 1000,
                    ],
                ],
				'condition' => [
                    'hide_featured_image!' => 'yes',
                ],
                'selectors' => [
                    '{{WRAPPER}} .yomooh-listpost-thumbnail' => 'height: {{SIZE}}{{UNIT}}',
                ],
            ]
        );
		$this->add_control(
			'featured_image_fit',
			[
				'label' => __('Image Fit', 'yomooh-core'),
				'type' => Controls_Manager::SELECT,
				'default' => 'cover',
				'options' => [
					'cover' => __('Cover', 'yomooh-core'),
					'contain' => __('Contain', 'yomooh-core'),
					'fill' => __('Fill', 'yomooh-core'),
					'none' => __('None', 'yomooh-core'),
					'scale-down' => __('Scale Down', 'yomooh-core'),
				],
				'condition' => [
                    'hide_featured_image!' => 'yes',
                ],
				'selectors' => [
					'{{WRAPPER}} .yomooh-listpost-thumbnail img' => 'object-fit: {{VALUE}}',
				],
			]
		);

        $this->add_responsive_control(
            'featured_image_position',
            [
                'label' => __('Image Position', 'yomooh-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'top',
				'condition' => [
                    'hide_featured_image!' => 'yes',
                ],
                'options' => [
                    'top' => __('Top', 'yomooh-core'),
                    'left' => __('Left', 'yomooh-core'),
                    'right' => __('Right', 'yomooh-core'),
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'featured_image_border',
                'selector' => '{{WRAPPER}} .yomooh-listpost-thumbnail img',
				'condition' => [
                    'hide_featured_image!' => 'yes',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'featured_image_border_radius',
            [
                'label' => __('Border Radius', 'yomooh-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
				'condition' => [
                    'hide_featured_image!' => 'yes',
                ],
                'selectors' => [
                    '{{WRAPPER}} .yomooh-listpost-thumbnail img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'featured_image_box_shadow',
                'selector' => '{{WRAPPER}} .yomooh-listpost-thumbnail img',
				'condition' => [
                    'hide_featured_image!' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'featured_image_hover_effect',
            [
                'label' => __('Hover Effect', 'yomooh-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'none',
				'condition' => [
                    'hide_featured_image!' => 'yes',
                ],
                'options' => [
                    'none' => __('None', 'yomooh-core'),
                    'zoom-in' => __('Zoom In', 'yomooh-core'),
                    'zoom-out' => __('Zoom Out', 'yomooh-core'),
                    'grayscale' => __('Grayscale', 'yomooh-core'),
                    'blur' => __('Blur', 'yomooh-core'),
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_section();

        // Style Tab - Post Title
        $this->start_controls_section(
            'section_style_title',
            [
                'label' => __('Post Title', 'yomooh-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __('Color', 'yomooh-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .yomooh-listpost-title a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'title_color_hover',
            [
                'label' => __('Hover Color', 'yomooh-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .yomooh-listpost-title a:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .yomooh-listpost-title',
                'fields_options' => [
                'font_size' => [
                    'responsive' => true, 
                ],
                'line_height' => [
                    'responsive' => true,
                ]
            ]
        ]
    );

        $this->add_control(
            'title_html_tag',
            [
                'label' => __('HTML Tag', 'yomooh-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => 'H1',
                    'h2' => 'H2',
                    'h3' => 'H3',
                    'h4' => 'H4',
                    'h5' => 'H5',
                    'h6' => 'H6',
                    'div' => 'div',
                ],
                'default' => 'h3',
            ]
        );

        $this->add_responsive_control(
            'title_spacing',
            [
                'label' => __('Spacing', 'yomooh-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .yomooh-listpost-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Style Tab - Entry Meta
        $this->start_controls_section(
            'section_style_meta',
            [
                'label' => __('Entry Meta', 'yomooh-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'meta_display',
            [
                'label' => __('Display', 'yomooh-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'default',
                'options' => [
                    'default' => __('Default', 'yomooh-core'),
                    'custom' => __('Custom', 'yomooh-core'),
                    'none' => __('None', 'yomooh-core'),
                ],
            ]
        );

        $this->add_control(
            'meta_tags',
            [
                'label' => __('Meta Tags', 'yomooh-core'),
                'description' => __('Input custom entry meta tags to show, separate by comma. e.g. avatar,author,update. Keys include: [avatar, author, date, category, tag, comment, update, read].', 'yomooh-core'),
                'type' => Controls_Manager::TEXT,
                'default' => 'author,date,category',
                'condition' => [
                    'meta_display' => 'custom',
                ],
            ]
        );

        $this->add_control(
            'meta_position',
            [
                'label' => __('Position', 'yomooh-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'top',
                'options' => [
                    'top' => __('Top', 'yomooh-core'),
                    'bottom' => __('Bottom', 'yomooh-core'),
                ],
                'condition' => [
                    'meta_display!' => 'none',
                ],
            ]
        );

        $this->add_control(
            'meta_divider_style',
            [
                'label' => __('Divider Style', 'yomooh-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'none',
                'options' => [
                    'none' => __('None', 'yomooh-core'),
                    'solid' => __('Solid', 'yomooh-core'),
                    'dotted' => __('Dotted', 'yomooh-core'),
                    'dashed' => __('Dashed', 'yomooh-core'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .yomooh-listpost-meta .meta-separator' => 'border-right-style: {{VALUE}}',
                ],
                'condition' => [
                    'meta_display!' => 'none',
					'meta_display!' => 'none',
                ],
            ]
        );

        $this->add_control(
            'meta_divider_color',
            [
                'label' => __('Divider Color', 'yomooh-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .yomooh-listpost-meta .meta-separator' => 'border-right-color: {{VALUE}}',
                ],
                'condition' => [
                    'meta_divider_style!' => 'none',
					'meta_display!' => 'none',
                ],
            ]
        );

        $this->add_control(
            'meta_divider_width',
            [
                'label' => __('Divider Width', 'yomooh-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 10,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .yomooh-listpost-meta .meta-separator' => 'border-right-width: {{SIZE}}{{UNIT}}; margin-right: calc({{SIZE}}{{UNIT}} + 5px); padding-right: calc({{SIZE}}{{UNIT}} + 5px);',
                ],
                'condition' => [
                    'meta_divider_style!' => 'none',
					'meta_display!' => 'none',
                ],
            ]
        );

        $this->add_control(
            'meta_color',
            [
                'label' => __('Text Color', 'yomooh-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .yomooh-listpost-meta' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .yomooh-listpost-meta a' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'meta_display!' => 'none',
                ],
            ]
        );

        $this->add_control(
            'meta_link_hover_color',
            [
                'label' => __('Link Hover Color', 'yomooh-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .yomooh-listpost-meta a:hover' => 'color: {{VALUE}}',
                ],
                'condition' => [
                    'meta_display!' => 'none',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'meta_typography',
                'selector' => '{{WRAPPER}} .yomooh-listpost-meta',
                'condition' => [
                    'meta_display!' => 'none',
                ],
            ]
        );

        $this->add_control(
            'meta_avatar_size',
            [
                'label' => __('Avatar Size', 'yomooh-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 16,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .yomooh-listpost-meta .meta-avatar img' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'meta_display!' => 'none',
                ],
            ]
        );

        $this->add_responsive_control(
            'meta_spacing',
            [
                'label' => __('Spacing', 'yomooh-core'),
				'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .yomooh-listpost-meta' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'meta_display!' => 'none',
                ],
            ]
        );
		$this->add_control(
            'meta_gap',
            [
                'label' => __('Gap', 'yomooh-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .yomooh-listpost-meta' => ' gap: 0 {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'meta_display!' => 'none',
                ],
            ]
        );

        $this->add_control(
            'category_taxonomy',
            [
                'label' => __('Category Taxonomy', 'yomooh-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'category',
                'options' => $this->get_taxonomies(),
                'condition' => [
                    'meta_display!' => 'none',
                ],
            ]
        );

        $this->add_control(
            'category_size',
            [
                'label' => __('Category Size', 'yomooh-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 30,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .yomooh-listpost-meta .post-categories' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'meta_display!' => 'none',
                ],
            ]
        );
		$this->add_control(
            'category_spacing',
            [
                'label' => __('Spacing', 'yomooh-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .yomooh-listpost-meta .post-categories' => ' gap: 0 {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'meta_display!' => 'none',
                ],
            ]
        );

        $this->add_control(
            'hide_category',
            [
                'label' => __('Hide Category', 'yomooh-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Hide', 'yomooh-core'),
                'label_off' => __('Show', 'yomooh-core'),
                'return_value' => 'yes',
                'default' => 'no',
                'condition' => [
                    'meta_display!' => 'none',
                ],
            ]
        );

        $this->end_controls_section();

        // Style Tab - Excerpt
        $this->start_controls_section(
            'section_style_excerpt',
            [
                'label' => __('Excerpt', 'yomooh-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'hide_excerpt',
            [
                'label' => __('Hide Excerpt', 'yomooh-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Hide', 'yomooh-core'),
                'label_off' => __('Show', 'yomooh-core'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'excerpt_length',
            [
                'label' => __('Max Length', 'yomooh-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => 25,
                'min' => 0,
                'max' => 500,
                'condition' => [
                    'hide_excerpt!' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'excerpt_color',
            [
                'label' => __('Text Color', 'yomooh-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .yomooh-listpost-excerpt' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'hide_excerpt!' => 'yes',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'excerpt_typography',
                'selector' => '{{WRAPPER}} .yomooh-listpost-excerpt',
                'condition' => [
                    'hide_excerpt!' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'excerpt_spacing',
            [
                'label' => __('Spacing', 'yomooh-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .yomooh-listpost-excerpt' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'hide_excerpt!' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();

        // Style Tab - Read More
        $this->start_controls_section(
            'section_style_read_more',
            [
                'label' => __('Read More', 'yomooh-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'read_more_display',
            [
                'label' => __('Display', 'yomooh-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'default',
                'options' => [
                    'button' => __('Button', 'yomooh-core'),
					'onlytext' => __('Only Text', 'yomooh-core'),
                    'none' => __('None', 'yomooh-core'),
                ],
            ]
        );

        $this->add_control(
            'read_more_text',
            [
                'label' => __('Text', 'yomooh-core'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Read More', 'yomooh-core'),
                'condition' => [
                    'read_more_display!' => 'none',
                ],
            ]
        );

        $this->add_control(
            'read_more_color',
            [
                'label' => __('Text Color', 'yomooh-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .yomooh-listpost-read-more' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'read_more_display!' => 'none',
                ],
            ]
        );

        $this->add_control(
            'read_more_hover_color',
            [
                'label' => __('Hover Color', 'yomooh-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .yomooh-listpost-read-more:hover' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'read_more_display!' => 'none',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'read_more_typography',
                'selector' => '{{WRAPPER}} .yomooh-listpost-read-more',
                'condition' => [
                    'read_more_display!' => 'none',
                ],
            ]
        );

        $this->add_control(
            'read_more_button_bg_color',
            [
                'label' => __('Background Color', 'yomooh-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .yomooh-listpost-read-more' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'read_more_display' => 'button',
                ],
            ]
        );

        $this->add_control(
            'read_more_button_hover_bg_color',
            [
                'label' => __('Hover Background Color', 'yomooh-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .yomooh-listpost-read-more:hover' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'read_more_display' => 'button',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'read_more_button_border',
                'selector' => '{{WRAPPER}} .yomooh-listpost-read-more',
                'condition' => [
                    'read_more_display' => 'button',
                ],
            ]
        );

        $this->add_control(
            'read_more_button_border_radius',
            [
                'label' => __('Border Radius', 'yomooh-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .yomooh-listpost-read-more' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'read_more_display' => 'button',
                ],
            ]
        );

        $this->add_responsive_control(
            'read_more_button_padding',
            [
                'label' => __('Padding', 'yomooh-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .yomooh-listpost-read-more' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'read_more_display' => 'button',
                ],
            ]
        );
		 $this->add_responsive_control(
            'read_more_button_alignment',
            [
                'label' => __('Button alignment', 'yomooh-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'yomooh-core'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'yomooh-core'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'yomooh-core'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .yomooh-listpost-read-more-wrapper' => 'text-align: {{VALUE}};',
                ],
                'condition' => [
                    'read_more_display!' => 'none',
                ],
            ]
        );

        $this->add_responsive_control(
            'read_more_button_margin',
            [
                'label' => __('Margin', 'yomooh-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .yomooh-listpost-read-more' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'read_more_display' => 'button',
                ],
            ]
        );

        $this->end_controls_section();

        // Style Tab - General
        $this->start_controls_section(
            'section_style_general',
            [
                'label' => __('General', 'yomooh-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'post_bg_color',
            [
                'label' => __('Background Color', 'yomooh-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .yomooh-listpost-item' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'post_border',
                'selector' => '{{WRAPPER}} .yomooh-listpost-item',
            ]
        );

        $this->add_control(
            'post_border_radius',
            [
                'label' => __('Border Radius', 'yomooh-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .yomooh-listpost-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'post_box_shadow',
                'selector' => '{{WRAPPER}} .yomooh-listpost-item',
            ]
        );

        $this->add_responsive_control(
            'post_padding',
            [
                'label' => __('Padding', 'yomooh-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .yomooh-listpost-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_responsive_control(
            'post_margin',
            [
                'label' => __('Margin', 'yomooh-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .yomooh-listpost-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    // Helper methods
    protected function get_post_types() {
        $post_types = get_post_types([
            'public' => true,
            'show_in_nav_menus' => true
        ], 'objects');

        $options = [];

        foreach ($post_types as $post_type) {
            $options[$post_type->name] = $post_type->label;
        }

        return $options;
    }

    protected function get_authors() {
    $users = get_users([
        'capability' => 'edit_posts',
        'has_published_posts' => true,
        'fields' => ['ID', 'display_name']
    ]);

    $options = [];

    foreach ($users as $user) {
        $options[$user->ID] = $user->display_name;
    }

    return $options;
}

    protected function get_post_categories() {
        $categories = get_categories(['hide_empty' => false]);
        $options = [];

        foreach ($categories as $category) {
            $options[$category->term_id] = $category->name;
        }

        return $options;
    }

    protected function get_taxonomies() {
        $taxonomies = get_taxonomies([
            'public' => true,
            'show_in_nav_menus' => true
        ], 'objects');

        $options = [];

        foreach ($taxonomies as $taxonomy) {
            $options[$taxonomy->name] = $taxonomy->label;
        }

        return $options;
    }

    protected function get_image_sizes() {
        $image_sizes = get_intermediate_image_sizes();
        $options = [];

        foreach ($image_sizes as $size) {
            $options[$size] = ucwords(str_replace(['-', '_'], ' ', $size));
        }

        $options['full'] = __('Full', 'yomooh-core');

        return $options;
    }

    protected function render() {
    $settings = $this->get_settings_for_display();
    
    // Get current page for pagination
    $paged = max(1, get_query_var('paged'), get_query_var('page'));
    
    // Query arguments
    $args = [
        'post_type' => $settings['post_type'],
        'posts_per_page' => $settings['posts_per_page'],
        'orderby' => $settings['orderby'],
        'order' => $settings['order'],
        'ignore_sticky_posts' => 1,
        'paged' => $paged,
    ];

    // Post format filter
    if (!empty($settings['post_format'])) {
        $args['tax_query'] = [
            [
                'taxonomy' => 'post_format',
                'field' => 'slug',
                'terms' => ['post-format-' . $settings['post_format']],
            ]
        ];
    }

    // Author filter
    if (!empty($settings['author_filter'])) {
        $args['author__in'] = $settings['author_filter'];
    }

    // Category filter
    if (!empty($settings['category_filter'])) {
        $args['category__in'] = $settings['category_filter'];
    }

    // Exclude categories
    if (!empty($settings['exclude_categories'])) {
        $exclude_cats = array_map('trim', explode(',', $settings['exclude_categories']));
        $args['category__not_in'] = $exclude_cats;
    }

    // Exclude posts
    if (!empty($settings['exclude_posts'])) {
        $exclude_posts = array_map('trim', explode(',', $settings['exclude_posts']));
        $args['post__not_in'] = $exclude_posts;
    }

    $query = new \WP_Query($args);

    // CSS classes
    $this->add_render_attribute('wrapper', 'class', 'yomooh-listpost-wrapper');
    $this->add_render_attribute('container', 'class', 'yomooh-listpost-container');
    $this->add_render_attribute('listing', 'class', 'yomooh-listpost-listing');

    // Grid layout
    $this->add_render_attribute('listing', 'class', 'elementor-grid');
    $this->add_render_attribute('listing', 'class', 'elementor-items-' . $settings['columns']);

    // Column border
    if ('yes' === $settings['column_border']) {
        $this->add_render_attribute('listing', 'class', 'has-column-border');
    }

    // Bottom border
    if ('yes' === $settings['bottom_border']) {
        $this->add_render_attribute('listing', 'class', 'has-bottom-border');
    }

    // Centering content
    if ('yes' === $settings['centering_content']) {
        $this->add_render_attribute('listing', 'class', 'has-centered-content');
    }

			// This is correct (no warnings)
		$image_position_desktop = $this->get_settings_for_display('featured_image_position');
		$image_position_tablet = $this->get_settings_for_display('featured_image_position_tablet');
		$image_position_mobile = $this->get_settings_for_display('featured_image_position_mobile');

		// Use these values safely
		$this->add_render_attribute('wrapper', 'class', 'image-position-' . esc_attr($image_position_desktop));
		$this->add_render_attribute('wrapper', 'class', 'elementor-tablet-image-position-' . esc_attr($image_position_tablet));
		$this->add_render_attribute('wrapper', 'class', 'elementor-mobile-image-position-' . esc_attr($image_position_mobile));


    // Hover effect
    if ('none' !== $settings['featured_image_hover_effect']) {
        $this->add_render_attribute('listing', 'class', 'image-hover-' . $settings['featured_image_hover_effect']);
    }
    ?>

    <div <?php echo $this->get_render_attribute_string('wrapper'); ?>>
        <div <?php echo $this->get_render_attribute_string('container'); ?>>
            <?php if ($query->have_posts()) : ?>
                <div <?php echo $this->get_render_attribute_string('listing'); ?>>
                    <?php while ($query->have_posts()) : $query->the_post(); ?>
                        <article id="post-<?php the_ID(); ?>" <?php post_class('yomooh-listpost-item'); ?>>
                           <?php if (has_post_thumbnail() && empty($settings['hide_featured_image'])) : ?>
                                <div class="yomooh-listpost-thumbnail">
                                    <a href="<?php the_permalink(); ?>" aria-hidden="true" tabindex="-1">
                                        <?php
                                        the_post_thumbnail($settings['featured_image_size'], [
                                            'alt' => get_the_title(),
                                            'loading' => 'lazy'
                                        ]);
                                        ?>
                                    </a>
                                </div>
                            <?php endif; ?>

                            <div class="yomooh-listpost-content">
                                <?php if ('none' !== $settings['meta_display'] && 'top' === $settings['meta_position']) : ?>
                                    <div class="yomooh-listpost-meta">
                                        <?php $this->render_post_meta(); ?>
                                    </div>
                                <?php endif; ?>

                                <<?php echo $settings['title_html_tag']; ?> class="yomooh-listpost-title">
                                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                </<?php echo $settings['title_html_tag']; ?>>

                                <?php if ('none' !== $settings['meta_display'] && 'bottom' === $settings['meta_position']) : ?>
                                    <div class="yomooh-listpost-meta">
                                        <?php $this->render_post_meta(); ?>
                                    </div>
                                <?php endif; ?>

                                <?php if ('yes' !== $settings['hide_excerpt']) : ?>
                                    <div class="yomooh-listpost-excerpt">
                                        <?php
                                        $excerpt = get_the_excerpt();
                                        if (!empty($settings['excerpt_length'])) {
                                            $excerpt = wp_trim_words($excerpt, $settings['excerpt_length'], '...');
                                        }
                                        echo wp_kses_post($excerpt);
                                        ?>
                                    </div>
                                <?php endif; ?>

                                <?php if ('none' !== $settings['read_more_display']) : ?>
                                    <div class="yomooh-listpost-read-more-wrapper">
                                        <a href="<?php the_permalink(); ?>" class="yomooh-listpost-read-more">
                                            <?php echo esc_html($settings['read_more_text']); ?>
                                        </a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </article>
                    <?php endwhile; ?>
                </div>
				<?php $this->render_pagination($query); ?>
                <?php wp_reset_postdata(); ?>
            <?php else : ?>
                <div class="yomooh-listpost-no-results">
                    <p><?php esc_html_e('No posts found.', 'yomooh-core'); ?></p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php
}
 protected function render_pagination($query) {
    $settings = $this->get_settings_for_display();
    $paged = max(1, get_query_var('paged'), get_query_var('page'));
     // Query arguments
                $args = [
                    'post_type' => $settings['post_type'],
                    'posts_per_page' => $settings['posts_per_page'],
                    'orderby' => $settings['orderby'],
                    'order' => $settings['order'],
                    'ignore_sticky_posts' => 1,
                    'paged' => $paged,
                ];

                ?>
               <?php if ('none' !== $settings['pagination_type']) : ?>
                <div class="yomooh-pagination">
                    <?php if ('loadmore' === $settings['pagination_type']) : ?>
                        <?php if ($query->max_num_pages > $paged) : ?>
                            <div class="yomooh-loadmore-container">
                                <button class="yomooh-loadmore-button" 
                                    data-max-pages="<?php echo esc_attr($query->max_num_pages); ?>" 
                                    data-next-page="<?php echo esc_attr($paged + 1); ?>"
                                    data-base-url="<?php echo esc_url(get_pagenum_link(999999)); ?>">
                                    <?php echo esc_html($settings['load_more_text']); ?>
                                </button>
                                <div class="yomooh-loading-spinner" style="display: none;"></div>
                            </div>

                           
                        <?php endif; ?>

                    <?php elseif ('numeric' === $settings['pagination_type']) : ?>
                        <div class="pagination-containers numeric-paginations">
                            <?php
                            $big = 999999999;
                            echo paginate_links([
                                'base' => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
                                'format' => '?paged=%#%',
                                'current' => $paged,
                                'type' => 'plain',
                                'total' => $query->max_num_pages,
                                'prev_next' => false,
                            ]);
                            ?>
                        </div>

                    <?php elseif ('standard' === $settings['pagination_type']) : ?>
                        <div class="pagination-containers standard-paginations">
                            <?php
                            $big = 999999999;
                            echo paginate_links([
                                'base' => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
                                'format' => '?paged=%#%',
                                'current' => $paged,
                                'total' => $query->max_num_pages,
                                'prev_next' => true,
                                'prev_text' => __('« Previous', 'yomooh-core'),
                                'next_text' => __('Next »', 'yomooh-core'),
                            ]);
                            ?>
                        </div>
                    <?php endif; ?>
                </div>
             <?php endif; ?>
    <?php
}
protected function render_post_meta() {
    $settings = $this->get_settings_for_display();
    
    if ('custom' === $settings['meta_display']) {
        $meta_tags = array_map('trim', explode(',', $settings['meta_tags']));
    } else {
        // Default meta tags
        $meta_tags = ['author', 'date', 'category'];
    }

    $meta_items = [];
    
    foreach ($meta_tags as $tag) {
        switch ($tag) {
            case 'avatar':
                $meta_items[] = '<span class="meta-avatar">' . get_avatar(get_the_author_meta('ID'), $settings['meta_avatar_size']['size']) . '</span>';
                break;
                
            case 'author':
                $meta_items[] = '<span class="meta-author"><a href="' . esc_url(get_author_posts_url(get_the_author_meta('ID'))) . '">' . get_the_author() . '</a></span>';
                break;
                
            case 'date':
                $meta_items[] = '<span class="meta-date">' . get_the_date() . '</span>';
                break;
                
            case 'update':
                $meta_items[] = '<span class="meta-update">' . get_the_modified_date() . '</span>';
                break;
                
            case 'category':
                if ('yes' !== $settings['hide_category']) {
                    $categories = get_the_terms(get_the_ID(), $settings['category_taxonomy']);
                    if (!empty($categories)) {
                        $category_links = [];
                        foreach ($categories as $category) {
                            $category_links[] = '<a href="' . esc_url(get_category_link($category->term_id)) . '">' . esc_html($category->name) . '</a>';
                        }
                        $meta_items[] = '<span class="post-categories">' . implode(', ', $category_links) . '</span>';
                    }
                }
                break;
                
            case 'tag':
                $tags = get_the_tags();
                if (!empty($tags)) {
                    $tag_links = [];
                    foreach ($tags as $tag) {
                        $tag_links[] = '<a href="' . esc_url(get_tag_link($tag->term_id)) . '">' . esc_html($tag->name) . '</a>';
                    }
                    $meta_items[] = '<span class="post-tags">' . implode(', ', $tag_links) . '</span>';
                }
                break;
                
            case 'comment':
                if (comments_open()) {
                    $comment_count = get_comments_number();
                    $meta_items[] = '<span class="meta-comments"><a href="' . esc_url(get_comments_link()) . '">' . sprintf(_n('%s Comment', '%s Comments', $comment_count, 'yomooh-core'), $comment_count) . '</a></span>';
                }
                break;
                
            case 'read':
                $read_time = ceil(str_word_count(get_the_content()) / 200); // 200 words per minute
                $meta_items[] = '<span class="meta-read-time">' . sprintf(_n('%s min read', '%s min read', $read_time, 'yomooh-core'), $read_time) . '</span>';
                break;
        }
    }

    if (!empty($meta_items)) {
        $divider_style = isset($settings['meta_divider_style']) ? $settings['meta_divider_style'] : 'none';
$separator = ('none' !== $divider_style) ? '<span class="meta-separator"></span>' : '';
        echo implode($separator, $meta_items);
    }
}
}