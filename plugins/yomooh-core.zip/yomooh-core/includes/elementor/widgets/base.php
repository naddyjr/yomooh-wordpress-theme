<?php
/**
 * Yomooh Elementor Widgets Loader
 *
 * This file is responsible for loading Elementor widgets and their dependencies.
 *
 * @package Yomooh core
 */
use Elementor\Plugin;

if (!defined('ABSPATH')) exit;

final class Yomooh_Elementor_Widgets_Loader {

    public function __construct() {
        add_action('elementor/widgets/widgets_registered', [$this, 'register_widgets']);
        add_action('elementor/elements/categories_registered', [$this, 'add_widget_categories']);
    }

    public function add_widget_categories($elements_manager) {
        // Add our custom category as second category
        $elements_manager->add_category(
            'yomooh-elements',
            [
                'title' => __('Yomooh Elements', 'yomooh-core'),
                'icon' => 'eicon-yomooh', 
            ]
        );
        
        $categories = $elements_manager->get_categories();
        $new_order = [];
        
        // Keep 'basic' as first category
        if (isset($categories['basic'])) {
            $new_order['basic'] = $categories['basic'];
        }
        // Add our category second
        $new_order['yomooh-elements'] = [
            'title' => __('Yomooh Elements', 'yomooh-core'),
            'icon' => 'eicon-yomooh',
        ];
        // Add remaining categories
        foreach ($categories as $key => $value) {
            if ($key !== 'basic' && $key !== 'yomooh-elements') {
                $new_order[$key] = $value;
            }
        }
        // Set the new order
        $reflection = new ReflectionClass($elements_manager);
        $property = $reflection->getProperty('categories');
        $property->setAccessible(true);
        $property->setValue($elements_manager, $new_order);
    }

    public function register_widgets() {
        // Load widgets manually
        require_once YOMOOH_PLUGIN_DIR . 'includes/elementor/widgets/elements/logo.php';
        require_once YOMOOH_PLUGIN_DIR . 'includes/elementor/widgets/elements/heading.php';
        require_once YOMOOH_PLUGIN_DIR . 'includes/elementor/widgets/elements/post-listing.php';
        require_once YOMOOH_PLUGIN_DIR . 'includes/elementor/widgets/elements/post-slider.php';
		require_once YOMOOH_PLUGIN_DIR . 'includes/elementor/widgets/elements/breaking-news.php';
        require_once YOMOOH_PLUGIN_DIR . 'includes/elementor/widgets/elements/taxonomy.php';
        require_once YOMOOH_PLUGIN_DIR . 'includes/elementor/widgets/elements/button.php';
        require_once YOMOOH_PLUGIN_DIR . 'includes/elementor/widgets/elements/image.php';
        require_once YOMOOH_PLUGIN_DIR . 'includes/elementor/widgets/elements/dark-toggle.php';
        require_once YOMOOH_PLUGIN_DIR . 'includes/elementor/widgets/elements/banner.php';
        require_once YOMOOH_PLUGIN_DIR . 'includes/elementor/widgets/elements/ad-script.php';
        require_once YOMOOH_PLUGIN_DIR . 'includes/elementor/widgets/elements/search.php';
		//require_once YOMOOH_PLUGIN_DIR . 'includes/elementor/widgets/elements/menu.php';//
		//require_once YOMOOH_PLUGIN_DIR . 'includes/elementor/widgets/elements/mobile-menu.php';//
		require_once YOMOOH_PLUGIN_DIR . 'includes/elementor/widgets/elements/social-list.php';
        // Register widgets
        $widgets_manager = Plugin::instance()->widgets_manager;
        $widgets_manager->register(new Yomooh_Widget_Logo());
        $widgets_manager->register(new Yomooh_Widget_Heading());
        $widgets_manager->register(new Yomooh_Widget_Post_Listing());
        $widgets_manager->register(new Yomooh_Post_Carousel_Slider_Widget());
		$widgets_manager->register(new Yomooh_Breaking_News());
        $widgets_manager->register(new Yomooh_Taxonomy_List_Widget());
        $widgets_manager->register(new Yomooh_Widget_Button());
        $widgets_manager->register(new Yomooh_Widget_Image());
        $widgets_manager->register(new Yomooh_Widget_Dark_Toggle());
        $widgets_manager->register(new Yomooh_Widget_Banner());
        $widgets_manager->register(new Yomooh_Widget_Ad_Script());
		$widgets_manager->register(new Yomooh_Search_Widget());
		//$widgets_manager->register(new Yomooh_Menu_Widget());//
        //$widgets_manager->register(new Yomooh_Mobile_Menus_Widget());//
		$widgets_manager->register(new Yomooh_Social_Media_List_Widget());
    }
}

new Yomooh_Elementor_Widgets_Loader();