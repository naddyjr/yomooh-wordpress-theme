<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class Yomooh_Address_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct(
            'yomooh_address_widget',
            __('Yomooh Address', 'yomooh-core'),
            array(
                'description' => __('Display address information with icons.', 'yomooh-core'),
                'customize_selective_refresh' => true,
            )
        );
    }

    public function widget($args, $instance) {
        $title = apply_filters('widget_title', empty($instance['title']) ? '' : $instance['title'], $instance, $this->id_base);
        $address_title = empty($instance['address_title']) ? '' : $instance['address_title'];
        $office_address = empty($instance['office_address']) ? '' : $instance['office_address'];
        $phone_label = empty($instance['phone_label']) ? '' : $instance['phone_label'];
        $phone_number = empty($instance['phone_number']) ? '' : $instance['phone_number'];
        $tel_number = empty($instance['tel_number']) ? '' : $instance['tel_number'];
        $email_address = empty($instance['email_address']) ? '' : $instance['email_address'];
        $additional_label = empty($instance['additional_label']) ? '' : $instance['additional_label'];
        $additional_info = empty($instance['additional_info']) ? '' : $instance['additional_info'];

        echo $args['before_widget'];

        if ($title) {
            echo $args['before_title'] . esc_html($title) . $args['after_title'];
        }

        echo '<div class="yomooh-address-widget">';

        if ($address_title) {
            echo '<h4 class="address-title">' . esc_html($address_title) . '</h4>';
        }

        if ($office_address) {
            echo '<div class="address-info office-address">';
            echo '<i class="fas fa-map-marker-alt"></i>';
            echo '<div class="address-text">' . wpautop(esc_html($office_address)) . '</div>';
            echo '</div>';
        }

        if ($phone_number) {
            echo '<div class="address-info phone-number">';
            echo '<i class="fas fa-mobile-alt"></i>';
            echo '<div class="address-text">';
            if ($phone_label) {
                echo '<span class="info-label">' . esc_html($phone_label) . '</span>';
            }
            echo '<a href="tel:' . esc_attr(str_replace(' ', '', $phone_number)) . '">' . esc_html($phone_number) . '</a>';
            echo '</div>';
            echo '</div>';
        }

        if ($tel_number) {
            echo '<div class="address-info tel-number">';
            echo '<i class="fas fa-phone"></i>';
            echo '<div class="address-text">';
            echo '<a href="tel:' . esc_attr(str_replace(' ', '', $tel_number)) . '">' . esc_html($tel_number) . '</a>';
            echo '</div>';
            echo '</div>';
        }

        if ($email_address) {
            echo '<div class="address-info email-address">';
            echo '<i class="fas fa-envelope"></i>';
            echo '<div class="address-text">';
            echo '<a href="mailto:' . esc_attr($email_address) . '">' . esc_html($email_address) . '</a>';
            echo '</div>';
            echo '</div>';
        }

        if ($additional_info) {
            echo '<div class="address-info additional-info">';
            if ($additional_label) {
                echo '<i class="fas fa-info-circle"></i>';
            }
            echo '<div class="address-text">';
            if ($additional_label) {
                echo '<span class="info-label">' . esc_html($additional_label) . '</span>';
            }
            echo wpautop(esc_html($additional_info));
            echo '</div>';
            echo '</div>';
        }

        echo '</div>';
        echo $args['after_widget'];
    }

    public function form($instance) {
        $defaults = array(
            'title' => '',
            'address_title' => '',
            'office_address' => '',
            'phone_label' => __('Phone:', 'yomooh-core'),
            'phone_number' => '',
            'tel_number' => '',
            'email_address' => '',
            'additional_label' => '',
            'additional_info' => ''
        );

        $instance = wp_parse_args((array) $instance, $defaults);
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Widget Title:', 'yomooh-core'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" 
                   name="<?php echo $this->get_field_name('title'); ?>" 
                   type="text" value="<?php echo esc_attr($instance['title']); ?>" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('address_title'); ?>"><?php _e('Address Title:', 'yomooh-core'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('address_title'); ?>" 
                   name="<?php echo $this->get_field_name('address_title'); ?>" 
                   type="text" value="<?php echo esc_attr($instance['address_title']); ?>" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('office_address'); ?>"><?php _e('Office Address:', 'yomooh-core'); ?></label>
            <textarea class="widefat" rows="4" id="<?php echo $this->get_field_id('office_address'); ?>" 
                      name="<?php echo $this->get_field_name('office_address'); ?>"><?php echo esc_textarea($instance['office_address']); ?></textarea>
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('phone_label'); ?>"><?php _e('Phone Label:', 'yomooh-core'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('phone_label'); ?>" 
                   name="<?php echo $this->get_field_name('phone_label'); ?>" 
                   type="text" value="<?php echo esc_attr($instance['phone_label']); ?>" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('phone_number'); ?>"><?php _e('Phone Number:', 'yomooh-core'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('phone_number'); ?>" 
                   name="<?php echo $this->get_field_name('phone_number'); ?>" 
                   type="text" value="<?php echo esc_attr($instance['phone_number']); ?>" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('tel_number'); ?>"><?php _e('Tel Number:', 'yomooh-core'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('tel_number'); ?>" 
                   name="<?php echo $this->get_field_name('tel_number'); ?>" 
                   type="text" value="<?php echo esc_attr($instance['tel_number']); ?>" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('email_address'); ?>"><?php _e('Email Address:', 'yomooh-core'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('email_address'); ?>" 
                   name="<?php echo $this->get_field_name('email_address'); ?>" 
                   type="email" value="<?php echo esc_attr($instance['email_address']); ?>" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('additional_label'); ?>"><?php _e('Additional Label:', 'yomooh-core'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('additional_label'); ?>" 
                   name="<?php echo $this->get_field_name('additional_label'); ?>" 
                   type="text" value="<?php echo esc_attr($instance['additional_label']); ?>" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('additional_info'); ?>"><?php _e('Additional Info:', 'yomooh-core'); ?></label>
            <textarea class="widefat" rows="4" id="<?php echo $this->get_field_id('additional_info'); ?>" 
                      name="<?php echo $this->get_field_name('additional_info'); ?>"><?php echo esc_textarea($instance['additional_info']); ?></textarea>
        </p>
        <?php
    }

    public function update($new_instance, $old_instance) {
        $instance = $old_instance;
        $instance['title'] = sanitize_text_field($new_instance['title']);
        $instance['address_title'] = sanitize_text_field($new_instance['address_title']);
        $instance['office_address'] = sanitize_textarea_field($new_instance['office_address']);
        $instance['phone_label'] = sanitize_text_field($new_instance['phone_label']);
        $instance['phone_number'] = sanitize_text_field($new_instance['phone_number']);
        $instance['tel_number'] = sanitize_text_field($new_instance['tel_number']);
        $instance['email_address'] = sanitize_email($new_instance['email_address']);
        $instance['additional_label'] = sanitize_text_field($new_instance['additional_label']);
        $instance['additional_info'] = sanitize_textarea_field($new_instance['additional_info']);
        
        return $instance;
    }
}