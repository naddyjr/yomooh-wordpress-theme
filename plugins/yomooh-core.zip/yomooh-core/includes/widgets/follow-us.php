<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class Yomooh_Social_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct(
            'yomooh_social_widget',
            __('Yomooh Social Follow', 'yomooh-core'),
            array(
                'description' => __('Display social media links with icons.', 'yomooh-core'),
                'customize_selective_refresh' => true,
            )
        );
    }

    public function widget($args, $instance) {
        $title = apply_filters('widget_title', empty($instance['title']) ? __('Find Us on Socials', 'yomooh-core') : $instance['title'], $instance, $this->id_base);
        $align = empty($instance['align']) ? 'center' : $instance['align'];
        $new_tab = !empty($instance['new_tab']);
        
        // Social URLs
        $social_platforms = array(
            'facebook', 'twitter', 'youtube', 'googlenews', 'instagram', 'pinterest', 
            'linkedin', 'medium', 'flipboard', 'twitch', 'steam', 'tumblr', 'discord', 
            'flickr', 'skype', 'snapchat', 'quora', 'spotify', 'applepodcasts', 
            'googlepodcasts', 'stitcher', 'myspace', 'bloglovin', 'digg', 'dribbble', 
            'soundcloud', 'vimeo', 'reddit', 'vkontakte', 'telegram', 'whatsapp', 
            'truthsocial', 'paypal', 'patreon', 'threads', 'bluesky', 'rss'
        );

        echo $args['before_widget'];

        if ($title) {
            echo $args['before_title'] . esc_html($title) . $args['after_title'];
        }

        $target = $new_tab ? 'target="_blank" rel="noopener noreferrer"' : '';
        
        echo '<div class="yomooh-wd-social-widget align-' . esc_attr($align) . '">';
        echo '<div class="wd-social-icons">';

        foreach ($social_platforms as $platform) {
            $url = empty($instance[$platform . '_url']) ? '' : $instance[$platform . '_url'];
            if ($url) {
                echo '<a href="' . esc_url($url) . '" class="wd-social-icon ' . esc_attr($platform) . '" ' . $target . '>';
                echo $this->get_social_icon($platform);
                echo '</a>';
            }
        }

        echo '</div>'; // .social-icons
        echo '</div>'; 
        
        echo $args['after_widget'];
    }

    private function get_social_icon($platform) {
        $icons = array(
            'facebook' => 'fab fa-facebook-f',
            'twitter' => 'fab fa-twitter',
            'youtube' => 'fab fa-youtube',
            'googlenews' => 'fab fa-google',
            'instagram' => 'fab fa-instagram',
            'pinterest' => 'fab fa-pinterest-p',
            'linkedin' => 'fab fa-linkedin-in',
            'medium' => 'fab fa-medium-m',
            'flipboard' => 'fab fa-flipboard',
            'twitch' => 'fab fa-twitch',
            'steam' => 'fab fa-steam',
            'tumblr' => 'fab fa-tumblr',
            'discord' => 'fab fa-discord',
            'flickr' => 'fab fa-flickr',
            'skype' => 'fab fa-skype',
            'snapchat' => 'fab fa-snapchat-ghost',
            'quora' => 'fab fa-quora',
            'spotify' => 'fab fa-spotify',
            'applepodcasts' => 'fab fa-apple',
            'googlepodcasts' => 'fab fa-google-play',
            'stitcher' => 'fas fa-podcast',
            'myspace' => 'wpi-myspace',
            'bloglovin' => 'fas fa-heart',
            'digg' => 'fab fa-digg',
            'dribbble' => 'fab fa-dribbble',
            'soundcloud' => 'fab fa-soundcloud',
            'vimeo' => 'fab fa-vimeo-v',
            'reddit' => 'fab fa-reddit-alien',
            'vkontakte' => 'fab fa-vk',
            'telegram' => 'fab fa-telegram-plane',
            'whatsapp' => 'fab fa-whatsapp',
            'truthsocial' => 'fas fa-comment-alt',
            'paypal' => 'fab fa-paypal',
            'patreon' => 'fab fa-patreon',
            'threads' => 'wpi-comment',
            'bluesky' => 'fas fa-cloud',
            'rss' => 'fas fa-rss'
        );

        return '<i class="' . esc_attr($icons[$platform]) . '"></i>';
    }

    public function form($instance) {
        $defaults = array(
            'title' => __('Find Us on Socials', 'yomooh-core'),
            'align' => 'center',
            'new_tab' => true,
            // Initialize all social URLs as empty
            'facebook_url' => '',
            'twitter_url' => '',
            'youtube_url' => '',
            'googlenews_url' => '',
            'instagram_url' => '',
            'pinterest_url' => '',
            'linkedin_url' => '',
            'medium_url' => '',
            'flipboard_url' => '',
            'twitch_url' => '',
            'steam_url' => '',
            'tumblr_url' => '',
            'discord_url' => '',
            'flickr_url' => '',
            'skype_url' => '',
            'snapchat_url' => '',
            'quora_url' => '',
            'spotify_url' => '',
            'applepodcasts_url' => '',
            'googlepodcasts_url' => '',
            'stitcher_url' => '',
            'myspace_url' => '',
            'bloglovin_url' => '',
            'digg_url' => '',
            'dribbble_url' => '',
            'soundcloud_url' => '',
            'vimeo_url' => '',
            'reddit_url' => '',
            'vkontakte_url' => '',
            'telegram_url' => '',
            'whatsapp_url' => '',
            'truthsocial_url' => '',
            'paypal_url' => '',
            'patreon_url' => '',
            'threads_url' => '',
            'bluesky_url' => '',
            'rss_url' => ''
        );

        $instance = wp_parse_args((array) $instance, $defaults);
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:', 'yomooh-core'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" 
                   name="<?php echo $this->get_field_name('title'); ?>" 
                   type="text" value="<?php echo esc_attr($instance['title']); ?>" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('align'); ?>"><?php _e('Align Content:', 'yomooh-core'); ?></label>
            <select class="widefat" id="<?php echo $this->get_field_id('align'); ?>" name="<?php echo $this->get_field_name('align'); ?>">
                <option value="left" <?php selected($instance['align'], 'left'); ?>><?php _e('Left', 'yomooh-core'); ?></option>
                <option value="center" <?php selected($instance['align'], 'center'); ?>><?php _e('Center', 'yomooh-core'); ?></option>
                <option value="right" <?php selected($instance['align'], 'right'); ?>><?php _e('Right', 'yomooh-core'); ?></option>
            </select>
        </p>

        <p>
            <input class="checkbox" type="checkbox" id="<?php echo $this->get_field_id('new_tab'); ?>" name="<?php echo $this->get_field_name('new_tab'); ?>" <?php checked($instance['new_tab'], true); ?> />
            <label for="<?php echo $this->get_field_id('new_tab'); ?>"><?php _e('Open links in new tab', 'yomooh-core'); ?></label>
        </p>

        <h4><?php _e('Social Media URLs', 'yomooh-core'); ?></h4>
        
        <?php
        $social_platforms = array(
            'Facebook' => 'facebook_url',
            'X (Twitter)' => 'twitter_url',
            'YouTube' => 'youtube_url',
            'Google News' => 'googlenews_url',
            'Instagram' => 'instagram_url',
            'Pinterest' => 'pinterest_url',
            'LinkedIn' => 'linkedin_url',
            'Medium' => 'medium_url',
            'Flipboard' => 'flipboard_url',
            'Twitch' => 'twitch_url',
            'Steam' => 'steam_url',
            'Tumblr' => 'tumblr_url',
            'Discord' => 'discord_url',
            'Flickr' => 'flickr_url',
            'Skype' => 'skype_url',
            'Snapchat' => 'snapchat_url',
            'Quora' => 'quora_url',
            'Spotify' => 'spotify_url',
            'Apple Podcasts' => 'applepodcasts_url',
            'Google Podcasts' => 'googlepodcasts_url',
            'Stitcher' => 'stitcher_url',
            'Myspace' => 'myspace_url',
            'Bloglovin' => 'bloglovin_url',
            'Digg' => 'digg_url',
            'Dribbble' => 'dribbble_url',
            'SoundCloud' => 'soundcloud_url',
            'Vimeo' => 'vimeo_url',
            'Reddit' => 'reddit_url',
            'VKontakte' => 'vkontakte_url',
            'Telegram' => 'telegram_url',
            'WhatsApp' => 'whatsapp_url',
            'Truth Social' => 'truthsocial_url',
            'PayPal' => 'paypal_url',
            'Patreon' => 'patreon_url',
            'Threads' => 'threads_url',
            'Bluesky' => 'bluesky_url',
            'RSS' => 'rss_url'
        );

        foreach ($social_platforms as $label => $field) {
            echo '<p>';
            echo '<label for="' . $this->get_field_id($field) . '">' . $label . ' URL:</label>';
            echo '<input class="widefat" id="' . $this->get_field_id($field) . '" name="' . $this->get_field_name($field) . '" type="url" value="' . esc_url($instance[$field]) . '" placeholder="https://" />';
            echo '</p>';
        }
    }

    public function update($new_instance, $old_instance) {
        $instance = $old_instance;
        $instance['title'] = sanitize_text_field($new_instance['title']);
        $instance['align'] = in_array($new_instance['align'], array('left', 'center', 'right')) ? $new_instance['align'] : 'center';
        $instance['new_tab'] = isset($new_instance['new_tab']) ? (bool) $new_instance['new_tab'] : false;
        
        // Sanitize all social URLs
        $social_fields = array(
            'facebook_url', 'twitter_url', 'youtube_url', 'googlenews_url', 'instagram_url', 'pinterest_url',
            'linkedin_url', 'medium_url', 'flipboard_url', 'twitch_url', 'steam_url', 'tumblr_url', 'discord_url',
            'flickr_url', 'skype_url', 'snapchat_url', 'quora_url', 'spotify_url', 'applepodcasts_url',
            'googlepodcasts_url', 'stitcher_url', 'myspace_url', 'bloglovin_url', 'digg_url', 'dribbble_url',
            'soundcloud_url', 'vimeo_url', 'reddit_url', 'vkontakte_url', 'telegram_url', 'whatsapp_url',
            'truthsocial_url', 'paypal_url', 'patreon_url', 'threads_url', 'bluesky_url', 'rss_url'
        );
        
        foreach ($social_fields as $field) {
            $instance[$field] = esc_url_raw($new_instance[$field]);
        }
        
        return $instance;
    }
}