<?php
/**
 * Plugin Name: Yomooh Core
 * Plugin URI: https://somnest.net
 * Description: Unlock the full power of the Yomooh theme with essential features, custom widgets, and advanced theme options. This plugin is required for the theme to function properly.
 * Version: 1.0.0
 * Author: Somnest
 * Author URI: https://somnest.net
 * Text Domain: yomooh-core
 * License: GPL-2.0+
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Domain Path: /languages
 */
use Yomooh\baseClasses\Activate;
use Yomooh\baseClasses\Deactivate;

defined('ABSPATH') || exit;

// Define constants
define('YOMOOH_NAME', 'yomooh-core');
define('YOMOOH_TEXT_DOMAIN', 'yomooh-core');
if (!defined('YOMOOH_NAMESPACE')) {
    define('YOMOOH_NAMESPACE', "yomooh-core");
}

if (!defined('YOMOOH_PREFIX')) {
    define('YOMOOH_PREFIX', "ymh_");
}
define('YOMOOH_VERSION', '1.0.0');
define('YOMOOH_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('YOMOOH_PLUGIN_URL', plugin_dir_url(__FILE__));
define('YOMOOH_PLUGIN_BASENAME', plugin_basename(__FILE__));
/**
 * Check if the active theme is Yomooh
 */
function is_yomooh_theme_active() {
    $theme = wp_get_theme();
    $parent_theme = $theme->parent();
    
    // Check current theme
    if ('Yomooh' === $theme->get('Name')) {
        return true;
    }
    
    // Check parent theme if it exists
    if ($parent_theme instanceof WP_Theme && 'Yomooh' === $parent_theme->get('Name')) {
        return true;
    }
    
    return false;
}
/**
 * Show admin notice if Yomooh theme is not active
 */
function yomooh_theme_requirement_notice() {
    if (!is_yomooh_theme_active() && current_user_can('activate_plugins')) {
        echo '
        <div class="notice notice-error is-dismissible">
            <p><strong>Yomooh Core Plugin:</strong> This plugin works only with the Yomooh theme. Please activate the Yomooh theme to use all features.</p>
        </div>';
    }
}
add_action('admin_notices', 'yomooh_theme_requirement_notice');
// Require once the Composer Autoload
if (file_exists(dirname(__FILE__) . '/vendor/autoload.php')) {
    require_once dirname(__FILE__) . '/vendor/autoload.php';
} else {
    wp_die('yomooh-core Plugin failed to load. Please run composer install.');
}

// Load files
function yomooh_load_theme_files() {
  if (is_yomooh_theme_active()) {
require_once YOMOOH_PLUGIN_DIR . 'includes/elementor/template/class-yomooh-templates.php';
require_once YOMOOH_PLUGIN_DIR . 'includes/Backend/metaboxes/metaboxes.php';
require_once YOMOOH_PLUGIN_DIR . 'includes/Backend/common/dashboard.php';
require_once YOMOOH_PLUGIN_DIR . 'includes/widgets/posts.php';
require_once YOMOOH_PLUGIN_DIR . 'includes/widgets/author.php';
require_once YOMOOH_PLUGIN_DIR . 'includes/widgets/banner.php';
require_once YOMOOH_PLUGIN_DIR . 'includes/widgets/address.php';
require_once YOMOOH_PLUGIN_DIR . 'includes/widgets/follow-us.php';
require_once YOMOOH_PLUGIN_DIR . 'includes/widgets/connect-us.php';
require_once YOMOOH_PLUGIN_DIR . 'includes/widgets/stats.php';
require_once YOMOOH_PLUGIN_DIR . 'includes/widgets/ad-script.php';
require_once YOMOOH_PLUGIN_DIR . 'includes/widgets/newsletter.php';
 }
}
add_action('plugins_loaded', 'yomooh_load_theme_files', 10);
/**
 * Load plugin textdomain
 */
function yomooh_load_textdomain() {
    load_plugin_textdomain(
        'yomooh-core',
        false,
        dirname(plugin_basename(__FILE__)) . '/languages/'
    );
}
add_action('plugins_loaded', 'yomooh_load_textdomain', 5); 

// Load Elementor widgets base
if (is_yomooh_theme_active()) {
add_action('plugins_loaded', function () {
    if (did_action('elementor/loaded')) {
        require_once YOMOOH_PLUGIN_DIR . 'includes/elementor/widgets/base.php';
    }
});
}
// Enqueue shared styles
function yomooh_enqueue_frontend_assets() {
    if ( ! is_yomooh_theme_active() ) return;
    wp_enqueue_style(
            'font-awesome-5',
            'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css',
            [],
            '5.15.4'
        );

    // Condition: Elementor page or relevant widget is active
    if ( yomooh_is_elementor_page() || is_active_widget(false, false, 'yomooh_posts_widget', true) || is_admin() ) {
        // Swiper
        wp_enqueue_style('swiper', YOMOOH_PLUGIN_URL . 'assets/swiper/swiper-bundle.min.css', [], YOMOOH_VERSION);
        wp_enqueue_script('swiper', YOMOOH_PLUGIN_URL . 'assets/swiper/swiper-bundle.min.js', [], YOMOOH_VERSION, true);
    }
}
add_action('wp_enqueue_scripts', 'yomooh_enqueue_frontend_assets');

function yomooh_is_elementor_page() {
    if ( ! class_exists('\Elementor\Plugin') ) {
        return false;
    }

    if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
        return true;
    }

    if ( is_singular() && \Elementor\Plugin::$instance->db->is_built_with_elementor(get_the_ID()) ) {
        return true;
    }

    return false;
}

add_action('elementor/editor/before_enqueue_scripts', 'yomooh_enqueue_frontend_assets');

/**
 * Defer slider JS
 */
add_filter('script_loader_tag', function ($tag, $handle) {
    if (in_array($handle, ['swiper', 'elementor-slider'])) {
        return str_replace(' src', ' defer src', $tag);
    }
    return $tag;
}, 10, 2);

/**
 * ADMIN styles
 */
add_action('admin_enqueue_scripts', function () {
    wp_enqueue_style('yomooh-dashboard', YOMOOH_PLUGIN_URL . 'assets/css/dashboard.min.css', [], YOMOOH_VERSION);
    wp_enqueue_style('yomooh-mcpv', YOMOOH_PLUGIN_URL . 'assets/css/mcpv.css', [], YOMOOH_VERSION);
});


// Register widgets
function register_yomooh_widgets() {
    if (is_yomooh_theme_active()) {
    register_widget('Yomooh_Posts_Widget');
    register_widget('Yomooh_Author_Widget');
	register_widget('Yomooh_Banner_Widget');
	register_widget('Yomooh_Address_Widget');
	register_widget('Yomooh_Social_Widget');
	register_widget('Yomooh_Social_Connect_Widget');
	register_widget('Yomooh_Stats_Widget');
	register_widget('Yomooh_Ad_Script_Widget');
	register_widget('Yomooh_Newsletter_Widget');
}
}
add_action('widgets_init', 'register_yomooh_widgets');

//  activation/deactivation hooks
register_activation_hook(__FILE__, [Activate::class, 'activate']);
register_deactivation_hook(__FILE__, [Deactivate::class, 'init']);

// Initialize the plugin
(new Activate())->init();
