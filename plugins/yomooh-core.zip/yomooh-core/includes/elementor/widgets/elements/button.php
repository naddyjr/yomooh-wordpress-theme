<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;

if (!defined('ABSPATH')) exit;

class Yomooh_Widget_Button extends Widget_Base {

    public function get_name() {
        return 'yomooh_button';
    }

    public function get_title() {
        return __('Yomooh Button', 'yomooh-core');
    }

    public function get_icon() {
        return 'eicon-button';
    }

    public function get_categories() {
        return ['yomooh-elements'];
    }

    protected function register_controls() {
        // Content Tab
        $this->start_controls_section('content_section', [
            'label' => __('Content', 'yomooh-core'),
            'tab' => Controls_Manager::TAB_CONTENT,
        ]);

        $this->add_control('button_type', [
            'label' => __('Button Type', 'yomooh-core'),
            'type' => Controls_Manager::SELECT,
            'default' => 'default',
            'options' => [
                'default' => __('Default', 'yomooh-core'),
                'info' => __('Info', 'yomooh-core'),
                'success' => __('Success', 'yomooh-core'),
                'warning' => __('Warning', 'yomooh-core'),
                'danger' => __('Danger', 'yomooh-core'),
                'light' => __('Light', 'yomooh-core'),
                'dark' => __('Dark', 'yomooh-core'),
                'link' => __('Link', 'yomooh-core'),
            ],
        ]);

        $this->add_control('button_text', [
            'label' => __('Button Text', 'yomooh-core'),
            'type' => Controls_Manager::TEXT,
            'default' => __('Click Here', 'yomooh-core'),
            'placeholder' => __('Enter button text', 'yomooh-core'),
        ]);

        $this->add_control('button_link', [
            'label' => __('Link', 'yomooh-core'),
            'type' => Controls_Manager::URL,
            'placeholder' => __('https://your-link.com', 'yomooh-core'),
            'default' => [
                'url' => '#',
            ],
        ]);

        $this->add_control('button_icon', [
            'label' => __('Icon', 'yomooh-core'),
            'type' => Controls_Manager::ICONS,
            'fa4compatibility' => 'icon',
        ]);

        $this->add_control('icon_position', [
            'label' => __('Icon Position', 'yomooh-core'),
            'type' => Controls_Manager::SELECT,
            'default' => 'left',
            'options' => [
                'left' => __('Left', 'yomooh-core'),
                'right' => __('Right', 'yomooh-core'),
            ],
            'condition' => [
                'button_icon[value]!' => '',
            ],
        ]);

        $this->add_control('icon_spacing', [
            'label' => __('Icon Spacing', 'yomooh-core'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => ['min' => 0, 'max' => 50],
            ],
            'default' => ['size' => 8],
            'selectors' => [
                '{{WRAPPER}} .yomooh-button-icon-left .yomooh-button-icon' => 'margin-right: {{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .yomooh-button-icon-right .yomooh-button-icon' => 'margin-left: {{SIZE}}{{UNIT}};',
            ],
            'condition' => [
                'button_icon[value]!' => '',
            ],
        ]);

        $this->end_controls_section();

        // Style Tab
        $this->start_controls_section('style_section', [
            'label' => __('Style', 'yomooh-core'),
            'tab' => Controls_Manager::TAB_STYLE,
        ]);

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'button_typography',
                'selector' => '{{WRAPPER}} .yomooh-button',
            ]
        );

        $this->add_responsive_control('button_padding', [
            'label' => __('Padding', 'yomooh-core'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%', 'em'],
            'selectors' => [
                '{{WRAPPER}} .yomooh-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->add_responsive_control('button_border_radius', [
            'label' => __('Border Radius', 'yomooh-core'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%'],
            'selectors' => [
                '{{WRAPPER}} .yomooh-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        // Normal State
        $this->start_controls_tabs('button_tabs');

        $this->start_controls_tab('button_normal', [
            'label' => __('Normal', 'yomooh-core'),
        ]);

        $this->add_control('button_text_color', [
            'label' => __('Text Color', 'yomooh-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .yomooh-button' => 'color: {{VALUE}};',
                '{{WRAPPER}} .yomooh-button .yomooh-button-icon' => 'color: {{VALUE}}; fill: {{VALUE}};',
            ],
        ]);

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'button_bg',
                'label' => __('Background', 'yomooh-core'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .yomooh-button',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'button_border',
                'selector' => '{{WRAPPER}} .yomooh-button',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_box_shadow',
                'selector' => '{{WRAPPER}} .yomooh-button',
            ]
        );

        $this->end_controls_tab();

        // Hover State
        $this->start_controls_tab('button_hover', [
            'label' => __('Hover', 'yomooh-core'),
        ]);

        $this->add_control('button_text_color_hover', [
            'label' => __('Text Color', 'yomooh-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .yomooh-button:hover' => 'color: {{VALUE}};',
                '{{WRAPPER}} .yomooh-button:hover .yomooh-button-icon' => 'color: {{VALUE}}; fill: {{VALUE}};',
            ],
        ]);

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'button_bg_hover',
                'label' => __('Background', 'yomooh-core'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .yomooh-button:hover',
            ]
        );

        $this->add_control('button_border_color_hover', [
            'label' => __('Border Color', 'yomooh-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .yomooh-button:hover' => 'border-color: {{VALUE}};',
            ],
        ]);

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_box_shadow_hover',
                'selector' => '{{WRAPPER}} .yomooh-button:hover',
            ]
        );

        $this->add_control('button_hover_animation', [
            'label' => __('Hover Animation', 'yomooh-core'),
            'type' => Controls_Manager::HOVER_ANIMATION,
        ]);

        $this->end_controls_tab();
        $this->end_controls_tabs();

        // Icon Style
        $this->add_control('icon_style_heading', [
            'label' => __('Icon Style', 'yomooh-core'),
            'type' => Controls_Manager::HEADING,
            'separator' => 'before',
            'condition' => [
                'button_icon[value]!' => '',
            ],
        ]);

        $this->add_responsive_control('icon_size', [
            'label' => __('Icon Size', 'yomooh-core'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => ['min' => 6, 'max' => 50],
            ],
            'default' => ['size' => 14],
            'selectors' => [
                '{{WRAPPER}} .yomooh-button-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .yomooh-button-icon svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
            ],
            'condition' => [
                'button_icon[value]!' => '',
            ],
        ]);

        $this->end_controls_section();

        // Position Section
        $this->start_controls_section('position_section', [
            'label' => __('Position', 'yomooh-core'),
            'tab' => Controls_Manager::TAB_STYLE,
        ]);

        $this->add_responsive_control('button_align', [
            'label' => __('Alignment', 'yomooh-core'),
            'type' => Controls_Manager::CHOOSE,
            'options' => [
                'left' => [
                    'title' => __('Left', 'yomooh-core'),
                    'icon' => 'eicon-text-align-left',
                ],
                'center' => [
                    'title' => __('Center', 'yomooh-core'),
                    'icon' => 'eicon-text-align-center',
                ],
                'right' => [
                    'title' => __('Right', 'yomooh-core'),
                    'icon' => 'eicon-text-align-right',
                ],
            ],
            'default' => 'left',
            'selectors' => [
                '{{WRAPPER}} .yomooh-button-wrapper' => 'text-align: {{VALUE}};',
            ],
        ]);

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $has_icon = !empty($settings['button_icon']['value']);

        $this->add_render_attribute('button', 'class', [
            'yomooh-button',
            'yomooh-button-' . $settings['button_type'],
            $has_icon ? 'yomooh-button-icon-' . $settings['icon_position'] : '',
            !empty($settings['button_hover_animation']) ? 'elementor-animation-' . $settings['button_hover_animation'] : '',
        ]);

        $this->add_render_attribute('button', 'href', $settings['button_link']['url']);

        if ($settings['button_link']['is_external']) {
            $this->add_render_attribute('button', 'target', '_blank');
        }

        if ($settings['button_link']['nofollow']) {
            $this->add_render_attribute('button', 'rel', 'nofollow');
        }
        ?>
        <div class="yomooh-button-wrapper">
            <a <?php echo $this->get_render_attribute_string('button'); ?>>
                <?php if ($has_icon && $settings['icon_position'] === 'left') : ?>
                    <span class="yomooh-button-icon">
                        <?php Icons_Manager::render_icon($settings['button_icon'], ['aria-hidden' => 'true']); ?>
                    </span>
                <?php endif; ?>

                <span class="yomooh-button-text"><?php echo esc_html($settings['button_text']); ?></span>

                <?php if ($has_icon && $settings['icon_position'] === 'right') : ?>
                    <span class="yomooh-button-icon">
                        <?php Icons_Manager::render_icon($settings['button_icon'], ['aria-hidden' => 'true']); ?>
                    </span>
                <?php endif; ?>
            </a>
        </div>
        <?php
    }
}