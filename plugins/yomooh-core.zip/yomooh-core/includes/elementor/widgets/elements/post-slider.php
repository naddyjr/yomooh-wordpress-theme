<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Image_Size;
if (!defined('ABSPATH')) exit;

class Yomooh_Post_Carousel_Slider_Widget extends Widget_Base {

    public function get_name() {
        return 'post-carousel-slider';
    }

    public function get_title() {
        return __('Post Carousel Slider', 'yomooh-core');
    }

    public function get_icon() {
        return 'eicon-posts-carousel';
    }

    public function get_categories() {
        return ['yomooh-elements'];
    }
    public function get_script_depends() {
    return ['swiper'];
	}

	public function get_style_depends() {
		return ['swiper'];
	}

    protected function _register_controls() {
        // Content Tab
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Content', 'yomooh-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'post_type',
            [
                'label' => __('Post Type', 'yomooh-core'),
                'type' => Controls_Manager::SELECT,
                'options' => $this->get_post_types(),
                'default' => 'post',
            ]
        );
         $this->add_control(
            'post_format',
            [
                'label' => __('Post Format', 'yomooh-core'),
                'type' => Controls_Manager::SELECT,
                'default' => '',
                'options' => [
                    '' => __('All', 'yomooh-core'),
                    'standard' => __('Standard', 'yomooh-core'),
                    'video' => __('Video', 'yomooh-core'),
                    'audio' => __('Audio', 'yomooh-core'),
                    'gallery' => __('Gallery', 'yomooh-core'),
                ],
            ]
        );
        $this->add_control(
            'author_filter',
            [
                'label' => __('Author Filter', 'yomooh-core'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'multiple' => true,
                'options' => $this->get_authors(),
            ]
        );

        $this->add_control(
            'category_filter',
            [
                'label' => __('Category Filter', 'yomooh-core'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'multiple' => true,
                'options' => $this->get_post_categories(),
            ]
        );

        $this->add_control(
            'exclude_categories',
            [
                'label' => __('Exclude Category IDs', 'yomooh-core'),
                'type' => Controls_Manager::TEXT,
                'description' => __('Comma separated list of category IDs to exclude', 'yomooh-core'),
            ]
        );

        $this->add_control(
            'exclude_posts',
            [
                'label' => __('Exclude Post IDs', 'yomooh-core'),
                'type' => Controls_Manager::TEXT,
                'description' => __('Comma separated list of post IDs to exclude', 'yomooh-core'),
            ]
        );

        $this->add_control(
            'posts_per_page',
            [
                'label' => __('Number of Posts', 'yomooh-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => 6,
                'min' => 1,
                'max' => 50,
            ]
        );

        $this->add_control(
            'orderby',
            [
                'label' => __('Order By', 'yomooh-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'date' => __('Date', 'yomooh-core'),
                    'title' => __('Title', 'yomooh-core'),
                    'rand' => __('Random', 'yomooh-core'),
                    'menu_order' => __('Menu Order', 'yomooh-core'),
                ],
                'default' => 'date',
            ]
        );

        $this->add_control(
            'order',
            [
                'label' => __('Order', 'yomooh-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'ASC' => __('Ascending', 'yomooh-core'),
                    'DESC' => __('Descending', 'yomooh-core'),
                ],
                'default' => 'DESC',
            ]
        );

        $this->end_controls_section();

        // Slider Settings Tab
        $this->start_controls_section(
            'slider_settings',
            [
                'label' => __('Slider Settings', 'yomooh-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'slides_per_view',
            [
                'label' => __('Slides Per View (Desktop)', 'yomooh-core'),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 6,
                'step' => 1,
                'default' => 2,
            ]
        );

        $this->add_control(
            'slides_per_view_tablet',
            [
                'label' => __('Slides Per View (Tablet)', 'yomooh-core'),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 4,
                'step' => 1,
                'default' => 2,
            ]
        );

        $this->add_control(
            'slides_per_view_mobile',
            [
                'label' => __('Slides Per View (Mobile)', 'yomooh-core'),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 2,
                'step' => 1,
                'default' => 1,
            ]
        );

        $this->add_control(
            'space_between',
            [
                'label' => __('Space Between Slides', 'yomooh-core'),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 100,
                'step' => 5,
                'default' => 30,
            ]
        );

        $this->add_control(
            'autoplay',
            [
                'label' => __('Autoplay', 'yomooh-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'yomooh-core'),
                'label_off' => __('No', 'yomooh-core'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'autoplay_speed',
            [
                'label' => __('Autoplay Speed (ms)', 'yomooh-core'),
                'type' => Controls_Manager::NUMBER,
                'min' => 100,
                'max' => 10000,
                'step' => 100,
                'default' => 3000,
                'condition' => [
                    'autoplay' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'loop',
            [
                'label' => __('Infinite Loop', 'yomooh-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'yomooh-core'),
                'label_off' => __('No', 'yomooh-core'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'show_arrows',
            [
                'label' => __('Show Navigation Arrows', 'yomooh-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'yomooh-core'),
                'label_off' => __('Hide', 'yomooh-core'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'show_dots',
            [
                'label' => __('Show Pagination Dots', 'yomooh-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'yomooh-core'),
                'label_off' => __('Hide', 'yomooh-core'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->end_controls_section();

        // Style Tab
        $this->start_controls_section(
            'image_style_section',
            [
                'label' => __('Image Style', 'yomooh-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_responsive_control(
            'image_width',
            [
                'label' => __('Width', 'yomooh-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 100,
                        'max' => 1000,
                    ],
                    '%' => [
                        'min' => 10,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .post-carousel-slider-image' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'image_height',
            [
                'label' => __('Image Height', 'yomooh-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 100,
                        'max' => 1000,
                        'step' => 5,
                    ],
                    '%' => [
                        'min' => 10,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 300,
                ],
                'selectors' => [
                    '{{WRAPPER}} .post-carousel-slider-image' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'image_border',
                'selector' => '{{WRAPPER}} .post-carousel-slider-image',
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'image_border_radius',
            [
                'label' => __('Border Radius', 'yomooh-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .post-carousel-slider-image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'image_box_shadow',
                'selector' => '{{WRAPPER}} .post-carousel-slider-image',
            ]
        );
		$this->add_responsive_control(
            'feature_spacing',
            [
                'label' => __('Spacing', 'yomooh-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .post-carousel-slider-image' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Title Style
        $this->start_controls_section(
            'title_style_section',
            [
                'label' => __('Title Style', 'yomooh-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __('Color', 'yomooh-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .post-carousel-slider-title a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'title_hover_color',
            [
                'label' => __('Hover Color', 'yomooh-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .post-carousel-slider-title a:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .post-carousel-slider-title',
            ]
        );

        $this->add_control(
            'title_margin',
            [
                'label' => __('Margin', 'yomooh-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .post-carousel-slider-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'title_alignment',
            [
                'label' => __('Alignment', 'yomooh-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'yomooh-core'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'yomooh-core'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'yomooh-core'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'left',
                'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .post-carousel-slider-title' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();
        // Meta Settings
        $this->start_controls_section(
            'meta_section',
            [
                'label' => __('Meta Settings', 'yomooh-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        // Meta Items
        $this->add_control(
            'meta_items',
            [
                'label' => __('Meta Items', 'yomooh-core'),
                'description' => __('Enter meta items to display, separated by commas. Available: avatar, author, date, category, tag, comment, update, read', 'yomooh-core'),
                'type' => Controls_Manager::TEXT,
                'default' => 'author,date,category',
                'label_block' => true,
            ]
        );

        // Meta Position
        $this->add_control(
            'meta_position',
            [
                'label' => __('Meta Position', 'yomooh-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'before_title' => __('Before Title', 'yomooh-core'),
                    'after_title' => __('After Title', 'yomooh-core'),
                ],
                'default' => 'after_title',
            ]
        );
        // Meta Display Style
		$this->add_control(
			'meta_display',
			[
				'label' => __('Display Style', 'yomooh-core'),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'inline' => __('Inline', 'yomooh-core'),
					'block' => __('Block', 'yomooh-core'),
				],
				'default' => 'inline',
			]
		);

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'meta_typography',
                'selector' => '{{WRAPPER}} .post-carousel-meta',
            ]
        );

        $this->add_control(
            'meta_color',
            [
                'label' => __('Color', 'yomooh-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .post-carousel-meta' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'meta_link_color',
            [
                'label' => __('Link Color', 'yomooh-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .post-carousel-meta a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'meta_link_hover_color',
            [
                'label' => __('Link Hover Color', 'yomooh-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .post-carousel-meta a:hover' => 'color: {{VALUE}};',
                ],
            ]
        );
		// In the meta_style section:
			$this->add_control(
				'meta_divider_style',
				[
					'label' => __('Divider Style', 'yomooh-core'),
					'type' => Controls_Manager::SELECT,
					'options' => [
						'none' => __('None', 'yomooh-core'),
						'slash' => __('Slash (/)', 'yomooh-core'),
						'pipe' => __('Pipe (|)', 'yomooh-core'),
						'heiven' => __('Heiven (-)', 'yomooh-core'),
						'dot' => __('Dot (•)', 'yomooh-core'),
					],
					'default' => 'dot',
					'selectors' => [
						'{{WRAPPER}} .post-carousel-meta-item' => 'divider-{{VALUE}}',
					],
				]
			);

        $this->add_responsive_control(
            'meta_spacing',
            [
                'label' => __('Spacing', 'yomooh-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .post-carousel-meta' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'meta_alignment',
            [
                'label' => __('Alignment', 'yomooh-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'yomooh-core'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'yomooh-core'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'yomooh-core'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'left',
                'selectors' => [
                    '{{WRAPPER}} .post-carousel-meta' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'meta_items_spacing',
            [
                'label' => __('Items Spacing', 'yomooh-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .post-carousel-meta-item:not(:last-child)' => 'margin-right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
        // background Style
        $this->start_controls_section(
            'bgcard_style',
            [
                'label' => __('Background', 'yomooh-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'bgcard_background',
                'label' => __('Background', 'yomooh-core'),
                'type' => Controls_Manager::COLOR,
				'selector' => '{{WRAPPER}} .post-carousel-slider-slide',
            ]
        );
		$this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'bgcard_border',
                'selector' => '{{WRAPPER}} .post-carousel-slider-slide',
            ]
        );

        $this->add_control(
            'bgcard_border_radius',
            [
                'label' => __('Border Radius', 'yomooh-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .post-carousel-slider-slide' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		 $this->end_controls_section();

        // Navigation Style
        $this->start_controls_section(
            'navigation_style_section',
            [
                'label' => __('Navigation Style', 'yomooh-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'arrow_size',
            [
                'label' => __('Arrow Size', 'yomooh-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 60,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 20,
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-button-next, {{WRAPPER}} .swiper-button-prev' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'show_arrows' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'arrow_color',
            [
                'label' => __('Arrow Color', 'yomooh-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .swiper-button-next, {{WRAPPER}} .swiper-button-prev' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'show_arrows' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'arrow_hover_color',
            [
                'label' => __('Arrow Hover Color', 'yomooh-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .swiper-button-next:hover, {{WRAPPER}} .swiper-button-prev:hover' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'show_arrows' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'dots_size',
            [
                'label' => __('Dots Size', 'yomooh-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 5,
                        'max' => 20,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 10,
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-pagination-bullet' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'show_dots' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'dots_color',
            [
                'label' => __('Dots Color', 'yomooh-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .swiper-pagination-bullet' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'show_dots' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'dots_active_color',
            [
                'label' => __('Active Dot Color', 'yomooh-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .swiper-pagination-bullet-active' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'show_dots' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        $args = [
            'post_type' => $settings['post_type'],
            'posts_per_page' => $settings['posts_per_page'],
            'orderby' => $settings['orderby'],
            'order' => $settings['order'],
        ];
        // Post format filter
    if (!empty($settings['post_format'])) {
        $args['tax_query'] = [
            [
                'taxonomy' => 'post_format',
                'field' => 'slug',
                'terms' => ['post-format-' . $settings['post_format']],
            ]
        ];
    }

    // Author filter
    if (!empty($settings['author_filter'])) {
        $args['author__in'] = $settings['author_filter'];
    }

    // Category filter
    if (!empty($settings['category_filter'])) {
        $args['category__in'] = $settings['category_filter'];
    }

    // Exclude categories
    if (!empty($settings['exclude_categories'])) {
        $exclude_cats = array_map('trim', explode(',', $settings['exclude_categories']));
        $args['category__not_in'] = $exclude_cats;
    }

    // Exclude posts
    if (!empty($settings['exclude_posts'])) {
        $exclude_posts = array_map('trim', explode(',', $settings['exclude_posts']));
        $args['post__not_in'] = $exclude_posts;
    }

        $query = new \WP_Query($args);

        if ($query->have_posts()) :
            $this->add_render_attribute('carousel', 'class', 'post-carousel-slider-wrapper');
            $this->add_render_attribute('carousel', 'data-settings', wp_json_encode([
                'slidesPerView' => $settings['slides_per_view'],
                'slidesPerViewTablet' => $settings['slides_per_view_tablet'],
                'slidesPerViewMobile' => $settings['slides_per_view_mobile'],
                'spaceBetween' => $settings['space_between'],
                'autoplay' => $settings['autoplay'] === 'yes' ? [
                    'delay' => $settings['autoplay_speed'],
                    'disableOnInteraction' => false,
                ] : false,
                'loop' => $settings['loop'] === 'yes',
                'navigation' => [
                    'nextEl' => '.swiper-button-next-' . $this->get_id(),
                    'prevEl' => '.swiper-button-prev-' . $this->get_id(),
                ],
                'pagination' => [
                    'el' => '.swiper-pagination-' . $this->get_id(),
                    'clickable' => true,
                ],
            ]));
            ?>
            <div <?php echo $this->get_render_attribute_string('carousel'); ?>>
                <div class="swiper-container post-carousel-slider-container">
                    <div class="swiper-wrapper">
                        <?php while ($query->have_posts()) : $query->the_post(); ?>
                            <div class="swiper-slide post-carousel-slider-slide">
                                <?php if (has_post_thumbnail()) : ?>
                                    <div class="post-carousel-slider-image">
                                        <a href="<?php the_permalink(); ?>">
                                            <?php the_post_thumbnail('large'); ?>
                                        </a>
                                    </div>
                                <?php endif; ?>
                                 <?php if ($settings['meta_position'] === 'before_title') : ?>
                            <?php $this->render_meta(get_the_ID(), $settings['meta_items']); ?>
                        <?php endif; ?>
                                <h3 class="post-carousel-slider-title">
                                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                </h3>
                                <?php if ($settings['meta_position'] === 'after_title') : ?>
                            <?php $this->render_meta(get_the_ID(), $settings['meta_items']); ?>
                        <?php endif; ?>
                            </div>
                        <?php endwhile; ?>
                    </div>

                    <?php if ($settings['show_dots'] === 'yes') : ?>
                        <div class="swiper-pagination swiper-pagination-<?php echo $this->get_id(); ?>"></div>
                    <?php endif; ?>

                    <?php if ($settings['show_arrows'] === 'yes') : ?>
                        <div class="swiper-button-next swiper-button-next-<?php echo $this->get_id(); ?>"></div>
                        <div class="swiper-button-prev swiper-button-prev-<?php echo $this->get_id(); ?>"></div>
                    <?php endif; ?>
                </div>
            </div>
            <?php
            wp_reset_postdata();
        else :
            echo '<p>' . __('No posts found', 'yomooh-core') . '</p>';
        endif;
    }
    protected function render_meta($post_id, $meta_items) {
    if (empty($meta_items)) {
        return;
    }
    
    $items = array_map('trim', explode(',', $meta_items));
    $output = [];
    $settings = $this->get_settings_for_display();
    
    foreach ($items as $item) {
        $divider_style = isset($settings['meta_divider_style']) ? $settings['meta_divider_style'] : 'dot';
        $meta_class = 'post-carousel-meta-item divider-' . $divider_style;
        
        switch ($item) {
            case 'avatar':
                $output[] = '<span class="' . $meta_class . ' post-meta-avatar">' . get_avatar(get_the_author_meta('ID'), 32) . '</span>';
                break;
                
            case 'author':
                $output[] = '<span class="' . $meta_class . ' post-meta-author">' . 
                            '<a href="' . get_author_posts_url(get_the_author_meta('ID')) . '">' . 
                            get_the_author() . '</a></span>';
                break;
                
            case 'date':
                $output[] = '<span class="' . $meta_class . ' post-meta-date">' . 
                            get_the_date() . '</span>';
                break;
                
            case 'category':
                $categories = get_the_category($post_id);
                if (!empty($categories)) {
                    $category_links = [];
                    foreach ($categories as $category) {
                        $category_links[] = '<a href="' . get_category_link($category->term_id) . '">' . $category->name . '</a>';
                    }
                    $output[] = '<span class="' . $meta_class . ' post-meta-categories">' . 
                                implode(', ', $category_links) . '</span>';
                }
                break;
                
            case 'tag':
                $tags = get_the_tags($post_id);
                if (!empty($tags)) {
                    $tag_links = [];
                    foreach ($tags as $tag) {
                        $tag_links[] = '<a href="' . get_tag_link($tag->term_id) . '">' . $tag->name . '</a>';
                    }
                    $output[] = '<span class="' . $meta_class . ' post-meta-tags">' . 
                                implode(', ', $tag_links) . '</span>';
                }
                break;
                
            case 'comment':
                $output[] = '<span class="' . $meta_class . ' post-meta-comments">' . 
                            get_comments_number_text() . '</span>';
                break;
                
            case 'update':
                $output[] = '<span class="' . $meta_class . ' post-meta-updated">' . 
                            __('Updated: ', 'yomooh-core') . get_the_modified_date() . '</span>';
                break;
                
            case 'read':
                $output[] = '<span class="' . $meta_class . ' post-meta-readtime">' . 
                            $this->calculate_read_time($post_id) . '</span>';
                break;
        }
    }
    
    if (!empty($output)) {
        echo '<div class="post-carousel-meta display-' . $settings['meta_display'] . '">' . implode('', $output) . '</div>';
    }
}

    protected function calculate_read_time($post_id) {
        $content = get_post_field('post_content', $post_id);
        $word_count = str_word_count(strip_tags($content));
        $reading_time = ceil($word_count / 200); // 200 words per minute
        
        return sprintf(_n('%d min read', '%d min read', $reading_time, 'yomooh-core'), $reading_time);
    }

    protected function get_post_types() {
        $post_types = get_post_types(['public' => true], 'objects');
        $options = [];

        foreach ($post_types as $post_type) {
            if ($post_type->name !== 'elementor_library') {
                $options[$post_type->name] = $post_type->label;
            }
        }

        return $options;
    }
    protected function get_authors() {
    $users = get_users([
        'capability' => 'edit_posts',
        'has_published_posts' => true,
        'fields' => ['ID', 'display_name']
    ]);

    $options = [];

    foreach ($users as $user) {
        $options[$user->ID] = $user->display_name;
    }

    return $options;
}

    protected function get_post_categories() {
        $categories = get_categories(['hide_empty' => false]);
        $options = [];

        foreach ($categories as $category) {
            $options[$category->term_id] = $category->name;
        }

        return $options;
    }
}