<?php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Handle the preview query parameter
if (isset($_GET['page-title'])) {
    $page_title = sanitize_text_field($_GET['page-title']);
    $template_post = get_page_by_title($page_title, OBJECT, 'yomooh_template');
    
    if ($template_post) {
        $post = $template_post;
        setup_postdata($post);
    }
}

get_header();
?>

<main id="yomooh-template-content" class="yomooh-template">
    <?php
    // Always call the_content() for Elementor compatibility
    while (have_posts()) : the_post();
        // Check if Elementor should handle the content
        if (defined('ELEMENTOR_PATH') && class_exists('Elementor\Plugin')) {
            $elementor_instance = Elementor\Plugin::instance();
            
            // First try to get Elementor content
            $elementor_content = $elementor_instance->frontend->get_builder_content_for_display(get_the_ID());
            
            if (!empty($elementor_content)) {
                echo $elementor_content;
            } else {
                // Fallback to regular content if no Elementor content exists
                the_content();
            }
        } else {
            // Standard WordPress content if Elementor isn't active
            the_content();
        }
    endwhile;
    ?>
</main>

<?php
get_footer();

// Reset post data if we used the query parameter
if (isset($_GET['page-title'])) {
    wp_reset_postdata();
}