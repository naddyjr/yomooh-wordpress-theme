<?php
namespace Yomooh\Backend\settings\Options;
use Redux;
use Yomooh\Backend\settings\AdminOptions;

class WooCommerceSettings extends AdminOptions
{
    protected $options;

    public function __construct($opt_name)
    {
        $this->opt_name = $opt_name;
        $this->options = $this->woocommerce_fields();
        $this->set_widget_option();
    }

    protected function get_registered_sidebars()
    {
        return [
            'sidebar-1'          => __('Default Sidebar', 'yomooh-core'),
            'sidebar-shop'       => __('Shop Sidebar', 'yomooh-core'),
            'sidebar-product'     => __('Product Sidebar', 'yomooh-core')
        ];
    }

    protected function woocommerce_fields()
    {
        return [
            [
                'id'       => 'wc_archive_sidebar_position',
                'type'     => 'button_set',
                'title'    => esc_html__('Shop Sidebar Position', 'yomooh-core'),
                'subtitle' => esc_html__('Sidebar position for product archives', 'yomooh-core'),
                'options'  => [
                    'left'  => esc_html__('Left', 'yomooh-core'),
                    'right' => esc_html__('Right', 'yomooh-core'),
                    'none'  => esc_html__('No Sidebar', 'yomooh-core')
                ],
                'default'  => 'left',
            ],
            [
                'id'       => 'wc_archive_sidebar',
                'type'     => 'select',
                'title'    => esc_html__('Shop Sidebar', 'yomooh-core'),
                'subtitle' => esc_html__('Select sidebar for product archives', 'yomooh-core'),
                'options'  => $this->get_registered_sidebars(),
                'default'  => 'sidebar-shop',
                'required' => ['wc_archive_sidebar_position', '!=', 'none'],
            ],
            [
                'id'       => 'wc_products_per_page',
                'type'     => 'spinner',
                'title'    => esc_html__('Products Per Page', 'yomooh-core'),
                'subtitle' => esc_html__('Number of products to show per page', 'yomooh-core'),
                'default'  => '12',
                'min'      => '1',
                'step'     => '1',
                'max'      => '100',
            ],
            [
                'id'       => 'shop_section_end',
                'type'     => 'section',
                'indent'   => false,
            ],
            [
                'id'       => 'wc_product_single_section',
                'type'     => 'section',
                'subtitle' => esc_html__('Configure Product single', 'yomooh-core'),
                'indent'   => true,
            ],
            [
                'id'       => 'wc_single_sidebar_position',
                'type'     => 'button_set',
                'title'    => esc_html__('Product Sidebar Position', 'yomooh-core'),
                'subtitle' => esc_html__('Sidebar position for single products', 'yomooh-core'),
                'options'  => [
                    'left'  => esc_html__('Left', 'yomooh-core'),
                    'right' => esc_html__('Right', 'yomooh-core'),
                    'none'  => esc_html__('No Sidebar', 'yomooh-core')
                ],
                'default'  => 'none',
            ],
            [
                'id'       => 'wc_single_sidebar',
                'type'     => 'select',
                'title'    => esc_html__('Product Sidebar', 'yomooh-core'),
                'subtitle' => esc_html__('Select sidebar for single products', 'yomooh-core'),
                'options'  => $this->get_registered_sidebars(),
                'default'  => 'sidebar-product',
                'required' => ['wc_single_sidebar_position', '!=', 'none'],
            ],
            
            [
                'id'       => 'wc_show_breadcrumbs',
                'type'     => 'switch',
                'title'    => esc_html__('Show Breadcrumbs', 'yomooh-core'),
                'subtitle' => esc_html__('Display WooCommerce breadcrumbs', 'yomooh-core'),
                'default'  => true,
            ],
            [
                'id'       => 'wc_related_products',
                'type'     => 'switch',
                'title'    => esc_html__('Show Related Product ', 'yomooh-core'),
                'subtitle' => esc_html__('Display Related Product', 'yomooh-core'),
                'default'  => true,
            ]
        ];
    }

    protected function set_widget_option()
    {
        \Redux::setSection($this->opt_name, [
            'title'            => esc_html__('WooCommerce', 'yomooh-core'),
            'id'               => 'woocommerce_settings',
            'icon'             => 'el el-shopping-cart',
            'desc'             => __('Configure WooCommerce display settings', 'yomooh-core'),
            'customizer_width' => '500px',
            'fields'           => $this->options,
        ]);
    }
}