<?php
namespace Yomooh\baseClasses;

use Yomooh\Backend\settings\AdminOptions;

class Activate extends Base
{
    public static function activate()
    {
        flush_rewrite_rules();
    }

    public function init()
    {
        // Checking if Redux Framework plugin is active
        if (!class_exists('Redux')) {
            add_action('admin_notices', function () {
                ?>
                <div class="notice notice-error is-dismissible">
                    <p>The Yomooh plugin requires Redux Framework to be installed and activated.</p>
                </div>
                <?php
            });
            return;
        }

       if ( function_exists('is_yomooh_theme_active') && is_yomooh_theme_active() ) {
            (new AdminOptions())->init();
        }
        flush_rewrite_rules();
    }
}
