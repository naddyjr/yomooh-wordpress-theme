<?php
/** Don't load directly */
defined( 'ABSPATH' ) || exit;

add_action( 'after_setup_theme', [ 'Yomooh_Register_Metaboxes', 'get_instance' ], 1 );

if ( ! class_exists( 'Yomooh_META' ) ) {
    class Yomooh_META {

        private static $instance;

        static function get_instance() {
            if ( self::$instance === null ) {
                return new self();
            }
            return self::$instance;
        }

        function __construct() {
            self::$instance = $this;
            add_action( 'add_meta_boxes', [ $this, 'register_meta_boxes' ], PHP_INT_MAX );
            add_action( 'save_post', [ $this, 'save' ], 300, 1 );
            add_action( 'edit_form_top', [ $this, 'create_nonce' ] );
            add_action( 'block_editor_meta_box_hidden_fields', [ $this, 'create_nonce' ] );
            $this->load_assets();
        }

        /**
         * Create nonce
         */
        function create_nonce() {
            wp_nonce_field( basename( __FILE__ ), 'som_meta_nonce' );
        }

        /**
         * Register meta boxes
         */
        public function register_meta_boxes() {
            $metaboxes = apply_filters( 'som_meta_boxes', [] );
            
            if ( empty( $metaboxes ) ) {
                return;
            }

            foreach ( $metaboxes as $metabox ) {
                if ( empty( $metabox['id'] ) || empty( $metabox['title'] ) || empty( $metabox['post_types'] ) ) {
                    continue;
                }

                add_meta_box(
                    $metabox['id'],
                    $metabox['title'],
                    [ $this, 'settings_form' ],
                    $metabox['post_types'],
                    $metabox['context'] ?? 'normal',
                    $metabox['priority'] ?? 'default',
                    $metabox
                );
            }
        }

            /**
             * Save meta data
             * @param int $post_id
             */
            function save( $post_id ) {
                // Verify nonce
                if ( ! isset( $_POST['som_meta_nonce'] ) || ! wp_verify_nonce( $_POST['som_meta_nonce'], basename( __FILE__ ) ) ) {
                    return $post_id;
                }

                // Check autosave
                if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
                    return $post_id;
                }

                // Check permissions
                if ( ! current_user_can( 'edit_post', $post_id ) ) {
                    return $post_id;
                }

                $metaboxes = apply_filters( 'som_meta_boxes', [] );
                
                if ( empty( $metaboxes ) ) {
                    return;
                }

                foreach ( $metaboxes as $metabox ) {
                    if ( ! in_array( get_post_type( $post_id ), $metabox['post_types'] ) ) {
                        continue;
                    }

                    if ( ! empty( $metabox['tabs'] ) ) {
                        foreach ( $metabox['tabs'] as $tab ) {
                            if ( ! empty( $tab['fields'] ) ) {
                                foreach ( $tab['fields'] as $field ) {
                                    if ( empty( $field['id'] ) ) {
                                        continue;
                                    }

                                    $old_value = get_post_meta( $post_id, $field['id'], true );
                                    
                                    // Handle different field types
                                    if ( $field['type'] === 'checkbox' ) {
                                        // Single checkbox (no options)
                                        if ( empty( $field['options'] ) ) {
                                            $new_value = isset( $_POST[ $field['id'] ] ) ? 1 : 0;
                                        } 
                                        // Multiple checkboxes (with options) - NEW FORMAT
                                        else {
                                            $submitted_values = isset( $_POST[ $field['id'] ] ) && is_array( $_POST[ $field['id'] ] ) 
                                                ? $_POST[ $field['id'] ] 
                                                : [];
                                            
                                            // Create key-value pairs with 1 for selected, 0 for not selected
                                            $new_value = [];
                                            foreach ( $field['options'] as $key => $label ) {
                                                $new_value[$key] = in_array( $key, $submitted_values ) ? 1 : 0;
                                            }
                                        }
                                    } 
                                    // Handle other field types
                                    else {
                                        $new_value = isset( $_POST[ $field['id'] ] ) ? $_POST[ $field['id'] ] : '';
                                    }

                                    // Sanitize the value based on field type
                                    $new_value = $this->sanitize_field_value( $field, $new_value );

                                    if ( $new_value !== $old_value ) {
                                        update_post_meta( $post_id, $field['id'], $new_value );
                                    } elseif ( '' === $new_value && $old_value ) {
                                        delete_post_meta( $post_id, $field['id'], $old_value );
                                    }
                                }
                            }
                        }
                    }
                }
            }

        /**
         * Load assets
         */
        public function load_assets() {
            add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_scripts' ], PHP_INT_MAX );
        }

        /**
         * Enqueue scripts and styles
         */
       	public function enqueue_scripts() {
			global $post_type;

			$metaboxes = apply_filters('som_meta_boxes', []);
			$has_metabox = false;

			foreach ($metaboxes as $metabox) {
				if (in_array($post_type, $metabox['post_types'])) {
					$has_metabox = true;
					break;
				}
			}

			if (!$has_metabox) {
				return;
			}

			// Enqueue CSS
			wp_enqueue_style(
				'yomooh-meta-css',
				YOMOOH_PLUGIN_URL . 'assets/css/meta-boxes.css',
				[],
				filemtime(YOMOOH_PLUGIN_DIR . 'assets/css/meta-boxes.css')
			);

			// Enqueue JS
			wp_enqueue_script(
				'yomooh-meta-js',
				YOMOOH_PLUGIN_URL . 'assets/js/meta-boxes.min.js',
				['jquery', 'wp-color-picker'],
				filemtime(YOMOOH_PLUGIN_DIR . 'assets/js/meta-boxes.min.js'),
				true
			);

			// Localize script if needed
			wp_localize_script('yomooh-meta-js', 'yomoohMeta', [
				'ajaxurl' => admin_url('admin-ajax.php'),
				'nonce'   => wp_create_nonce('yomooh-meta-nonce')
			]);

			// Enqueue WordPress color picker (for color fields)
			wp_enqueue_style('wp-color-picker');
			wp_enqueue_script('wp-color-picker');

			// Enqueue media uploader (for image fields)
			wp_enqueue_media();
		}

        /**
         * Settings form
         * @param WP_Post $post
         * @param array $metabox
         */
        public function settings_form( $post, $metabox ) {
            $args = $metabox['args'];
            
            if ( ! empty( $args['desc'] ) ) : ?>
                <p class="description"><?php echo esc_html( $args['desc'] ); ?></p>
            <?php endif;
            
            if ( empty( $args['tabs'] ) ) {
                return;
            }
            
            $active_tab = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : $args['tabs'][0]['id']; ?>
            
            <div class="som-meta-tabs">
                <div class="som-meta-tabs-nav">
                    <?php foreach ( $args['tabs'] as $tab ) : 
                        if ( empty( $tab['id'] ) ) {
                            continue;
                        } ?>
                        <a href="#<?php echo esc_attr( $tab['id'] ); ?>" 
                           class="som-meta-tab-nav <?php echo $active_tab === $tab['id'] ? 'active' : ''; ?>"
                           data-tab="<?php echo esc_attr( $tab['id'] ); ?>">
                            <?php if ( ! empty( $tab['icon'] ) ) : ?>
                                <span class="dashicons <?php echo esc_attr( $tab['icon'] ); ?>"></span>
                            <?php endif; ?>
                            <?php echo esc_html( $tab['title'] ); ?>
                        </a>
                    <?php endforeach; ?>
                </div>
                
                <div class="som-meta-tabs-content">
                    <?php foreach ( $args['tabs'] as $tab ) : 
                        if ( empty( $tab['id'] ) || empty( $tab['fields'] ) ) {
                            continue;
                        } ?>
                        
                        <div id="<?php echo esc_attr( $tab['id'] ); ?>" 
                             class="som-meta-tab-content <?php echo $active_tab === $tab['id'] ? 'active' : ''; ?>">
                        <?php if ( ! empty( $tab['desc'] ) ) : ?>
                                <p class="tabs-description"><?php echo esc_html( $tab['desc'] ); ?></p>
                            <?php endif; ?>
                            
                            <table class="form-table">
                                <tbody>
                                    <?php foreach ( $tab['fields'] as $field ) : 
                                        if ( empty( $field['id'] ) ) {
                                            continue;
                                        }
                                        
                                        $value = get_post_meta( $post->ID, $field['id'], true );
                                        $value = $value !== '' ? $value : ( $field['default'] ?? '' ); ?>
                                        
                                        <tr>
                                            <th scope="row">
                                                <label for="<?php echo esc_attr( $field['id'] ); ?>">
                                                    <?php echo esc_html( $field['name'] ); ?>
                                                </label>
                                                <?php if ( ! empty( $field['desc'] ) ) : ?>
                                                    <p class="description"><?php echo esc_html( $field['desc'] ); ?></p>
                                                <?php endif; ?>
                                            </th>
                                            <td>
                                                <?php $this->render_field( $field, $value ); ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php
        }

        /**
         * Render field
         * @param array $field
         * @param mixed $value
         */
        private function render_field( $field, $value ) {
			$field['id'] = esc_attr( $field['id'] );
			$field['class'] = isset( $field['class'] ) ? esc_attr( $field['class'] ) : '';

			// Add conditional data attributes if required is set
			if ( isset( $field['required'] ) && is_array( $field['required'] ) ) {
				$field['data-required'] = esc_attr( wp_json_encode( $field['required'] ) );
			}

			switch ( $field['type'] ) {
				case 'select':
					$this->render_select_field( $field, $value );
					break;

				case 'text':
				case 'number':
				case 'email':
				case 'url':
					$this->render_input_field( $field, $value );
					break;

				case 'textarea':
					$this->render_textarea_field( $field, $value );
					break;
                case 'button_set':
                    $this->render_button_set_field( $field, $value );
                    break;
				case 'checkbox':
					$this->render_checkbox_field( $field, $value );
					break;

				case 'radio':
					$this->render_radio_field( $field, $value );
					break;

				case 'color':
					$this->render_color_field( $field, $value );
					break;

				case 'image':
					$this->render_image_field( $field, $value );
					break;

				default:
					do_action( 'som_render_field_' . $field['type'], $field, $value );
					break;
			}
		}
        /**
         * Sanitize field value based on field type
         * @param array $field
         * @param mixed $value
         * @return mixed
         */
        private function sanitize_field_value( $field, $value ) {
        switch ( $field['type'] ) {
        case 'checkbox':
            // Single checkbox
            if ( empty( $field['options'] ) ) {
                return (int) $value;
            }
            // Multiple checkboxes (key-value format)
            else {
                if ( is_array( $value ) ) {
                    $sanitized = [];
                    foreach ( $value as $key => $val ) {
                        $sanitized[sanitize_text_field( $key )] = (int) $val;
                    }
                    return $sanitized;
                }
                return [];
            }
                    
                case 'number':
                    return is_numeric( $value ) ? (int) $value : '';
                    
                case 'email':
                    return sanitize_email( $value );
                    
                case 'url':
                    return esc_url_raw( $value );
                    
                case 'textarea':
                    return sanitize_textarea_field( $value );
                    
                case 'color':
                    return sanitize_hex_color( $value );
                    
                case 'select':
                case 'button_set':
                case 'radio':
                    return sanitize_text_field( $value );
                    
                case 'text':
                default:
                    return sanitize_text_field( $value );
            }
        }

			private function render_select_field( $field, $value ) {
				?>
				<select name="<?php echo $field['id']; ?>" id="<?php echo $field['id']; ?>" class="<?php echo $field['class']; ?>"
					<?php if ( isset( $field['data-required'] ) ) { ?>
						data-required="<?php echo $field['data-required']; ?>"
					<?php } ?>
				>
					<?php foreach ( $field['options'] as $key => $label ) : ?>
						<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $value, $key ); ?>>
							<?php echo esc_html( $label ); ?>
						</option>
					<?php endforeach; ?>
				</select>
				<?php
			}

        /**
         * Render input field
         * @param array $field
         * @param mixed $value
         */
        private function render_input_field( $field, $value ) {
            ?>
            <input type="<?php echo esc_attr( $field['type'] ); ?>" 
                   name="<?php echo $field['id']; ?>" 
                   id="<?php echo $field['id']; ?>" 
                   class="<?php echo $field['class']; ?>" 
                   value="<?php echo esc_attr( $value ); ?>">
            <?php
        }

        /**
         * Render textarea field
         * @param array $field
         * @param mixed $value
         */
        private function render_textarea_field( $field, $value ) {
            ?>
            <textarea name="<?php echo $field['id']; ?>" 
                      id="<?php echo $field['id']; ?>" 
                      class="<?php echo $field['class']; ?>" 
                      rows="5"><?php echo esc_textarea( $value ); ?></textarea>
            <?php
        }

         /**
         * Render checkbox field (single or multiple)
         * @param array $field
         * @param mixed $value
         */
        private function render_checkbox_field( $field, $value ) {
            // Handle single checkbox (legacy format)
            if ( empty( $field['options'] ) ) {
                $checked = ( $value === 1 || $value === '1' || $value === true );
                ?>
                <input type="checkbox" 
                    name="<?php echo $field['id']; ?>" 
                    id="<?php echo $field['id']; ?>" 
                    class="<?php echo $field['class']; ?>" 
                    value="1" <?php checked( $checked ); ?>>
                <?php
                return;
            }
            
            // Handle multiple checkboxes
            $value = is_array( $value ) ? $value : [];
            $defaults = isset( $field['default'] ) && is_array( $field['default'] ) ? $field['default'] : [];
            ?>
            
            <div class="som-checkbox-row-wrap">
                <?php foreach ( $field['options'] as $key => $label ) :
                    $is_checked = in_array( $key, $value ) || 
                                ( empty( $value ) && isset( $defaults[$key] ) && ( $defaults[$key] === 1 || $defaults[$key] === '1' || $defaults[$key] === true ) );
                    ?>
                    <div class="som-checkbox-item">
                        <input type="checkbox" 
                            name="<?php echo $field['id']; ?>[]" 
                            id="<?php echo $field['id'] . '_' . $key; ?>" 
                            value="<?php echo esc_attr( $key ); ?>" 
                            <?php checked( $is_checked ); ?>>
                        <label for="<?php echo $field['id'] . '_' . $key; ?>">
                            <?php echo esc_html( $label ); ?>
                        </label>
                    </div>
                <?php endforeach; ?>
            </div>
            <?php
        }

        /**
         * Render radio field
         * @param array $field
         * @param mixed $value
         */
        private function render_radio_field( $field, $value ) {
            ?>
            <div class="som-radio-group">
                <?php foreach ( $field['options'] as $key => $label ) : ?>
                    <label>
                        <input type="radio" 
                               name="<?php echo $field['id']; ?>" 
                               value="<?php echo esc_attr( $key ); ?>" 
                               <?php checked( $value, $key ); ?>>
                        <?php echo esc_html( $label ); ?>
                    </label><br>
                <?php endforeach; ?>
            </div>
            <?php
        }

        /**
         * Render color field
         * @param array $field
         * @param mixed $value
         */
        private function render_color_field( $field, $value ) {
            wp_enqueue_style( 'wp-color-picker' );
            wp_enqueue_script( 'wp-color-picker' );
            ?>
            <input type="text" 
                   name="<?php echo $field['id']; ?>" 
                   id="<?php echo $field['id']; ?>" 
                   class="som-color-picker <?php echo $field['class']; ?>" 
                   value="<?php echo esc_attr( $value ); ?>"
                   data-default-color="<?php echo esc_attr( $field['default'] ?? '' ); ?>">
            <?php
        }
        /**
         * Render button_set field
         * @param array $field
         * @param mixed $value
         */
        private function render_button_set_field( $field, $value ) {
            $value = $value !== '' ? $value : ( $field['default'] ?? '' );
            ?>
            <div class="som-button-set"
                <?php if ( isset( $field['data-required'] ) ) { ?>
                    data-required="<?php echo $field['data-required']; ?>"
                <?php } ?>
            >
                <?php foreach ( $field['options'] as $key => $label ) : ?>
                    <input type="radio" 
                        id="<?php echo esc_attr( $field['id'] . '_' . $key ); ?>" 
                        name="<?php echo esc_attr( $field['id'] ); ?>" 
                        value="<?php echo esc_attr( $key ); ?>" 
                        class="som-button-set-input" 
                        <?php checked( $value, $key ); ?>>
                    <label for="<?php echo esc_attr( $field['id'] . '_' . $key ); ?>" 
                        class="som-button-set-label">
                        <?php echo esc_html( $label ); ?>
                    </label>
                <?php endforeach; ?>
            </div>
            <?php
        }

        /**
         * Render image field
         * @param array $field
         * @param mixed $value
         */
        private function render_image_field( $field, $value ) {
            wp_enqueue_media();
            ?>
            <div class="som-image-upload">
                <input type="hidden" 
                       name="<?php echo $field['id']; ?>" 
                       id="<?php echo $field['id']; ?>" 
                       value="<?php echo esc_attr( $value ); ?>">
                
                <div class="som-image-preview">
                    <?php if ( $value ) : ?>
                        <img src="<?php echo esc_url( wp_get_attachment_url( $value ) ); ?>" style="max-width: 100%;">
                    <?php endif; ?>
                </div>
                
                <button type="button" class="button som-upload-image">
                    <?php esc_html_e( 'Upload Image', 'yomooh-core' ); ?>
                </button>
                
                <button type="button" class="button som-remove-image" style="<?php echo ! $value ? 'display:none;' : ''; ?>">
                    <?php esc_html_e( 'Remove Image', 'yomooh-core' ); ?>
                </button>
            </div>
            <?php
        }
    }
}
if ( ! class_exists( 'Yomooh_Register_Metaboxes', false ) ) {
	class Yomooh_Register_Metaboxes {

		private static $instance;

		public static function get_instance() {

			if ( self::$instance === null ) {
				return new self();
			}

			return self::$instance;
		}

		public function __construct() {

			self::$instance = $this;

			add_filter( 'som_meta_boxes', [ $this, 'register' ] );
		}

		function register( $metaboxes = [] ) {

			$metaboxes[] = $this->single_post_metaboxes();
			$metaboxes[] = $this->page_metaboxes();
			return $metaboxes;
		}
        protected function get_registered_sidebars()
    {
        return [
            'sidebar-1'    => __('Sidebar (Default)', 'yomooh-core'),
            'sidebar-blog' => __('Blog Sidebar', 'yomooh-core'),
            'sidebar-spage' => __('Single Page Sidebar', 'yomooh-core'),
            'sidebar-sblog' => __('Single Blog Sidebar', 'yomooh-core')
        ];
    }

		public function page_metaboxes() {

			return [
				'id'         => 'page_options',
				'title'      => esc_html__( 'Single Page Settings', 'yomooh-core' ),
				'context'    => 'normal',
				'post_types' => [ 'page' ],
				'tabs'       => [
					[
						'id'     => 'section-page-general',
						'title'  => esc_html__( 'General', 'yomooh-core' ),
						'desc'   => esc_html__( 'The settings below will take priority over other settings in "Theme Options > Single Pages".', 'yomooh-core' ),
						'icon'   => 'dashicons-align-full-width',
						'fields' => [
                            [
								'id'          => 'single_header_display',
								'name'        => esc_html__( 'Header Display', 'yomooh-core' ),
								'type'    => 'select',
                                'options' => [
									'default'     => esc_html__( '- Default -', 'yomooh-core' ),
									'enable'  => esc_html__( 'Enable Header', 'yomooh-core' ),
									'disable' => esc_html__( 'Disable Header', 'yomooh-core' ),
								],
								'default' => 'default',
							],
                            [
                                'id'       => 'single_header_design',
                                'type'     => 'button_set',
                                'name'    => esc_html__('Header Style', 'yomooh-core'),
                                'desc' => esc_html__('Select the design variation that you want to use for site', 'yomooh-core'),
                                'options' => [
                                    'default'  => esc_html__( 'Header Default Style', 'yomooh-core' ),
                                    'style2' => esc_html__( 'Header Style 2', 'yomooh-core' ),
                                ],
                                'required' => ['single_header_display', '!=', 'disable'],
                                'default'  => 'default',
                            ],
							[
								'id'      => 'page_header_style',
								'name'    => esc_html__( 'Page Header Title', 'yomooh-core' ),
								'desc'    => esc_html__( 'Select a top header title for this page. This option is used for the single page (not Elementor page).', 'yomooh-core' ),
								'type'    => 'select',
								'options'  => [
                                    'default'     => esc_html__( '- Default -', 'yomooh-core' ),
                                    'left-heading' => 'Left Heading',
                                    'no-heading'  => 'No heading',
                                ],
								'default' => 'default',
							],
							[
								'id'      => 'page_breadcrumb',
								'name'    => esc_html__( 'Page Breadcrumb', 'yomooh-core' ),
								'desc'    => esc_html__( 'Enable or disable the breadcrumb on this page header.', 'yomooh-core' ),
								'type'    => 'select',
								'options' => [
									'default'     => esc_html__( '- Default -', 'yomooh-core' ),
									'enable'  => esc_html__( 'Enable', 'yomooh-core' ),
									'disable' => esc_html__( 'Disable', 'yomooh-core' ),
								],
								'default' => 'default',
							],
						],
					],
					[
						'id'     => 'section-sidebar',
						'title'  => esc_html__( 'Sidebar Area', 'yomooh-core' ),
						'desc'   => esc_html__( 'The settings below will take priority over other settings in "Theme Options > Single Pages > Sidebar Area".', 'yomooh-core' ),
						'icon'   => 'dashicons-align-pull-right',
						'fields' => [
							[
								'id'      => 'pagelayout',
								'name'    => esc_html__( 'Sidebar Position', 'yomooh-core' ),
								'desc'    => esc_html__( 'Select a position for this page sidebar.', 'yomooh-core' ),
								'class'   => 'sidebar-select',
								'type'    => 'select',
								'options' => [
									'default'     => esc_html__( '- Default -', 'yomooh-core' ),
									'left-sidebar'  => esc_html__( 'Left Sidebar', 'yomooh-core' ),
                                    'right-sidebar'  => esc_html__( 'Right Sidebar', 'yomooh-core' ),
									'no-sidebar' => esc_html__( 'No Sidebar', 'yomooh-core' ),
								],
								'default' => 'default',
							],
							[
								'id'      => 'page_sidebar',
								'name'    => esc_html__( 'Assign a Sidebar', 'yomooh-core' ),
								'desc'    => esc_html__( 'Assign a custom sidebar for this page.', 'yomooh-core' ),
								'type'    => 'select',
								'options'  => $this->get_registered_sidebars(),
								'default' => 'default',
                                'required' => ['pagelayout', '!=', 'no-sidebar'],
							],
						],
					],
					[
						'id'     => 'section-footer',
						'title'  => esc_html__( 'Site Footer', 'yomooh-core' ),
                        'desc'   => esc_html__( 'The settings below will take priority over other settings in "Theme Options > Footer settings".', 'yomooh-core' ),
						'icon'   => 'dashicons-align-full-width',
						'fields' => [
							[
								'id'          => 'footer_display',
								'name'        => esc_html__( 'Footer Display', 'yomooh-core' ),
								'type'    => 'select',
                                'options' => [
									'default'     => esc_html__( '- Default -', 'yomooh-core' ),
									'enable'  => esc_html__( 'Enable Footer', 'yomooh-core' ),
									'disable' => esc_html__( 'Disable Footer', 'yomooh-core' ),
								],
								'default' => 'default',
							],
						],
					],
                    [
						'id'     => 'section-blog',
						'title'  => esc_html__( 'Blog page', 'yomooh-core' ),
                        'desc'   => esc_html__( 'The settings below will take priority over other settings in "Theme Options > Blog General". Only applies if the current page is set as the Blog page.', 'yomooh-core' ),
						'icon'   => 'dashicons-menu-alt',
						'fields' => [
                            [
								'id'      => 'blog_sidebar',
								'name'    => esc_html__( 'Sidebar Position', 'yomooh-core' ),
								'desc'    => esc_html__( 'Select a position for this blog page sidebar.', 'yomooh-core' ),
								'class'   => 'sidebar-select',
								'type'    => 'select',
								'options' => [
									'default'     => esc_html__( '- Default -', 'yomooh-core' ),
									'left-sidebar'  => esc_html__( 'Left Sidebar', 'yomooh-core' ),
                                    'right-sidebar'  => esc_html__( 'Right Sidebar', 'yomooh-core' ),
									'no-sidebar' => esc_html__( 'No Sidebar', 'yomooh-core' ),
								],
								'default' => 'default',
							],
							[
								'id'      => 'blogarchive_sidebar',
								'name'    => esc_html__( 'Assign a Sidebar', 'yomooh-core' ),
								'desc'    => esc_html__( 'Assign a custom sidebar for this blog page.', 'yomooh-core' ),
								'type'    => 'select',
								'options'  => $this->get_registered_sidebars(),
								'default' => 'default',
                                'required' => ['blog_sidebar', '!=', 'no-sidebar'],
							],
							[
								'id'          => 'blog_layout',
								'name'        => esc_html__( 'Blog Layout', 'yomooh-core' ),
								'desc'    => esc_html__( 'Select blog post layout.', 'yomooh-core' ),
								'type'    => 'select',
                                'options' => [
									'default'     => esc_html__( '- Default -', 'yomooh-core' ),
									'standard'  => esc_html__( 'Standard', 'yomooh-core' ),
									'grid' => esc_html__( 'Grid', 'yomooh-core' ),
                                    'list' => esc_html__( 'List', 'yomooh-core' ),
								],
								'default' => 'default',
							],
                            [
								'id'          => 'blog_columns',
								'name'        => esc_html__( 'Blog Coumns', 'yomooh-core' ),
								'desc'    => esc_html__( 'Number of columns for grid/masonry layout.', 'yomooh-core' ),
								'type'    => 'select',
                                'options'  => [
                                    'default' => esc_html__( '- Default -', 'yomooh-core' ),
                                    '2' => '2 Columns',
                                    '3' => '3 Columns',
                                    '4' => '4 Columns'
                                ],
								'default' => 'default',
                                'required' => ['blog_layout', '=', 'grid'],
							],
						],
					],
				],
			];
		}

		public function single_post_metaboxes() {

			$configs = [
				'id'         => 'post_options',
				'title'      => esc_html__( 'Single Post Settings', 'yomooh-core' ),
				'context'    => 'normal',
				'post_types' => [ 'post' ],
				'tabs'       => [
                   [
                    'id'     => 'section-single-general',
                    'title'  => esc_html__( 'Blog Post', 'yomooh-core' ),
                    'desc'   => esc_html__( 'The settings below will take priority over other settings in "Theme Options > Blog single".', 'yomooh-core' ),
                    'icon'   => 'dashicons-menu-alt',
                    'fields' => [
                        [
                            'id'      => 'single_featured_image',
                            'name'    => esc_html__( 'Show Featured Image', 'yomooh-core' ),
                            'desc'    => esc_html__( 'Display featured image at top of post.', 'yomooh-core' ),
                            'type'    => 'checkbox',
                            'default' => 1,
                        ],
                        [
                            'id'       => 'single_author_box',
                            'type'     => 'checkbox',
                            'name'     => esc_html__('Author Box', 'yomooh-core'),
                            'desc'     => esc_html__('Display author bio below post content', 'yomooh-core'),
                            'default'  => 1,
                        ],
                        [
                            'id'       => 'single_related_posts',
                            'type'     => 'checkbox',
                            'name'     => esc_html__('Related Posts', 'yomooh-core'),
                            'desc'     => esc_html__('Display related posts section', 'yomooh-core'),
                            'default'  => 1,
                        ],
                        [
                            'id'       => 'single_navigation',
                            'type'     => 'checkbox',
                            'name'     => esc_html__('Post Navigation', 'yomooh-core'),
                            'desc'     => esc_html__('Display previous/next post links', 'yomooh-core'),
                            'default'  => 1,
                        ],
                        [
                            'id'       => 'single_comments',
                            'type'     => 'checkbox',
                            'name'     => esc_html__('Post Comments', 'yomooh-core'),
                            'desc'     => esc_html__('Enable comments on blog posts', 'yomooh-core'),
                            'default'  => 1,
                        ],
                        [
                            'id'       => 'single_social_sharing_position',
                            'type'     => 'button_set',
                            'name'     => esc_html__('Sharing Position', 'yomooh-core'),
                            'desc'     => esc_html__('Where to display social sharing buttons', 'yomooh-core'),
                            'options'  => [
                                'default' => esc_html__('Default (from Theme Options)', 'yomooh-core'),
                                'top' => 'Top',
                                'bottom' => 'Bottom',
                                'both' => 'Both',
                                'floating' => 'Floating'
                            ],
                            'default'  => 'default',
                        ]
                    ],
                    ],
					[
						'id'     => 'section-sidebar',
						'title'  => esc_html__( 'Sidebar Area', 'yomooh-core' ),
						'desc'   => esc_html__( 'The settings below will take priority over other settings in "Theme Options > Single Pages > Sidebar Area".', 'yomooh-core' ),
						'icon'   => 'dashicons-align-pull-right',
						'fields' => [
							[
								'id'      => 'single_layout',
								'name'    => esc_html__( 'Single Post Layout', 'yomooh-core' ),
								'desc'    => esc_html__( 'Select layout for single posts.', 'yomooh-core' ),
								'class'   => 'sidebar-select',
								'type'    => 'select',
								'options' => [
									'default'     => esc_html__( '- Default -', 'yomooh-core' ),
									'standard'  => esc_html__( 'Standard', 'yomooh-core' ),
                                    'fullwidth'  => esc_html__( 'Full Width', 'yomooh-core' ),
								],
								'default' => 'default',
							],
							[
								'id'      => 'single_sidebar',
								'name'    => esc_html__( 'Sidebar Position', 'yomooh-core' ),
								'desc'    => esc_html__( 'Select a position for this page sidebar.', 'yomooh-core' ),
								'class'   => 'sidebar-select',
								'type'    => 'select',
								'options' => [
									'default'     => esc_html__( '- Default -', 'yomooh-core' ),
									'left-sidebar'  => esc_html__( 'Left Sidebar', 'yomooh-core' ),
                                    'right-sidebar'  => esc_html__( 'Right Sidebar', 'yomooh-core' ),
									'no-sidebar' => esc_html__( 'No Sidebar', 'yomooh-core' ),
								],
								'default' => 'default',
							],
							[
								'id'      => 'blogsingle_sidebar',
								'name'    => esc_html__( 'Assign a Sidebar', 'yomooh-core' ),
								'desc'    => esc_html__( 'Assign a custom sidebar for this page.', 'yomooh-core' ),
								'type'    => 'select',
								'options'  => $this->get_registered_sidebars(),
								'default' => 'default',
                                'required' => ['single_sidebar', '!=', 'no-sidebar'],
							],
						],
					],
					[
						'id'     => 'section-footer',
						'title'  => esc_html__( 'Site Footer', 'yomooh-core' ),
                        'desc'   => esc_html__( 'The settings below will take priority over other settings in "Theme Options > Footer settings".', 'yomooh-core' ),
						'icon'   => 'dashicons-align-full-width',
						'fields' => [
							[
								'id'          => 'footer_display',
								'name'        => esc_html__( 'Footer Display', 'yomooh-core' ),
								'type'    => 'select',
                                'options' => [
									'default'     => esc_html__( '- Default -', 'yomooh-core' ),
									'enable'  => esc_html__( 'Enable Footer', 'yomooh-core' ),
									'disable' => esc_html__( 'Disable Footer', 'yomooh-core' ),
								],
								'default' => 'default',
							],
						],
					],
				],
			];

			return apply_filters( 'som_single_metaboxes', $configs );
		}
	}
}
// Initialize the metabox system
add_action( 'after_setup_theme', function() {
    if ( is_admin() ) {
        Yomooh_Register_Metaboxes::get_instance();
        Yomooh_META::get_instance();
    }
}, 1 );