<?php
namespace Yomooh\Backend\settings\Options;
use Redux;

use Yomooh\Backend\settings\AdminOptions;

class Newsletter extends AdminOptions
{
    protected $options;

    public function __construct($opt_name)
    {
        $this->opt_name = $opt_name;
        $this->options = $this->newsletter_fields();
        $this->set_widget_option();
    }

    protected function newsletter_fields()
    {
        return [
            [
                'id'       => 'newsletter_enable',
                'type'     => 'switch',
                'title'    => esc_html__('Enable Newsletter', 'yomooh-core'),
                'subtitle' => esc_html__('Enable newsletter form across the site.', 'yomooh-core'),
                'default'  => false,
            ],
            [
                'id'       => 'newsletter_title',
                'type'     => 'text',
                'title'    => esc_html__('Newsletter Title', 'yomooh-core'),
                'subtitle' => esc_html__('Main heading for the newsletter section.', 'yomooh-core'),
                'default'  => esc_html__('Subscribe to Our Newsletter', 'yomooh-core'),
                'required' => ['newsletter_enable', '=', true],
            ],
            [
                'id'       => 'newsletter_description',
                'type'     => 'text',
                'title'    => esc_html__('Newsletter Description', 'yomooh-core'),
                'subtitle' => esc_html__('Small description text for your newsletter form.', 'yomooh-core'),
                'default'  => esc_html__('Get latest news and updates delivered to your inbox.', 'yomooh-core'),
                'required' => ['newsletter_enable', '=', true],
            ],
            [
                'id'       => 'newsletter_shortcode',
                'type'     => 'text',
                'title'    => esc_html__('Newsletter Form Shortcode', 'yomooh-core'),
                'subtitle' => esc_html__('Paste a Mailchimp or other newsletter form shortcode.', 'yomooh-core'),
                'required' => ['newsletter_enable', '=', true],
            ],
        ];
    }

    protected function set_widget_option()
    {
        \Redux::setSection($this->opt_name, [
            'title'            => esc_html__('Newsletter', 'yomooh-core'),
            'id'               => 'newsletter_settings',
            'icon'             => 'el el-envelope',
            'desc'             => __('Configure newsletter integration and display settings.', 'yomooh-core'),
            'customizer_width' => '500px',
            'fields'           => $this->options,
        ]);
    }
}
