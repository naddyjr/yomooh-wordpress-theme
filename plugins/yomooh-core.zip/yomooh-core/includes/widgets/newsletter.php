<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class Yomooh_Newsletter_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct(
            'yomooh_newsletter_widget',
            __('Yomooh Newsletter', 'yomooh-core'),
            array(
                'description' => __('Display newsletter subscription form with Mailchimp integration.', 'yomooh-core'),
                'customize_selective_refresh' => true,
            )
        );
    }

    public function widget($args, $instance) {
        $title = apply_filters('widget_title', empty($instance['title']) ? '' : $instance['title'], $instance, $this->id_base);
        $description = empty($instance['description']) ? '' : $instance['description'];
        $mailchimp_shortcode = empty($instance['mailchimp_shortcode']) ? '' : $instance['mailchimp_shortcode'];

        echo $args['before_widget'];

        if ($title) {
            echo $args['before_title'] . esc_html($title) . $args['after_title'];
        }

        echo '<div class="yomooh-newsletter-widget">';

        if ($description) {
            echo '<div class="newsletter-description">' . wpautop(esc_html($description)) . '</div>';
        }

        if ($mailchimp_shortcode) {
            echo '<div class="newsletter-form">';
            echo do_shortcode($mailchimp_shortcode);
            echo '</div>';
        }

        echo '</div>';
        echo $args['after_widget'];
    }

    public function form($instance) {
        $defaults = array(
            'title' => __('Newsletter', 'yomooh-core'),
            'description' => __('Subscribe to our newsletter for the latest updates.', 'yomooh-core'),
            'mailchimp_shortcode' => ''
        );

        $instance = wp_parse_args((array) $instance, $defaults);
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:', 'yomooh-core'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" 
                   name="<?php echo $this->get_field_name('title'); ?>" 
                   type="text" value="<?php echo esc_attr($instance['title']); ?>" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('description'); ?>"><?php _e('Description:', 'yomooh-core'); ?></label>
            <textarea class="widefat" rows="4" id="<?php echo $this->get_field_id('description'); ?>" 
                      name="<?php echo $this->get_field_name('description'); ?>"><?php echo esc_textarea($instance['description']); ?></textarea>
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('mailchimp_shortcode'); ?>"><?php _e('Mailchimp Form Shortcode:', 'yomooh-core'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('mailchimp_shortcode'); ?>" 
                   name="<?php echo $this->get_field_name('mailchimp_shortcode'); ?>" 
                   type="text" value="<?php echo esc_attr($instance['mailchimp_shortcode']); ?>" />
            <small><?php _e('Example: [mc4wp_form id="123"]', 'yomooh-core'); ?></small>
        </p>
        <?php
    }

    public function update($new_instance, $old_instance) {
        $instance = $old_instance;
        $instance['title'] = sanitize_text_field($new_instance['title']);
        $instance['description'] = sanitize_textarea_field($new_instance['description']);
        $instance['mailchimp_shortcode'] = sanitize_text_field($new_instance['mailchimp_shortcode']);
        
        return $instance;
    }
}
