<?php
namespace Yomooh\Backend\settings\Options;
use Redux;

use Yomooh\Backend\settings\AdminOptions;

class F404 extends AdminOptions
{
    protected $options;

    public function __construct($opt_name)
    {
        $this->opt_name = $opt_name;
        $this->options = $this->dependent_options();
        $this->set_widget_option();
    }

    protected function dependent_options()
    {
        return [
            [
                'id'       => '404_enable_custom',
                'type'     => 'switch',
                'title'    => esc_html__('Enable Custom 404 Page', 'yomooh-core'),
                'subtitle' => esc_html__('Replace default 404 page with custom design', 'yomooh-core'),
                'default'  => false, // Changed default to false
            ],
            [
                'id'       => '404_template_shortcode',
                'type'     => 'text',
                'title'    => esc_html__('Template Shortcode', 'yomooh-core'),
				'placeholder'    => esc_html__('[yomooh-template id="7"]', 'yomooh-core'),
                'subtitle' => esc_html__('Enter shortcode for your custom 404 template', 'yomooh-core'),
                'required' => ['404_enable_custom', '=', true], // Only shows when custom is enabled
                'default'  => '',
            ],
            [
                'id'       => '404_image',
                'type'     => 'media',
                'title'    => esc_html__('404 Image', 'yomooh-core'),
                'subtitle' => esc_html__('Upload image for 404 page', 'yomooh-core'),
                'required' => ['404_enable_custom', '=', false], // Only shows when custom is disabled
                'default'  => '',
            ],
            [
                'id'       => '404_title',
                'type'     => 'text',
                'title'    => esc_html__('Title Text', 'yomooh-core'),
                'subtitle' => esc_html__('Enter the title for 404 page', 'yomooh-core'),
                'required' => ['404_enable_custom', '=', false], // Only shows when custom is disabled
                'default'  => esc_html__('Oops! Page Not Found', 'yomooh-core'),
            ],
            [
                'id'       => '404_description',
                'type'     => 'textarea',
                'title'    => esc_html__('Description', 'yomooh-core'),
                'subtitle' => esc_html__('Enter description text for 404 page', 'yomooh-core'),
                'required' => ['404_enable_custom', '=', false], // Only shows when custom is disabled
                'default'  => esc_html__('The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.', 'yomooh-core'),
            ],
            [
                'id'       => '404_button_text',
                'type'     => 'text',
                'title'    => esc_html__('Button Text', 'yomooh-core'),
                'subtitle' => esc_html__('Text for back to home button', 'yomooh-core'),
                'required' => ['404_enable_custom', '=', false], // Only shows when custom is disabled
                'default'  => esc_html__('Back to Homepage', 'yomooh-core'),
            ],
            [
                'id'       => '404_search_form',
                'type'     => 'switch',
                'title'    => esc_html__('Show Search Form', 'yomooh-core'),
                'subtitle' => esc_html__('Enable/disable search form on 404 page', 'yomooh-core'),
                'required' => ['404_enable_custom', '=', false], // Only shows when custom is disabled
                'default'  => true,
            ],
            [
                'id'       => '404_show_footer',
                'type'     => 'switch',
                'title'    => esc_html__('Show Footer', 'yomooh-core'),
                'required' => ['404_enable_custom', '=', false], // Only shows when custom is disabled
                'subtitle' => esc_html__('Enable/disable footer on 404 page', 'yomooh-core'),
                'default'  => true,
            ]
        ];
    }

    protected function set_widget_option()
    {
        \Redux::setSection($this->opt_name, [
            'title'            => esc_html__('404 Page Settings', 'yomooh-core'),
            'id'               => '404_settings',
            'icon'             => 'el el-error-alt',
            'desc'             => __('Customize the appearance and behavior of your 404 error page', 'yomooh-core'),
            'customizer_width' => '500px',
            'fields'           => $this->options,
        ]);
    }
}