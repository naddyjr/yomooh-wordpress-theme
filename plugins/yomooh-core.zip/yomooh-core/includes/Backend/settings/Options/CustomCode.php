<?php
namespace Yomooh\Backend\settings\Options;
use Redux;

use Yomooh\Backend\settings\AdminOptions;

class CustomCode extends AdminOptions
{
    protected $options;

    public function __construct($opt_name)
    {
        $this->opt_name = $opt_name;
        $this->options = $this->custom_code_fields();
        $this->set_widget_option();
    }

    protected function custom_code_fields()
    {
        return [
            [
                'id'       => 'custom_css_code',
                'type'     => 'ace_editor',
                'title'    => esc_html__('Custom CSS', 'yomooh-core'),
                'subtitle' => esc_html__('Add custom CSS code', 'yomooh-core'),
                'mode'     => 'css',
            ],
            [
                'id'       => 'custom_js_code',
                'type'     => 'ace_editor',
                'title'    => esc_html__('JS Code JavaScript', 'yomooh-core'),
                'subtitle' => esc_html__('Paste your custom JS code here.', 'yomooh-core'),
                'mode'     => 'javascript',
				'theme'   => 'chrome',
            ],
            [
                'id'       => 'custom_html_head',
                'type'     => 'textarea',
                'title'    => esc_html__('Head HTML', 'yomooh-core'),
                'subtitle' => esc_html__('Custom HTML added to &lt;head&gt;', 'yomooh-core'),
                'validate' => 'html',
                'default'  => '',
            ],
            [
                'id'       => 'custom_html_body',
                'type'     => 'textarea',
                'title'    => esc_html__('Body HTML', 'yomooh-core'),
                'subtitle' => esc_html__('Custom HTML added after opening &lt;body&gt;', 'yomooh-core'),
                'validate' => 'html',
                'default'  => '',
            ]
        ];
    }

    protected function set_widget_option()
    {
        \Redux::setSection($this->opt_name, [
            'title'            => esc_html__('Custom Code', 'yomooh-core'),
            'id'               => 'custom_code_settings',
            'icon'             => 'el el-edit',
            'desc'             => __('Add custom CSS, JavaScript, and HTML to your site', 'yomooh-core'),
            'customizer_width' => '500px',
            'fields'           => $this->options,
        ]);
    }
}