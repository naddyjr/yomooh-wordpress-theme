<?php
namespace Yomooh\Backend\settings\Options;
use Redux;

use Yomooh\Backend\settings\AdminOptions;

class Footer extends AdminOptions
{
    protected $options;

    public function __construct($opt_name)
    {
        $this->opt_name = $opt_name;
        $this->options = $this->footer_fields();
        $this->set_widget_option();
    }

    protected function footer_fields()
    {
        return [
            [
                'id'       => 'footer_enable',
                'type'     => 'switch',
                'title'    => esc_html__('Enable Footer', 'yomooh-core'),
                'subtitle' => esc_html__('Toggle the entire footer section', 'yomooh-core'),
                'default'  => true,
            ],
            [
                'id'       => 'footer_template_shortcode',
                'type'     => 'text',
                'title'    => esc_html__('Footer Template Shortcode', 'yomooh-core'),
				'placeholder'    => esc_html__('[yomooh-template id="7"]', 'yomooh-core'),
                'subtitle' => esc_html__('Enter Elementor template shortcode for custom footer', 'yomooh-core'),
                'required' => ['footer_enable', '=', true],
            ],
            [
                'id'       => 'footer_layout',
                'type'     => 'image_select',
                'title'    => esc_html__('Footer Layout', 'yomooh-core'),
                'subtitle' => esc_html__('Select footer column layout', 'yomooh-core'),
                'options'  => [
                    '1-column' => [
                        'alt' => '1 Column',
                        'img' => YOMOOH_PLUGIN_URL . 'includes/Backend/settings/assets/images/footer1.png'
                    ],
                    '2-column' => [
                        'alt' => '2 Columns',
                        'img' => YOMOOH_PLUGIN_URL . 'includes/Backend/settings/assets/images/footer2.png'
                    ],
                    '3-column' => [
                        'alt' => '3 Columns',
                        'img' => YOMOOH_PLUGIN_URL . 'includes/Backend/settings/assets/images/footer3.png'
                    ],
                    '4-column' => [
                        'alt' => '4 Columns',
                        'img' => YOMOOH_PLUGIN_URL . 'includes/Backend/settings/assets/images/footer4.png'
                    ],
                ],
                'default'  => '4-column',
                'required' => ['footer_enable', '=', true],
            ],
            [
                'id'       => 'footer_width',
                'type'     => 'button_set',
                'title'    => esc_html__('Footer Width', 'yomooh-core'),
                'subtitle' => esc_html__('Select footer content width', 'yomooh-core'),
                'options'  => [
                    'boxed' => 'Boxed',
                    'full'  => 'Full Width'
                ],
                'default'  => 'full',
                'required' => ['footer_enable', '=', true],
            ],
            [
                'id'       => 'footer_background',
                'type'     => 'background',
                'title'    => esc_html__('Footer Background', 'yomooh-core'),
                'subtitle' => esc_html__('Set footer background (color/image)', 'yomooh-core'),
                'output'   => ['#site-footer'],
                'required' => ['footer_enable', '=', true],
            ],
            [
                'id'       => 'footer_widgets_enable',
                'type'     => 'switch',
                'title'    => esc_html__('Enable Footer Widgets', 'yomooh-core'),
                'subtitle' => esc_html__('Display widget areas in footer', 'yomooh-core'),
                'default'  => true,
                'required' => ['footer_enable', '=', true],
            ],
            [
                'id'       => 'footer_copyright_enable',
                'type'     => 'switch',
                'title'    => esc_html__('Enable Copyright Section', 'yomooh-core'),
                'subtitle' => esc_html__('Display copyright bar below footer', 'yomooh-core'),
                'default'  => true,
                'required' => ['footer_enable', '=', true],
            ],
            [
                'id'       => 'footer_copyright_text',
                'type'     => 'editor',
                'title'    => esc_html__('Copyright Text', 'yomooh-core'),
                'subtitle' => esc_html__('Enter copyright text (HTML allowed)', 'yomooh-core'),
                'default'  => '&copy; ' . date('Y') . ' ' . get_bloginfo('name') . '. All Rights Reserved.',
                'args'     => [
                    'wpautop'       => false,
                    'media_buttons' => false,
                    'textarea_rows' => 5,
                    'teeny'         => true,
                ],
                'required' => [
                    ['footer_enable', '=', true],
                    ['footer_copyright_enable', '=', true]
                ],
            ],
            [
                'id'       => 'footer_social_enable',
                'type'     => 'switch',
                'title'    => esc_html__('Enable Social Icons', 'yomooh-core'),
                'subtitle' => esc_html__('Display social media icons in footer', 'yomooh-core'),
                'default'  => true,
                'required' => ['footer_enable', '=', true],
            ],
            [
                'id'       => 'footer_social_position',
                'type'     => 'button_set',
                'title'    => esc_html__('Social Icons Position', 'yomooh-core'),
                'subtitle' => esc_html__('Select where to display social icons', 'yomooh-core'),
                'options'  => [
                    'top'    => 'Top Footer',
                    'bottom' => 'Copyright Bar'
                ],
                'default'  => 'bottom',
                'required' => [
                    ['footer_enable', '=', true],
                    ['footer_social_enable', '=', true]
                ],
            ],
			   // 🍪 Cookie Notice Options
            [
                'id'       => 'enable_cookie_notice',
                'type'     => 'switch',
                'title'    => esc_html__('Enable Cookie Notice', 'yomooh-core'),
                'subtitle' => esc_html__('Show cookie consent banner on site', 'yomooh-core'),
                'default'  => true,
            ],

            [
                'id'       => 'cookie_notice_text',
                'type'     => 'textarea',
                'title'    => esc_html__('Cookie Notice Text', 'yomooh-core'),
                'subtitle' => esc_html__('The message shown in the cookie banner', 'yomooh-core'),
                'default'  => esc_html__('This website uses cookies to ensure you get the best experience on our website.', 'yomooh-core'),
                'required' => ['enable_cookie_notice', '=', true],
            ],

            [
                'id'       => 'cookie_accept_button_text',
                'type'     => 'text',
                'title'    => esc_html__('Accept Button Text', 'yomooh-core'),
                'default'  => esc_html__('Accept', 'yomooh-core'),
                'required' => ['enable_cookie_notice', '=', true],
            ],

            [
                'id'       => 'cookie_policy_link',
                'type'     => 'text',
                'title'    => esc_html__('Policy Page URL', 'yomooh-core'),
                'subtitle' => esc_html__('Link to your privacy/cookie policy page', 'yomooh-core'),
                'default'  => '#',
                'required' => ['enable_cookie_notice', '=', true],
            ]
        ];
    }

    protected function set_widget_option()
    {
        \Redux::setSection($this->opt_name, [
            'title'            => esc_html__('Footer Settings', 'yomooh-core'),
            'id'               => 'custom-footer-main',
            'icon'             => 'el el-photo',
            'desc'             => __('Configure all footer settings and appearance', 'yomooh-core'),
            'customizer_width' => '500px',
            'fields'           => $this->options,
        ]);
    }
}