<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Background;

if (!defined('ABSPATH')) exit;

class Yomooh_Taxonomy_List_Widget extends Widget_Base {

    public function get_name() {
        return 'taxonomy-list';
    }

    public function get_title() {
        return __('Taxonomy List', 'yomooh-core');
    }

    public function get_icon() {
        return 'eicon-tags';
    }

    public function get_categories() {
        return ['yomooh-elements'];
    }
	 public function get_style_depends() {
        return ['taxonomy-list'];
    }

    protected function register_controls() {
        // Content Tab
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Taxonomy Settings', 'yomooh-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        // Get all registered taxonomies
        $taxonomies = get_taxonomies(['public' => true], 'objects');
        $taxonomy_options = [];
        
        foreach ($taxonomies as $taxonomy) {
            $taxonomy_options[$taxonomy->name] = $taxonomy->label;
        }

        $this->add_control(
            'taxonomy',
            [
                'label' => __('Select Taxonomy', 'yomooh-core'),
                'type' => Controls_Manager::SELECT,
                'options' => $taxonomy_options,
                'default' => 'category',
            ]
        );

        $this->add_control(
            'include_terms',
            [
                'label' => __('Include Specific Terms', 'yomooh-core'),
                'type' => Controls_Manager::TEXT,
                'description' => __('Enter term IDs separated by commas', 'yomooh-core'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'exclude_terms',
            [
                'label' => __('Exclude Terms', 'yomooh-core'),
                'type' => Controls_Manager::TEXT,
                'description' => __('Enter term IDs separated by commas', 'yomooh-core'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'show_featured_image',
            [
                'label' => __('Show Featured Image', 'yomooh-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'yomooh-core'),
                'label_off' => __('Hide', 'yomooh-core'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'image_size',
            [
                'label' => __('Image Size', 'yomooh-core'),
                'type' => Controls_Manager::SELECT,
                'options' => $this->get_image_sizes(),
                'default' => 'thumbnail',
                'condition' => [
                    'show_featured_image' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'show_count',
            [
                'label' => __('Show Post Count', 'yomooh-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'yomooh-core'),
                'label_off' => __('Hide', 'yomooh-core'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'orderby',
            [
                'label' => __('Order By', 'yomooh-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'name' => __('Name', 'yomooh-core'),
                    'slug' => __('Slug', 'yomooh-core'),
                    'term_group' => __('Term Group', 'yomooh-core'),
                    'term_id' => __('Term ID', 'yomooh-core'),
                    'id' => __('ID', 'yomooh-core'),
                    'count' => __('Count', 'yomooh-core'),
                ],
                'default' => 'name',
            ]
        );

        $this->add_control(
            'order',
            [
                'label' => __('Order', 'yomooh-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'ASC' => __('Ascending', 'yomooh-core'),
                    'DESC' => __('Descending', 'yomooh-core'),
                ],
                'default' => 'ASC',
            ]
        );

        $this->end_controls_section();

        // Styles Tab
        $this->start_controls_section(
            'style_section',
            [
                'label' => __('List Style', 'yomooh-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'items_per_row',
            [
                'label' => __('Items Per Row', 'yomooh-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'auto' => __('Auto', 'yomooh-core'),
                    '1' => __('1', 'yomooh-core'),
                    '2' => __('2', 'yomooh-core'),
                    '3' => __('3', 'yomooh-core'),
                    '4' => __('4', 'yomooh-core'),
                    '5' => __('5', 'yomooh-core'),
                    '6' => __('6', 'yomooh-core'),
                ],
                'default' => 'auto',
                'selectors' => [
                    '{{WRAPPER}} .taxonomy-list-container' => 'grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));',
                ],
            ]
        );

        $this->add_responsive_control(
            'gap',
            [
                'label' => __('Gap', 'yomooh-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .taxonomy-list-container' => 'gap: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .taxonomy-item' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'item_width',
            [
                'label' => __('Item Width', 'yomooh-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 50,
                        'max' => 500,
                    ],
                    '%' => [
                        'min' => 5,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .taxonomy-item' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'item_height',
            [
                'label' => __('Item Height', 'yomooh-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 30,
                        'max' => 500,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .taxonomy-item' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'item_padding',
            [
                'label' => __('Item Padding', 'yomooh-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .taxonomy-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'item_border',
                'selector' => '{{WRAPPER}} .taxonomy-item',
            ]
        );

        $this->add_control(
            'item_border_radius',
            [
                'label' => __('Border Radius', 'yomooh-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .taxonomy-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'item_box_shadow',
                'selector' => '{{WRAPPER}} .taxonomy-item',
            ]
        );

        $this->add_control(
            'item_transition',
            [
                'label' => __('Transition Duration', 'yomooh-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'max' => 3,
                        'step' => 0.1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .taxonomy-item' => 'transition-duration: {{SIZE}}s',
                ],
            ]
        );

        $this->end_controls_section();

        // Item Content Style
        $this->start_controls_section(
            'item_content_style',
            [
                'label' => __('Item Content', 'yomooh-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'content_alignment',
            [
                'label' => __('Alignment', 'yomooh-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'yomooh-core'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'yomooh-core'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'yomooh-core'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .taxonomy-item-content' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'heading_title_style',
            [
                'label' => __('Title', 'yomooh-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .taxonomy-title',
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __('Color', 'yomooh-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .taxonomy-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'title_hover_color',
            [
                'label' => __('Hover Color', 'yomooh-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .taxonomy-item:hover .taxonomy-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'title_spacing',
            [
                'label' => __('Spacing', 'yomooh-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .taxonomy-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'heading_count_style',
            [
                'label' => __('Count', 'yomooh-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'show_count' => 'yes',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'count_typography',
                'selector' => '{{WRAPPER}} .taxonomy-count',
                'condition' => [
                    'show_count' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'count_color',
            [
                'label' => __('Color', 'yomooh-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .taxonomy-count' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'show_count' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();

        // Image Style
        $this->start_controls_section(
            'image_style',
            [
                'label' => __('Image', 'yomooh-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_featured_image' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'image_width',
            [
                'label' => __('Width', 'yomooh-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 500,
                    ],
                    '%' => [
                        'min' => 5,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .taxonomy-image' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'image_height',
            [
                'label' => __('Height', 'yomooh-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 500,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .taxonomy-image' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'image_spacing',
            [
                'label' => __('Spacing', 'yomooh-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .taxonomy-image' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'image_border',
                'selector' => '{{WRAPPER}} .taxonomy-image',
            ]
        );

        $this->add_control(
            'image_border_radius',
            [
                'label' => __('Border Radius', 'yomooh-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .taxonomy-image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'image_box_shadow',
                'selector' => '{{WRAPPER}} .taxonomy-image',
            ]
        );

        $this->end_controls_section();

        // Background Style
        $this->start_controls_section(
            'background_style',
            [
                'label' => __('Background', 'yomooh-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'item_background',
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .taxonomy-item',
            ]
        );

        $this->add_control(
            'item_hover_background',
            [
                'label' => __('Hover Background', 'yomooh-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .taxonomy-item:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function get_image_sizes() {
        $image_sizes = get_intermediate_image_sizes();
        $options = [];
        
        foreach ($image_sizes as $size) {
            $options[$size] = ucwords(str_replace(['-', '_'], ' ', $size));
        }
        
        $options['full'] = __('Full', 'yomooh-core');
        
        return $options;
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        
        $args = [
            'taxonomy' => $settings['taxonomy'],
            'hide_empty' => false,
            'orderby' => $settings['orderby'],
            'order' => $settings['order'],
        ];
        
        // Include specific terms
        if (!empty($settings['include_terms'])) {
            $include_terms = array_map('trim', explode(',', $settings['include_terms']));
            $args['include'] = $include_terms;
        }
        
        // Exclude terms
        if (!empty($settings['exclude_terms'])) {
            $exclude_terms = array_map('trim', explode(',', $settings['exclude_terms']));
            $args['exclude'] = $exclude_terms;
        }
        
        $terms = get_terms($args);
        
        if (empty($terms) || is_wp_error($terms)) {
            return;
        }
        
        ?>
        <div class="taxonomy-list-widget">
            <div class="taxonomy-list-container">
                <?php foreach ($terms as $term) : ?>
                    <div class="taxonomy-item elementor-repeater-item-<?php echo esc_attr($term->term_id); ?>">
                        <a href="<?php echo esc_url(get_term_link($term)); ?>" class="taxonomy-item-link">
                            <div class="taxonomy-item-content">
                                <?php if ($settings['show_featured_image'] === 'yes') : ?>
                                    <?php 
                                    $image_id = get_term_meta($term->term_id, 'thumbnail_id', true);
                                    if ($image_id) {
                                        echo wp_get_attachment_image($image_id, $settings['image_size'], false, [
                                            'class' => 'taxonomy-image',
                                            'alt' => esc_attr($term->name)
                                        ]);
                                    } else {
                                        echo '<div class="taxonomy-image-placeholder"></div>';
                                    }
                                    ?>
                                <?php endif; ?>
                                
                                <h3 class="taxonomy-title"><?php echo esc_html($term->name); ?></h3>
                                
                                <?php if ($settings['show_count'] === 'yes') : ?>
                                    <span class="taxonomy-count">
                                        <?php echo esc_html($term->count); ?> <?php _e('Posts', 'yomooh-core'); ?>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
    }
}