<?php
if (!function_exists('yomooh_dashboard')) {
    function yomooh_dashboard($current_page = '') {
        ?>
        <div class="somnest-admin-wrap">
            <div class="bsf-dashboard-header">
                <div class="bsf-dashboard-header-inner">
                    <div class="rbi-dashboard-menu-wrap">
                        <div class="bsf-dashboard-menu">
                            <div class="bsf-dashboard-topbar-left">
								 <h2 class="yomooh-title">
                                <span class="first-word">Y</span> <span class="rest">omooh</span>
                            </h2>
                                <div class="bsf-dashboard-meta bsf-ver">Version: <?php echo esc_html(YOMOOH_VERSION); ?></div>
                            </div>
                            <a class="bsf-menu-item <?php echo ($current_page === 'options') ? 'active' : ''; ?>" href="<?php echo esc_url(admin_url('admin.php?page=yomooh_options')); ?>">
                                <i class="icon-apps-settings"></i>
                                <span class="bsf-menu-text">Configuration Options</span>
                            </a>
							<a class="bsf-menu-item <?php echo ($current_page === 'demo') ? 'active' : ''; ?>" href="<?php echo esc_url(admin_url('admin.php?page=yomooh-demo-importer')); ?>">
                                <i class="icon-apps-settings"></i>
                                <span class="bsf-menu-text">Demo Importer</span>
                            </a>
                        </div>
                        <div class="bsf-dashboard-menu-right">
                            <div class="bsf-links">
                                <a href="https://yomooh.somnest.net/documentation/" target="_blank">Documentation</a>
                                <a href="https://somnest.net/tickets/" target="_blank">Open a Ticket</a>
                                <a href="https://yomooh.somnest.net/documentation/change-logs/" target="_blank">
                                    <i class="rbi-dash rbi-dash-horn"></i>What's new
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
}
