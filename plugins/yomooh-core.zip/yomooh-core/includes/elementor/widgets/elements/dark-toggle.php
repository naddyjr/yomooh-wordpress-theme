<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Icons_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

if (!defined('ABSPATH')) exit;

class Yomooh_Widget_Dark_Toggle extends Widget_Base {

    public function get_name() {
        return 'yomooh_dark_toggle';
    }

    public function get_title() {
        return __('Theme Mode Switcher', 'yomooh-core');
    }

    public function get_icon() {
        return 'eicon-adjust';
    }

    public function get_categories() {
        return ['yomooh-elements'];
    }

    protected function register_controls() {
        // Content Tab
        $this->start_controls_section('content_section', [
            'label' => __('Content', 'yomooh-core'),
            'tab' => Controls_Manager::TAB_CONTENT,
        ]);

        $this->add_control('design_style', [
            'label' => __('Design Style', 'yomooh-core'),
            'type' => Controls_Manager::SELECT,
            'default' => 'default',
            'options' => [
                'default' => __('Default - Switch', 'yomooh-core'),
                'button' => __('Button Style', 'yomooh-core'),
                'toggle' => __('Toggle Style', 'yomooh-core'),
                'icon' => __('Icon Only', 'yomooh-core'),
            ],
        ]);

        $this->add_control('light_icon', [
            'label' => __('Light Mode Icon', 'yomooh-core'),
            'type' => Controls_Manager::ICONS,
            'default' => [
                'value' => 'fas fa-sun',
                'library' => 'fa-solid',
            ],
        ]);

        $this->add_control('dark_icon', [
            'label' => __('Dark Mode Icon', 'yomooh-core'),
            'type' => Controls_Manager::ICONS,
            'default' => [
                'value' => 'fas fa-moon',
                'library' => 'fa-solid',
            ],
        ]);

        $this->end_controls_section();

        // Style Tab
        $this->start_controls_section('style_section', [
            'label' => __('Style', 'yomooh-core'),
            'tab' => Controls_Manager::TAB_STYLE,
        ]);

        $this->add_responsive_control('icon_size', [
            'label' => __('Icon Size', 'yomooh-core'),
            'type' => Controls_Manager::SLIDER,
            'size_units' => ['px', 'em', 'rem'],
            'range' => [
                'px' => ['min' => 10, 'max' => 100],
            ],
            'default' => ['size' => 16, 'unit' => 'px'],
            'selectors' => [
                '{{WRAPPER}} .yomooh-theme-switcher i' => 'font-size: {{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .yomooh-theme-switcher svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
            ],
        ]);

        $this->add_control('icon_color_light', [
            'label' => __('Light Icon Color', 'yomooh-core'),
            'type' => Controls_Manager::COLOR,
            'default' => '#f1c40f',
            'selectors' => [
                '{{WRAPPER}} .yomooh-theme-switcher .light-icon' => 'color: {{VALUE}};',
                '{{WRAPPER}} .yomooh-theme-switcher .light-icon svg' => 'fill: {{VALUE}};',
            ],
        ]);

        $this->add_control('icon_color_dark', [
            'label' => __('Dark Icon Color', 'yomooh-core'),
            'type' => Controls_Manager::COLOR,
            'default' => '#f39c12',
            'selectors' => [
                '{{WRAPPER}} .yomooh-theme-switcher .dark-icon' => 'color: {{VALUE}};',
                '{{WRAPPER}} .yomooh-theme-switcher .dark-icon svg' => 'fill: {{VALUE}};',
            ],
        ]);

        $this->add_responsive_control('switcher_scale', [
            'label' => __('Switcher Scale', 'yomooh-core'),
            'type' => Controls_Manager::SLIDER,
            'size_units' => ['px'],
            'range' => [
                'px' => ['min' => 0.5, 'max' => 2, 'step' => 0.1],
            ],
            'default' => ['size' => 1],
            'selectors' => [
                '{{WRAPPER}} .yomooh-theme-switcher' => 'transform: scale({{SIZE}});',
            ],
        ]);

        $this->add_responsive_control('alignment', [
            'label' => __('Alignment', 'yomooh-core'),
            'type' => Controls_Manager::CHOOSE,
            'options' => [
                'flex-start' => [
                    'title' => __('Left', 'yomooh-core'),
                    'icon' => 'eicon-text-align-left',
                ],
                'center' => [
                    'title' => __('Center', 'yomooh-core'),
                    'icon' => 'eicon-text-align-center',
                ],
                'flex-end' => [
                    'title' => __('Right', 'yomooh-core'),
                    'icon' => 'eicon-text-align-right',
                ],
            ],
            'default' => 'center',
            'selectors' => [
                '{{WRAPPER}} .yomooh-theme-switcher-wrapper' => 'justify-content: {{VALUE}};',
            ],
        ]);

        // Design-specific styles
        $this->add_control('design_styles', [
            'label' => __('Design Styles', 'yomooh-core'),
            'type' => Controls_Manager::HEADING,
            'separator' => 'before',
        ]);

        $this->add_control('toggle_bg_color', [
            'label' => __('Toggle Background', 'yomooh-core'),
            'type' => Controls_Manager::COLOR,
            'default' => '#f5f5f5',
            'selectors' => [
                '{{WRAPPER}} .yomooh-theme-switcher.toggle-style .theme-toggle-btn' => 'background-color: {{VALUE}};',
            ],
            'condition' => [
                'design_style' => 'toggle',
            ],
        ]);
		$this->add_control('toggle_slider_bg_color', [
            'label' => __('Toggle slider Background', 'yomooh-core'),
            'type' => Controls_Manager::COLOR,
            'default' => '#f5f5f5',
            'selectors' => [
                '{{WRAPPER}} .yomooh-theme-switcher.toggle-style .theme-toggle-slider' => 'background-color: {{VALUE}};',
            ],
            'condition' => [
                'design_style' => 'toggle',
            ],
        ]);
        $this->add_control('button_bg_color', [
            'label' => __('Button Background', 'yomooh-core'),
            'type' => Controls_Manager::COLOR,
            'default' => '#3498db',
            'selectors' => [
                '{{WRAPPER}} .yomooh-theme-switcher.button-style .theme-toggle-btn' => 'background-color: {{VALUE}};',
            ],
            'condition' => [
                'design_style' => 'button',
            ],
        ]);

        $this->add_control('button_text_color', [
            'label' => __('Button Text Color', 'yomooh-core'),
            'type' => Controls_Manager::COLOR,
            'default' => '#ffffff',
            'selectors' => [
                '{{WRAPPER}} .yomooh-theme-switcher.button-style .theme-toggle-btn' => 'color: {{VALUE}};',
            ],
            'condition' => [
                'design_style' => 'button',
            ],
        ]);

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'button_border',
                'selector' => '{{WRAPPER}} .yomooh-theme-switcher.button-style .theme-toggle-btn',
                'condition' => [
                    'design_style' => 'button',
                ],
            ]
        );

        $this->add_responsive_control('button_border_radius', [
            'label' => __('Border Radius', 'yomooh-core'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%'],
            'selectors' => [
                '{{WRAPPER}} .yomooh-theme-switcher.button-style .theme-toggle-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                '{{WRAPPER}} .yomooh-theme-switcher.toggle-style .theme-toggle-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
            'conditions' => [
                'relation' => 'or',
                'terms' => [
                    ['name' => 'design_style', 'operator' => '==', 'value' => 'button'],
                    ['name' => 'design_style', 'operator' => '==', 'value' => 'toggle'],
                ],
            ],
        ]);

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_box_shadow',
                'selector' => '{{WRAPPER}} .theme-toggle-btn',
                'conditions' => [
                    'relation' => 'or',
                    'terms' => [
                        ['name' => 'design_style', 'operator' => '==', 'value' => 'button'],
                        ['name' => 'design_style', 'operator' => '==', 'value' => 'toggle'],
                    ],
                ],
            ]
        );

        $this->add_responsive_control('button_padding', [
            'label' => __('Padding', 'yomooh-core'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%', 'em'],
            'selectors' => [
                '{{WRAPPER}} .yomooh-theme-switcher.button-style .theme-toggle-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
            'condition' => [
                'design_style' => 'button',
            ],
        ]);

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $design_class = $settings['design_style'] . '-style';

        $current_mode = $this->get_theme_mode();
        $light_active = $current_mode === 'light' ? 'active' : '';
        $dark_active = $current_mode === 'dark' ? 'active' : '';
        ?>
        <div class="yomooh-theme-switcher-wrapper elementor-element">
            <div class="yomooh-theme-switcher <?php echo esc_attr($design_class); ?>">
                <button class="theme-toggle-btn" aria-label="<?php esc_attr_e('Toggle theme mode', 'yomooh-core'); ?>">
                    <?php if ($settings['design_style'] === 'button') : ?>
                    <?php endif; ?>
                    
                    <span class="light-icon <?php echo esc_attr($light_active); ?>">
                        <?php Icons_Manager::render_icon($settings['light_icon'], ['aria-hidden' => 'true']); ?>
                    </span>
                    
                    <?php if ($settings['design_style'] === 'toggle') : ?>
                        <span class="theme-toggle-slider"></span>
                    <?php endif; ?>
                    
                    <span class="dark-icon <?php echo esc_attr($dark_active); ?>">
                        <?php Icons_Manager::render_icon($settings['dark_icon'], ['aria-hidden' => 'true']); ?>
                    </span>
                </button>
            </div>
        </div>
        <?php
    }

    private function get_theme_mode() {
        if (isset($_COOKIE['theme_mode'])) {
            return $_COOKIE['theme_mode'];
        }
        return 'light'; // Default mode
    }
}