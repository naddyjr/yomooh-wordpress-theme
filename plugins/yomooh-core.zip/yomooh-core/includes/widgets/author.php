<?php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class Yomooh_Author_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct(
            'yomooh_author_widget',
            __('Yomooh Author Profile', 'yomooh-core'),
            array(
                'description' => __('Display an author profile with avatar, bio, and social links.', 'yomooh-core'),
                'customize_selective_refresh' => true,
            )
        );
    }

    public function widget($args, $instance) {
        $title = apply_filters('widget_title', empty($instance['title']) ? '' : $instance['title'], $instance, $this->id_base);
        $selected_author = empty($instance['author']) ? 0 : absint($instance['author']);

        if (!$selected_author) {
            return;
        }

        $author_data = get_userdata($selected_author);
        if (!$author_data) {
            return;
        }

        echo $args['before_widget'];

        if ($title) {
            echo $args['before_title'] . $title . $args['after_title'];
        }

        echo '<div class="wd-author-profile">';
        
        // Avatar and Name
        echo '<div class="wd-author-header">';
        echo '<div class="wd-author-avatar">' . get_avatar($selected_author, 100) . '</div>';
        echo '<div class="wd-author-name">' . esc_html($author_data->display_name) . '</div>';
        echo '</div>';
        
        // Social Links
        if (function_exists('user_social_links')) {
            echo '<div class="wd-author-social-links">';
            user_social_links($selected_author);
            echo '</div>';
        }
        
        // Bio
        if (!empty($author_data->description)) {
            echo '<div class="wd-author-bio">' . wpautop(wp_kses_post($author_data->description)) . '</div>';
        }
        
        // Stats
        echo '<div class="wd-author-stats">';
        
        // Post count
        $post_count = count_user_posts($selected_author);
        echo '<div class="wd-stat-item posts-count">';
        echo '<span class="wd-stat-number">' . esc_html($post_count) . '</span>';
        echo '<span class="wd-stat-label">' . _n('Post', 'Posts', $post_count, 'yomooh-core') . '</span>';
        echo '</div>';
        
        // Comments count (requires WP 4.0+)
        $comment_count = get_comments(array(
            'user_id' => $selected_author,
            'count' => true,
        ));
        echo '<div class="wd-stat-item comments-count">';
        echo '<span class="wd-stat-number">' . esc_html($comment_count) . '</span>';
        echo '<span class="wd-stat-label">' . _n('Comment', 'Comments', $comment_count, 'yomooh-core') . '</span>';
        echo '</div>';
        
        echo '</div>'; // .author-stats
        
        echo '</div>'; 
        echo $args['after_widget'];
    }

    public function form($instance) {
        $defaults = array(
            'title' => '',
            'author' => 0,
        );

        $instance = wp_parse_args((array) $instance, $defaults);
        
        // Get all users with author capability
        $users = get_users(array(
            'orderby' => 'display_name',
            'capability' => ['edit_posts'],
            'has_published_posts' => true
        ));
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:', 'yomooh-core'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($instance['title']); ?>" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('author'); ?>"><?php _e('Select Author:', 'yomooh-core'); ?></label>
            <select class="widefat" id="<?php echo $this->get_field_id('author'); ?>" name="<?php echo $this->get_field_name('author'); ?>">
                <option value="0"><?php _e('Select an author', 'yomooh-core'); ?></option>
                <?php foreach ($users as $user) : ?>
                    <option value="<?php echo esc_attr($user->ID); ?>" <?php selected($instance['author'], $user->ID); ?>>
                        <?php echo esc_html($user->display_name); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </p>
        <?php
    }

    public function update($new_instance, $old_instance) {
        $instance = $old_instance;
        $instance['title'] = sanitize_text_field($new_instance['title']);
        $instance['author'] = absint($new_instance['author']);
        return $instance;
    }
}
