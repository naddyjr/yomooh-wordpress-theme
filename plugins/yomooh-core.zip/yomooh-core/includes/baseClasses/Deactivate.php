<?php
namespace Yomooh\baseClasses;

class Deactivate {
	public static function init () {
        // Flush rewrite rules
        flush_rewrite_rules();
    }
}