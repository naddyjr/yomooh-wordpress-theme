<?php
namespace Yomooh\Backend\settings\Options;
use Redux;

use Yomooh\Backend\settings\AdminOptions;

class BlogSingle extends AdminOptions
{
    protected $options;

    public function __construct($opt_name)
    {
        $this->opt_name = $opt_name;
        $this->options = $this->blog_single_fields();
        $this->set_widget_option();
    }
protected function get_registered_sidebars()
    {
        return [
            'sidebar-1'    => __('Sidebar (Default)', 'yomooh-core'),
            'sidebar-blog' => __('Blog Sidebar', 'yomooh-core'),
            'sidebar-spage' => __('Single Page Sidebar', 'yomooh-core'),
            'sidebar-sblog' => __('Single Blog Sidebar', 'yomooh-core')
        ];
    }
    protected function blog_single_fields()
    {
        return [
            [
                'id'       => 'single_layout',
                'type'     => 'button_set',
                'title'    => esc_html__('Single Post Layout', 'yomooh-core'),
                'subtitle' => esc_html__('Select layout for single posts', 'yomooh-core'),
				'options'  => [
                    'standard' => esc_html__('Standard', 'yomooh-core'),
					'fullwidth' => esc_html__('Full Width', 'yomooh-core'),
                ],
                'default'  => 'standard',
            ],
            [
                'id'       => 'single_sidebar',
                'type'     => 'image_select',
                'title'    => esc_html__('Sidebar Position', 'yomooh-core'),
                'subtitle' => esc_html__('Select sidebar position for single posts', 'yomooh-core'),
                'options'  => [
                    'left-sidebar' => [
                        'alt' => 'Left Sidebar',
                        'img' => YOMOOH_PLUGIN_URL . 'includes/Backend/settings/assets/images/left-sidebar.png'
                    ],
                    'right-sidebar' => [
                        'alt' => 'Right Sidebar',
                        'img' => YOMOOH_PLUGIN_URL . 'includes/Backend/settings/assets/images/sidebar-right.png'
                    ],
                    'no-sidebar' => [
                        'alt' => 'No Sidebar',
                        'img' => YOMOOH_PLUGIN_URL . 'includes/Backend/settings/assets/images/column-one.png'
                    ],
                ],
                'default'  => 'right-sidebar',
                'required' => ['single_layout', '!=', 'fullwidth'],
            ],
            [
                'id'       => 'blogsingle_sidebar',
                'type'     => 'select',
                'title'    => esc_html__('Assign a Sidebar', 'yomooh-core'),
                'subtitle' => esc_html__('Select which sidebar to display on blog single', 'yomooh-core'),
                'options'  => $this->get_registered_sidebars(),
                'default'  => 'sidebar-1',
                'required' => ['single_sidebar', '!=', 'no-sidebar'],
            ],
            [
                'id'       => 'single_featured_image',
                'type'     => 'switch',
                'title'    => esc_html__('Show Featured Image', 'yomooh-core'),
                'subtitle' => esc_html__('Display featured image at top of post', 'yomooh-core'),
                'default'  => true,
            ],
            [
                'id'       => 'single_featured_image_caption',
                'type'     => 'switch',
                'title'    => esc_html__('Show Image Caption', 'yomooh-core'),
                'subtitle' => esc_html__('Display caption below featured image', 'yomooh-core'),
                'default'  => true,
                'required' => ['single_featured_image', '=', true],
            ],
            [
                'id'       => 'single_meta',
                'type'     => 'checkbox',
                'title'    => esc_html__('Post Meta', 'yomooh-core'),
                'subtitle' => esc_html__('Select which meta items to display', 'yomooh-core'),
                'options'  => [
                    'author' => 'Author',
                    'date' => 'Date',
                    'categories' => 'Categories',
                    'comments' => 'Comments',
                    'tags' => 'Tags',
                    'reading_time' => 'Reading Time',
                ],
                'default'  => [
                    'author' => true,
                    'date' => true,
                    'categories' => true,
                    'comments' => true,
                    'tags' => true,
                    'reading_time' => false,
                ],
            ],
            [
                'id'       => 'single_author_box',
                'type'     => 'switch',
                'title'    => esc_html__('Author Box', 'yomooh-core'),
                'subtitle' => esc_html__('Display author bio below post content', 'yomooh-core'),
                'default'  => true,
            ],
            [
                'id'       => 'single_related_posts',
                'type'     => 'switch',
                'title'    => esc_html__('Related Posts', 'yomooh-core'),
                'subtitle' => esc_html__('Display related posts section', 'yomooh-core'),
                'default'  => true,
            ],
            [
                'id'       => 'single_related_posts_count',
                'type'     => 'spinner',
                'title'    => esc_html__('Related Posts Count', 'yomooh-core'),
                'subtitle' => esc_html__('Number of related posts to show', 'yomooh-core'),
                'default'  => '3',
                'min'      => '2',
                'step'     => '1',
                'max'      => '6',
                'required' => ['single_related_posts', '=', true],
            ],
            [
                'id'       => 'single_related_posts_columns',
                'type'     => 'button_set',
                'title'    => esc_html__('Related Posts Columns', 'yomooh-core'),
                'subtitle' => esc_html__('Number of columns for related posts', 'yomooh-core'),
                'options'  => [
                    '2' => '2 Columns',
                    '3' => '3 Columns',
                    '4' => '4 Columns'
                ],
                'default'  => '3',
                'required' => ['single_related_posts', '=', true],
            ],
            [
                'id'       => 'single_navigation',
                'type'     => 'switch',
                'title'    => esc_html__('Post Navigation', 'yomooh-core'),
                'subtitle' => esc_html__('Display previous/next post links', 'yomooh-core'),
                'default'  => true,
            ],
            [
                'id'       => 'single_comments',
                'type'     => 'switch',
                'title'    => esc_html__('Comments', 'yomooh-core'),
                'subtitle' => esc_html__('Enable comments on blog posts', 'yomooh-core'),
                'default'  => true,
            ],
            [
                'id'       => 'single_social_sharing',
                'type'     => 'checkbox',
                'title'    => esc_html__('Social Sharing', 'yomooh-core'),
                'subtitle' => esc_html__('Select social networks for sharing', 'yomooh-core'),
                'options'  => [
                    'facebook' => 'Facebook',
                    'twitter' => 'Twitter',
                    'linkedin' => 'LinkedIn',
                    'pinterest' => 'Pinterest',
                    'reddit' => 'Reddit',
                    'whatsapp' => 'WhatsApp',
                    'email' => 'Email',
                ],
                'default'  => [
                    'facebook' => true,
                    'twitter' => true,
                    'linkedin' => true,
                    'pinterest' => false,
                    'reddit' => false,
                    'whatsapp' => false,
                    'email' => true,
                ],
            ],
            [
                'id'       => 'single_social_sharing_position',
                'type'     => 'button_set',
                'title'    => esc_html__('Sharing Position', 'yomooh-core'),
                'subtitle' => esc_html__('Where to display social sharing buttons', 'yomooh-core'),
                'options'  => [
                    'top' => 'Top',
                    'bottom' => 'Bottom',
                    'both' => 'Both',
                    'floating' => 'Floating'
                ],
                'default'  => 'bottom',
            ]
        ];
    }

    protected function set_widget_option()
    {
        \Redux::setSection($this->opt_name, [
            'title'            => esc_html__('Blog Single', 'yomooh-core'),
            'id'               => 'blog_single_settings',
            'icon'             => 'el el-file-edit',
            'desc'             => __('Configure single blog post settings', 'yomooh-core'),
            'customizer_width' => '500px',
            'fields'           => $this->options,
        ]);
    }
}