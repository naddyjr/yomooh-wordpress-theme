<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class Yomooh_Ad_Script_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct(
            'yomooh_ad_script',
            __('Yomooh Ad Script', 'yomooh-core'),
            array(
                'description' => __('Display custom ad scripts or Adsense code with responsive sizing.', 'yomooh-core'),
                'customize_selective_refresh' => true,
            )
        );
    }

    public function widget($args, $instance) {
        $title = apply_filters('widget_title', empty($instance['title']) ? __('Advertisement', 'yomooh-core') : $instance['title'], $instance, $this->id_base);
        $ad_code = empty($instance['ad_code']) ? '' : $instance['ad_code'];
        $ad_size = empty($instance['ad_size']) ? 'auto' : $instance['ad_size'];
        $use_test_ad = !empty($instance['use_test_ad']);

        echo $args['before_widget'];

        if ($title) {
            echo $args['before_title'] . esc_html($title) . $args['after_title'];
        }

        echo '<div class="yomooh-ad-container ad-size-' . esc_attr($ad_size) . '">';
        
        if ($use_test_ad) {
            echo $this->get_test_ad($ad_size);
        } elseif ($ad_code) {
            // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            echo $ad_code;
        } else {
            echo '<div class="ad-placeholder">' . __('Configure your ad code in widget settings', 'yomooh-core') . '</div>';
        }
        
        echo '</div>';
        echo $args['after_widget'];
    }

    private function get_test_ad($size) {
        $sizes = $this->get_ad_sizes();
        $dimensions = isset($sizes[$size]) ? $sizes[$size] : array('width' => 'auto', 'height' => 'auto');
        
        $width = $dimensions['width'] === 'auto' ? '100%' : $dimensions['width'] . 'px';
        $height = $dimensions['height'] === 'auto' ? '150px' : $dimensions['height'] . 'px';
        
        $color1 = '#f0f0f0';
        $color2 = '#e0e0e0';
        
        return sprintf(
            '<div class="test-ad" style="width: %s; height: %s; background: linear-gradient(135deg, %s, %s); display: flex; align-items: center; justify-content: center; border: 1px dashed #ccc; color: #666; font-weight: bold;">%s<br>%sx%s</div>',
            esc_attr($width),
            esc_attr($height),
            esc_attr($color1),
            esc_attr($color2),
            __('Test Ad', 'yomooh-core'),
            $dimensions['width'] === 'auto' ? 'auto' : $dimensions['width'],
            $dimensions['height'] === 'auto' ? 'auto' : $dimensions['height']
        );
    }

    private function get_ad_sizes() {
        return array(
            'auto' => array('width' => 'auto', 'height' => 'auto'),
            '300x250' => array('width' => 300, 'height' => 250),
            '336x280' => array('width' => 336, 'height' => 280),
            '728x90' => array('width' => 728, 'height' => 90),
            '300x600' => array('width' => 300, 'height' => 600),
            '320x100' => array('width' => 320, 'height' => 100),
            '970x90' => array('width' => 970, 'height' => 90),
            '970x250' => array('width' => 970, 'height' => 250),
            '250x250' => array('width' => 250, 'height' => 250),
            '200x200' => array('width' => 200, 'height' => 200),
            '468x60' => array('width' => 468, 'height' => 60),
            '234x60' => array('width' => 234, 'height' => 60),
            '120x600' => array('width' => 120, 'height' => 600),
            '160x600' => array('width' => 160, 'height' => 600),
            '120x240' => array('width' => 120, 'height' => 240)
        );
    }

    public function form($instance) {
        $defaults = array(
            'title' => __('Advertisement', 'yomooh-core'),
            'ad_code' => '',
            'ad_size' => 'auto',
            'use_test_ad' => false
        );
        
        $instance = wp_parse_args((array) $instance, $defaults);
        $ad_sizes = $this->get_ad_sizes();
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:', 'yomooh-core'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" 
                   name="<?php echo $this->get_field_name('title'); ?>" 
                   type="text" value="<?php echo esc_attr($instance['title']); ?>" />
        </p>
        
        <p>
            <label for="<?php echo $this->get_field_id('ad_code'); ?>"><?php _e('Ad/Adsense Code:', 'yomooh-core'); ?></label>
            <textarea class="widefat" rows="8" id="<?php echo $this->get_field_id('ad_code'); ?>" 
                      name="<?php echo $this->get_field_name('ad_code'); ?>"><?php echo esc_textarea($instance['ad_code']); ?></textarea>
            <small><?php _e('Input your custom ad or Adsense code. Use Adsense units code to ensure it displays exactly where you put.', 'yomooh-core'); ?></small>
        </p>
        
        <p>
            <label for="<?php echo $this->get_field_id('ad_size'); ?>"><?php _e('Ad Size:', 'yomooh-core'); ?></label>
            <select class="widefat" id="<?php echo $this->get_field_id('ad_size'); ?>" name="<?php echo $this->get_field_name('ad_size'); ?>">
                <?php foreach ($ad_sizes as $size => $dimensions): ?>
                    <?php $size_label = $size === 'auto' ? 'Auto' : $size . ' (' . $dimensions['width'] . '×' . $dimensions['height'] . ')'; ?>
                    <option value="<?php echo esc_attr($size); ?>" <?php selected($instance['ad_size'], $size); ?>>
                        <?php echo esc_html($size_label); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <small><?php _e('Select a custom size for this ad if you use the Adsense ad units code.', 'yomooh-core'); ?></small>
        </p>
        
        <p>
            <input class="checkbox" type="checkbox" id="<?php echo $this->get_field_id('use_test_ad'); ?>" 
                   name="<?php echo $this->get_field_name('use_test_ad'); ?>" 
                   <?php checked($instance['use_test_ad'], true); ?> />
            <label for="<?php echo $this->get_field_id('use_test_ad'); ?>"><?php _e('Display Test Ad (for layout testing)', 'yomooh-core'); ?></label>
        </p>
        <?php
    }

    public function update($new_instance, $old_instance) {
        $instance = $old_instance;
        $instance['title'] = sanitize_text_field($new_instance['title']);
        $instance['ad_code'] = current_user_can('unfiltered_html') ? $new_instance['ad_code'] : wp_kses_post($new_instance['ad_code']);
        $instance['ad_size'] = sanitize_text_field($new_instance['ad_size']);
        $instance['use_test_ad'] = isset($new_instance['use_test_ad']) ? (bool) $new_instance['use_test_ad'] : false;
        
        return $instance;
    }
}