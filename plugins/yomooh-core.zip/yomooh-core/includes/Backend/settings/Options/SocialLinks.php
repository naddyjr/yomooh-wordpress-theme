<?php
namespace Yomooh\Backend\settings\Options;
use Redux;

use Yomooh\Backend\settings\AdminOptions;

class SocialLinks extends AdminOptions
{
    protected $options;

    public function __construct($opt_name)
    {
        $this->opt_name = $opt_name;
        $this->options = $this->social_fields();
        $this->set_widget_option();
    }

    protected function social_fields()
    {
        return [
            [
                'id'       => 'social_enable',
                'type'     => 'switch',
                'title'    => esc_html__('Enable Social Icons', 'yomooh-core'),
                'subtitle' => esc_html__('Globally enable/disable social icons', 'yomooh-core'),
                'default'  => false,
            ],
            [
                'id'       => 'social_style',
                'type'     => 'button_set',
                'title'    => esc_html__('Icon Style', 'yomooh-core'),
                'subtitle' => esc_html__('Select social icon appearance', 'yomooh-core'),
                'options'  => [
                    'minimal' => 'Minimal',
                    'rounded' => 'Rounded',
                    'square'  => 'Square'
                ],
                'default'  => 'minimal',
                'required' => ['social_enable', '=', true],
            ],
            [
                'id'       => 'social_color',
                'type'     => 'button_set',
                'title'    => esc_html__('Icon Color', 'yomooh-core'),
                'subtitle' => esc_html__('Select social icon color scheme', 'yomooh-core'),
                'options'  => [
                    'brand'   => 'Brand Colors',
                    'custom'  => 'Custom Color',
                    'inherit' => 'Inherit from Theme'
                ],
                'default'  => 'brand',
                'required' => ['social_enable', '=', true],
            ],
            [
                'id'       => 'social_custom_color',
                'type'     => 'color',
                'title'    => esc_html__('Custom Icon Color', 'yomooh-core'),
                'subtitle' => esc_html__('Set custom color for all icons', 'yomooh-core'),
                'required' => [
                    ['social_enable', '=', true],
                    ['social_color', '=', 'custom']
                ],
            ],
            [
                'id'       => 'social_custom_hover',
                'type'     => 'color',
                'title'    => esc_html__('Custom Hover Color', 'yomooh-core'),
                'subtitle' => esc_html__('Set custom hover color for all icons', 'yomooh-core'),
                'required' => [
                    ['social_enable', '=', true],
                    ['social_color', '=', 'custom']
                ],
            ],
            [
                'id'       => 'social_size',
                'type'     => 'dimensions',
                'title'    => esc_html__('Icon Size', 'yomooh-core'),
                'subtitle' => esc_html__('Set social icon dimensions', 'yomooh-core'),
                'units'    => ['px', 'em', 'rem'],
                'default'  => [
                    'width'  => '16px',
                    'height' => '16px',
                ],
                'required' => ['social_enable', '=', true],
            ],
            [
                'id'       => 'social_spacing',
                'type'     => 'spacing',
                'title'    => esc_html__('Icon Spacing', 'yomooh-core'),
                'subtitle' => esc_html__('Set spacing between social icons', 'yomooh-core'),
                'units'    => ['px', 'em', 'rem'],
                'default'  => [
                    'margin-left'  => '15px',
                    'margin-right' => '0px',
                ],
                'required' => ['social_enable', '=', true],
            ],
            [
                'id'       => 'social_links',
                'type'     => 'sortable',
                'mode'     => 'text',
				'label'    => true,
                'title'    => esc_html__('Social Media Links', 'yomooh-core'),
                'subtitle' => esc_html__('Enable and reorder social media links', 'yomooh-core'),
                'options'  => [
                    'facebook'   => '',
                    'twitter'    => '',
                    'instagram'  => '',
                    'linkedin'   => '',
                    'youtube'   => '',
                    'pinterest'  => '',
                    'tiktok'     => '',
                    'whatsapp'   => '',
                    'telegram'   => '',
                    'vimeo'      => '',
                    'reddit'     => '',
                    'discord'    => '',
                ],
                'required' => ['social_enable', '=', true],
            ]
        ];
    }

    protected function set_widget_option()
    {
        \Redux::setSection($this->opt_name, [
            'title'            => esc_html__('Social Media', 'yomooh-core'),
            'id'               => 'social_settings',
            'icon'             => 'el el-share',
            'desc'             => __('Configure all social media links and appearance', 'yomooh-core'),
            'customizer_width' => '500px',
            'fields'           => $this->options,
        ]);
    }
}