<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH')) exit;

class Yomooh_Social_Media_List_Widget extends Widget_Base {

    public function get_name() {
        return 'social-media-list';
    }

    public function get_title() {
        return __('Social Media List', 'yomooh-core');
    }

    public function get_icon() {
        return 'eicon-social-icons';
    }

    public function get_categories() {
        return ['yomooh-elements'];
    }

    protected function register_controls() {
        // Style Tab
        $this->start_controls_section(
            'style_section',
            [
                'label' => __('Style', 'yomooh-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_control(
			'note_important', array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => esc_html__( 'This block will get information from Theme Options > Social media to show.', 'yomooh-core' ),
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
			)
		);

        $this->add_control(
            'icon_size',
            [
                'label' => __('Icon Size', 'yomooh-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em'],
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 100,
                    ],
                    'em' => [
                        'min' => 0.5,
                        'max' => 5,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 16,
                ],
                'selectors' => [
                    '{{WRAPPER}} .yomooh-social-list a i' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'icon_color',
            [
                'label' => __('Icon Color', 'yomooh-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .yomooh-social-list a i' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'icon_hover_color',
            [
                'label' => __('Icon Hover Color', 'yomooh-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .yomooh-social-list a:hover i' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'icon_spacing',
            [
                'label' => __('Spacing', 'yomooh-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 15,
                ],
                'selectors' => [
                    '{{WRAPPER}} .yomooh-social-list li:not(:last-child)' => 'margin-right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'alignment',
            [
                'label' => __('Alignment', 'yomooh-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => __('Left', 'yomooh-core'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'yomooh-core'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'flex-end' => [
                        'title' => __('Right', 'yomooh-core'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .yomooh-social-list' => 'justify-content: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $social_platforms = [
            'facebook' => ['icon' => 'wp-icon-facebook', 'color' => '#3b5998'],
            'twitter' => ['icon' => 'wp-icon-x', 'color' => '#1da1f2'],
            'instagram' => ['icon' => 'wp-icon-instagram', 'color' => '#e1306c'],
            'linkedin' => ['icon' => 'wp-icon-linkedIn', 'color' => '#0077b5'],
            'youtube' => ['icon' => 'icon-youtube', 'color' => '#ff0000'],
            'pinterest' => ['icon' => 'wp-icon-pinterest', 'color' => '#bd081c'],
            'tiktok' => ['icon' => 'wp-icon-tiktok', 'color' => '#010101'],
            'whatsapp' => ['icon' => 'wpi-whatsapp', 'color' => '#25d366'],
            'telegram' => ['icon' => 'icon-telegram', 'color' => '#0088cc'],
            'vimeo' => ['icon' => 'wp-icon-vimeo', 'color' => '#1ab7ea'],
            'reddit' => ['icon' => 'wpi-reddit', 'color' => '#ff4500'],
            'discord' => ['icon' => 'wpi-discord', 'color' => '#7289da'],
        ];

        $options = get_option('yomooh_options');
        $social_links = isset($options['social_links']) ? $options['social_links'] : [];

        // Filter out empty social links
        $active_platforms = array_filter($social_links, function($url) {
            return !empty($url);
        });

        if (empty($active_platforms)) {
            return;
        }

        echo '<ul class="yomooh-social-list">';
        foreach ($active_platforms as $platform => $url) {
            if (isset($social_platforms[$platform])) {
                $icon = $social_platforms[$platform]['icon'];
                $color = $social_platforms[$platform]['color'];
                
                echo '<li>';
                echo '<a href="' . esc_url($url) . '" target="_blank" rel="noopener noreferrer">';
                echo '<i class="' . esc_attr($icon) . '" style="color: ' . esc_attr($color) . '"></i>';
                echo '</a>';
                echo '</li>';
            }
        }
        echo '</ul>';
    }
}