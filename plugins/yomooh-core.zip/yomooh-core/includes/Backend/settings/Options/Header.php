<?php
namespace Yomooh\Backend\settings\Options;
use Redux;

use Yomooh\Backend\settings\AdminOptions;

class Header extends AdminOptions
{
    protected $options;

    public function __construct($opt_name)
    {
        $this->opt_name = $opt_name;
        $this->options = $this->header_fields();
        $this->set_widget_option();
    }

    protected function header_fields()
    {
        return [
            [
                'id'       => 'header_template_shortcode',
                'type'     => 'text',
                'title'    => esc_html__('Header Template Shortcode', 'yomooh-core'),
				'placeholder'    => esc_html__('[yomooh-template id="7"]', 'yomooh-core'),
                'subtitle' => esc_html__('Enter Elementor template shortcode for custom header', 'yomooh-core'),
            ],
			[
                'id'       => 'header_design',
                'type'     => 'button_set',
                'title'    => esc_html__('Header Style', 'yomooh-core'),
                'subtitle' => esc_html__('Select the design variation that you want to use for site', 'yomooh-core'),
				'options' => [
					'default'  => esc_html__( 'Header Default Style', 'yomooh-core' ),
					'style2' => esc_html__( 'Header Style 2', 'yomooh-core' ),
				],
                'default'  => 'default',
            ],
            [
                'id'       => 'header_logo',
                'type'     => 'media',
                'title'    => esc_html__('Main Logo', 'yomooh-core'),
                'subtitle' => esc_html__('Upload your main logo image', 'yomooh-core'),
            ],
            [
                'id'       => 'header_logo_dark',
                'type'     => 'media',
                'title'    => esc_html__('Dark Mode Logo', 'yomooh-core'),
                'subtitle' => esc_html__('Upload logo for dark mode (optional)', 'yomooh-core'),
            ],
            [
                'id'       => 'logo_dimensions',
                'type'     => 'dimensions',
                'title'    => esc_html__('Logo Dimensions', 'yomooh-core'),
                'subtitle' => esc_html__('Set width and height for the logo example (height 40px)', 'yomooh-core'),
                'units'    => ['px'],
                'default'  => [
                    'width'  => '180px',
                    'height' => '40px',
                ],
            ],
            [
                'id'       => 'header_container',
                'type'     => 'button_set',
                'title'    => esc_html__('Header Container', 'yomooh-core'),
                'subtitle' => esc_html__('Select header width type', 'yomooh-core'),
                'options'  => [
                    'full'    => 'Full Width',
                    'custom'  => 'Custom Width'
                ],
                'default'  => 'full',
            ],
			 [
					'id' => 'header_background',
					'type' => 'button_set',
					'title' => esc_html__('Body Background', 'yomooh-core'),
					'subtitle' => esc_html__('Select this option for body background.', 'yomooh-core'),
					'options' => array(
						'1' => esc_html__('Default', 'yomooh-core'),
						'2' => esc_html__('Color', 'yomooh-core'),
						'3' => esc_html__('Transparent', 'yomooh-core'),
					),
					'default' => '1'
				 ],
				[
					'id' => 'header_bg_color',
					'type' => 'color',
					'title' => esc_html__('background color', 'yomooh-core'),
					'subtitle' => esc_html__('Choose header background color', 'yomooh-core'),
					'required' => array('header_background', '=', '2'),
					'default' => '',
					'mode' => 'background',
					'transparent' => false
				 ],
			[
                'id'       => 'header_sticky',
                'type'     => 'switch',
                'title'    => esc_html__('Sticky Header', 'yomooh-core'),
                'subtitle' => esc_html__('Enable sticky header on scroll', 'yomooh-core'),
                'default'  => true,
				'required' => ['header_design', '=', 'default'],
            ],
            [
                'id'       => 'header_search',
                'type'     => 'switch',
                'title'    => esc_html__('Display Search', 'yomooh-core'),
                'subtitle' => esc_html__('Show search icon in header', 'yomooh-core'),
                'default'  => true,
            ],
			[
                'id'       => 'header_isdarkmode',
                'type'     => 'switch',
                'title'    => esc_html__('Display Theme mode', 'yomooh-core'),
                'subtitle' => esc_html__('Show dark and light icon in header', 'yomooh-core'),
                'default'  => true,
            ],
            [
                'id'       => 'header_button',
                'type'     => 'switch',
                'title'    => esc_html__('Display Button', 'yomooh-core'),
                'subtitle' => esc_html__('Show call-to-action button in header', 'yomooh-core'),
                'default'  => false,
            ],
            [
                'id'       => 'header_button_text',
                'type'     => 'text',
                'title'    => esc_html__('Button Text', 'yomooh-core'),
                'subtitle' => esc_html__('Enter button text', 'yomooh-core'),
                'required' => ['header_button', '=', true],
                'default'  => 'Get Started',
            ],
            [
                'id'       => 'header_button_url',
                'type'     => 'text',
                'title'    => esc_html__('Button URL', 'yomooh-core'),
                'subtitle' => esc_html__('Enter button link URL', 'yomooh-core'),
                'required' => ['header_button', '=', true],
                'validate' => 'url',
            ],
            [
                'id'       => 'header_signin_popup',
                'type'     => 'switch',
                'title'    => esc_html__('Popup Sign In', 'yomooh-core'),
                'subtitle' => esc_html__('Enable sign in popup modal', 'yomooh-core'),
                'default'  => false,
            ],
			[
                'id'       => 'header_social_enable',
                'type'     => 'switch',
                'title'    => esc_html__('Show Social icon', 'yomooh-core'),
                'subtitle' => esc_html__('Enable Social media', 'yomooh-core'),
                'default'  => false,
				'required' => ['header_design', '=', 'style2'],
            ]
           
        ];
    }

    protected function set_widget_option()
    {
        \Redux::setSection($this->opt_name, [
            'title'            => esc_html__('Header', 'yomooh-core'),
            'id'               => 'header_settings',
            'icon'             => 'custom-header-main',
            'desc'             => __('Configure all desktop header settings and appearance', 'yomooh-core'),
            'customizer_width' => '500px',
            'fields'           => $this->options,
        ]);
    }
}