<?php
/**
 * ================================
 *  UNUSED CODE – DO NOT USE
 *  Purchase Code Validation System
 *  (Kept here for reference only)
 * ================================
 */

 /*
 // Prevent direct access
 if (!defined('ABSPATH')) {
     exit;
 }

 // Function to validate purchase code
 function somnest_validate_purchase_code($purchase_code) {
     $response = wp_remote_post('https://somnest.net/wp-json/mpcv/v1/validate-code', array(
         'body' => array(
             'code' => $purchase_code,
             'user' => site_url(),
         ),
     ));

     if (is_wp_error($response)) {
         return array('valid' => false, 'message' => 'An error occurred while validating the purchase code.');
     }

     $body = json_decode(wp_remote_retrieve_body($response), true);
     if ($body['valid']) {
         update_option('somnest_purchase_code', $purchase_code);
     }

     return $body;
 }

 // Function to revoke purchase code
 function somnest_revoke_purchase_code() {
     $response = wp_remote_post('https://somnest.net/wp-json/mpcv/v1/revoke-purchase-code');

     if (is_wp_error($response)) {
         return array('success' => false, 'message' => 'An error occurred while revoking the purchase code.');
     }

     $body = json_decode(wp_remote_retrieve_body($response), true);
     if ($body['success']) {
         delete_option('somnest_purchase_code');
     }

     return $body;
 }

 // Handle AJAX request for validation
 add_action('wp_ajax_somnest_validate_purchase_code', 'somnest_handle_validate_purchase_code');
 function somnest_handle_validate_purchase_code() {
     $purchase_code = sanitize_text_field($_POST['purchase_code']);
     $response = somnest_validate_purchase_code($purchase_code);
     wp_send_json($response);
 }

 // Handle AJAX request for revocation
 add_action('wp_ajax_somnest_revoke_purchase_code', 'somnest_handle_revoke_purchase_code');
 function somnest_handle_revoke_purchase_code() {
     $response = somnest_revoke_purchase_code();
     wp_send_json($response);
 }

 // Admin page for activating product
 function somnest_activate_product_page() {
     $purchase_code = get_option('somnest_purchase_code');
     $is_activated = !empty($purchase_code);

     ?>
     <!-- HTML & JS for activation page (commented out) -->
     <?php /*
     yomooh_dashboard('dashboard');
     ?>
     <div class="card5">
         <div class="card5-content">
             <br>
             <?php if ($is_activated): ?>
             <div class="activate-header is-activated">
                 <h1 class="shine">
                     <i class="dashicons-before dashicons-admin-network" aria-hidden="true"></i>
                     <?php echo sprintf( esc_html__( '%s is Activated', 'yomooh-core' ), 'Yomooh theme'); ?>
                 </h1>
                 <p><?php echo sprintf( esc_html__( 'Thank you for choosing %s. Should you have any other concerns while using this plugin,', 'yomooh-core' ), 'Yomooh theme'); ?></p>
                 <p><?php echo sprintf( esc_html__( 'please feel free to contact us at any time.', 'yomooh-core'); ?></p>
             </div>
             <div class="activate-form is-activated">
                 <form method="post" action="" id="deregister-theme-form">
                     <?php wp_nonce_field( 'core', 'core-nonce' ); ?>
                     <div class="panel-input">
                         <label class="panel-label" for="purchase_code"><?php esc_html_e( 'Purchase Code', 'yomooh-core' ); ?></label>
                         <input type="text" value="<?php echo admin_hide_code( $purchase_code ); ?>" name="activated_purchase_code" class="panel-input-text" readonly>
                     </div>
                     <p style="color: green;">Your product is already activated with the purchase code</p>
                     <button id="revoke-purchase-code" class="button button-secondary">Revoke Activation</button>
                 </form>
             </div>
             <?php else: ?>
             <div class="activate-header is-activated">
                 <h1 class="shine">
                     <i class="dashicons-before dashicons-admin-network" aria-hidden="true"></i>
                     <?php echo sprintf( esc_html__( '%s is not Activated', 'yomooh-core' ), 'Yomooh theme' ); ?>
                 </h1>
                 <p><?php echo sprintf( esc_html__( 'Thank you for choosing %s. Should you have any other concerns while using this plugin,', 'yomooh-core' ), 'Somnest'); ?></p>
                 <p><?php echo sprintf( esc_html__( 'please feel free to contact us at any time.', 'yomooh-core'); ?></p>
             </div>
             <br>
             <form id="somnest-activate-product-form">
                 <label for="purchase-code">Enter Purchase Code:</label>
                 <input type="text" id="purchase-code" name="purchase_code" required>
                 <button type="button" id="validate-purchase-code" class="button button-primary">Validate</button>
             </form>
             <div id="validation-result"></div>
             <?php endif; ?>
             <br><br>
             <div class="heading">We're on Social Media</div>
             <div class="icons"> ... </div>
         </div>
     </div>

     // <script>
// jQuery(document).ready(function($) {
//     // Validate purchase code
//     $('#validate-purchase-code').on('click', function() {
//         var purchaseCode = $('#purchase-code').val();
//         if (!purchaseCode) {
//             alert('Please enter a purchase code.');
//             return;
//         }
//         $.ajax({
//             url: '<?php echo admin_url('admin-ajax.php'); ?>',
//             method: 'POST',
//             data: {
//                 action: 'somnest_validate_purchase_code',
//                 purchase_code: purchaseCode
//             },
//             beforeSend: function() {
//                 $('#validation-result').html('<p>Validating...</p>');
//             },
//             success: function(response) {
//                 if (response.valid) {
//                     $('#validation-result').html('<p style="color: green;">' + response.message + '</p>');
//                     location.reload();
//                 } else {
//                     $('#validation-result').html('<p style="color: red;">' + response.message + '</p>');
//                 }
//             },
//             error: function() {
//                 $('#validation-result').html('<p style="color: red;">An error occurred. Please try again.</p>');
//             }
//         });
//     });

//     // Revoke purchase code
//     $('#revoke-purchase-code').on('click', function(e) {
//         e.preventDefault();
//         if (confirm('Are you sure you want to revoke the activation?')) {
//             $.ajax({
//                 url: '<?php echo admin_url('admin-ajax.php'); ?>',
//                 method: 'POST',
//                 data: { action: 'somnest_revoke_purchase_code' },
//                 beforeSend: function() {
//                     $('#activation-status').html('<p>Revoking...</p>');
//                 },
//                 success: function(response) {
//                     if (response.success) {
//                         alert(response.message);
//                         location.reload();
//                     } else {
//                         $('#activation-status').html('<p style="color: red;">' + response.message + '</p>');
//                     }
//                 },
//                 error: function() {
//                     $('#activation-status').html('<p style="color: red;">An error occurred. Please try again.</p>');
//                 }
//             });
//         }
//     });
// });
// </script>
     <?php
 }

 if ( ! function_exists( 'admin_hide_code' ) ) {
     function admin_hide_code( $code = '' ) {
         if ( $code ) {
             return preg_replace( '[[a-z0-9]]', '*', substr( esc_attr( $code ), 0, - 5 ) ) . substr( esc_attr( $code ), - 5, 5 );
         }
         return false;
     }
 }
 */
