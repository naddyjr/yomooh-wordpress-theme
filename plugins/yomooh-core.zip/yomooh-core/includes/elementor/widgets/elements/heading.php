<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Background;

if (!defined('ABSPATH')) exit;

class Yomooh_Widget_Heading extends Widget_Base {

    public function get_name() {
        return 'yomooh_heading';
    }

    public function get_title() {
        return __('Yomooh Heading', 'yomooh-core');
    }

    public function get_icon() {
        return 'eicon-heading';
    }

    public function get_categories() {
        return ['yomooh-elements'];
    }

    protected function register_controls() {
        // Content Tab
        $this->start_controls_section('content_section', [
            'label' => __('Content', 'yomooh-core'),
            'tab' => Controls_Manager::TAB_CONTENT,
        ]);

        $this->add_control('heading_text', [
            'label' => __('Heading Text', 'yomooh-core'),
            'type' => Controls_Manager::TEXT,
            'default' => __('Awesome Heading', 'yomooh-core'),
            'placeholder' => __('Enter your heading', 'yomooh-core'),
            'label_block' => true,
        ]);

        $this->add_control('html_tag', [
            'label' => __('HTML Tag', 'yomooh-core'),
            'type' => Controls_Manager::SELECT,
            'default' => 'h2',
            'options' => [
                'h1' => 'H1',
                'h2' => 'H2',
                'h3' => 'H3',
                'h4' => 'H4',
                'h5' => 'H5',
                'h6' => 'H6',
                'div' => 'div',
                'span' => 'span',
                'p' => 'p',
            ],
        ]);

        $this->add_control('heading_layout', [
            'label' => __('Layout Style', 'yomooh-core'),
            'type' => Controls_Manager::SELECT,
            'default' => '1',
            'options' => [
                '1' => __('1 - Default', 'yomooh-core'),
                '2' => __('2 - Two Slashes', 'yomooh-core'),
                '3' => __('3 - Left Dot', 'yomooh-core'),
                '4' => __('4 - Multiple Underline', 'yomooh-core'),
                '5' => __('5 - Left Border', 'yomooh-core'),
                '6' => __('6 - Bottom Border', 'yomooh-core'),
                '7' => __('7 - Background Highlight', 'yomooh-core'),
                '8' => __('8 - Double Border', 'yomooh-core'),
            ],
        ]);

        $this->end_controls_section();

        // Style Tab
        $this->start_controls_section('style_section', [
            'label' => __('Style', 'yomooh-core'),
            'tab' => Controls_Manager::TAB_STYLE,
        ]);

        $this->add_control('heading_color', [
            'label' => __('Text Color', 'yomooh-core'),
            'type' => Controls_Manager::COLOR,
            'default' => '#222222',
            'selectors' => [
                '{{WRAPPER}} .yomooh-heading' => 'color: {{VALUE}};',
            ],
        ]);

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'heading_typography',
                'selector' => '{{WRAPPER}} .yomooh-heading',
            ]
        );

        $this->add_responsive_control('heading_align', [
            'label' => __('Alignment', 'yomooh-core'),
            'type' => Controls_Manager::CHOOSE,
            'options' => [
                'left' => [
                    'title' => __('Left', 'yomooh-core'),
                    'icon' => 'eicon-text-align-left',
                ],
                'center' => [
                    'title' => __('Center', 'yomooh-core'),
                    'icon' => 'eicon-text-align-center',
                ],
                'right' => [
                    'title' => __('Right', 'yomooh-core'),
                    'icon' => 'eicon-text-align-right',
                ],
            ],
            'default' => 'left',
            'selectors' => [
                '{{WRAPPER}} .yomooh-heading-wrapper' => 'text-align: {{VALUE}};',
            ],
        ]);

        $this->add_responsive_control('heading_margin', [
            'label' => __('Margin', 'yomooh-core'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%', 'em'],
            'selectors' => [
                '{{WRAPPER}} .yomooh-heading-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->add_responsive_control('heading_padding', [
            'label' => __('Padding', 'yomooh-core'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%', 'em'],
            'selectors' => [
                '{{WRAPPER}} .yomooh-heading' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        // Layout Specific Styles
        $this->add_control('layout_style_section', [
            'label' => __('Layout Styles', 'yomooh-core'),
            'type' => Controls_Manager::HEADING,
            'separator' => 'before',
        ]);

        $this->add_control('decorative_color', [
            'label' => __('Decorative Color', 'yomooh-core'),
            'type' => Controls_Manager::COLOR,
            'default' => '#3a7bd5',
            'selectors' => [
                '{{WRAPPER}} .yomooh-heading.layout-2:before, {{WRAPPER}} .yomooh-heading.layout-2:after' => 'background-color: {{VALUE}};',
                '{{WRAPPER}} .yomooh-heading.layout-3:before' => 'background-color: {{VALUE}};',
                '{{WRAPPER}} .yomooh-heading.layout-4:after' => 'background-color: {{VALUE}};',
                '{{WRAPPER}} .yomooh-heading.layout-5' => 'border-left-color: {{VALUE}};',
                '{{WRAPPER}} .yomooh-heading.layout-6:after' => 'background-color: {{VALUE}};',
                '{{WRAPPER}} .yomooh-heading.layout-8:before, {{WRAPPER}} .yomooh-heading.layout-8:after' => 'background-color: {{VALUE}};',
            ],
            'condition' => [
                'heading_layout!' => ['1', '7'],
            ],
        ]);

        $this->add_control('highlight_color', [
            'label' => __('Highlight Color', 'yomooh-core'),
            'type' => Controls_Manager::COLOR,
            'default' => 'rgba(58, 123, 213, 0.1)',
            'selectors' => [
                '{{WRAPPER}} .yomooh-heading.layout-7' => 'background-color: {{VALUE}};',
            ],
            'condition' => [
                'heading_layout' => '7',
            ],
        ]);

        $this->add_control('border_width', [
            'label' => __('Border Width', 'yomooh-core'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => ['min' => 1, 'max' => 10],
            ],
            'default' => ['size' => 4],
            'selectors' => [
                '{{WRAPPER}} .yomooh-heading.layout-5' => 'border-left-width: {{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .yomooh-heading.layout-6:after' => 'height: {{SIZE}}{{UNIT}};',
            ],
            'conditions' => [
                'relation' => 'or',
                'terms' => [
                    ['name' => 'heading_layout', 'operator' => '==', 'value' => '5'],
                    ['name' => 'heading_layout', 'operator' => '==', 'value' => '6'],
                ],
            ],
        ]);

        $this->add_control('dot_size', [
            'label' => __('Dot Size', 'yomooh-core'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => ['min' => 5, 'max' => 20],
            ],
            'default' => ['size' => 10],
            'selectors' => [
                '{{WRAPPER}} .yomooh-heading.layout-3:before' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
            ],
            'condition' => [
                'heading_layout' => '3',
            ],
        ]);

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $layout_class = 'layout-' . $settings['heading_layout'];
        
        $this->add_render_attribute('heading_wrapper', 'class', 'yomooh-heading-wrapper');
        $this->add_render_attribute('heading', [
            'class' => ['yomooh-heading', $layout_class],
        ]);
        
        printf(
            '<div %s><%s %s>%s</%s></div>',
            $this->get_render_attribute_string('heading_wrapper'),
            $settings['html_tag'],
            $this->get_render_attribute_string('heading'),
            $settings['heading_text'],
            $settings['html_tag']
        );
    }
}