<?php
namespace Yomooh\Backend\settings\Options;
use Redux;

use Yomooh\Backend\settings\AdminOptions;

class MobileHeader extends AdminOptions
{
    protected $options;

    public function __construct($opt_name)
    {
        $this->opt_name = $opt_name;
        $this->options = $this->mobile_header_fields();
        $this->set_widget_option();
    }

    protected function mobile_header_fields()
    {
        return [
            [
                'id'       => 'mobile_header_template_shortcode',
                'type'     => 'text',
                'title'    => esc_html__('Mobile Header Template', 'yomooh-core'),
				'placeholder'    => esc_html__('[yomooh-template id="7"]', 'yomooh-core'),
                'subtitle' => esc_html__('Enter Elementor template shortcode for mobile header', 'yomooh-core'),
            ],
            [
                'id'       => 'mobile_header_logo',
                'type'     => 'media',
                'title'    => esc_html__('Mobile Logo', 'yomooh-core'),
                'subtitle' => esc_html__('Upload logo specifically for mobile devices', 'yomooh-core'),
            ],
            [
                'id'       => 'mobile_header_logo_dark',
                'type'     => 'media',
                'title'    => esc_html__('Mobile Dark Logo', 'yomooh-core'),
                'subtitle' => esc_html__('Upload dark mode logo for mobile', 'yomooh-core'),
            ],
            [
                'id'       => 'mobile_logo_height',
                'type'     => 'dimensions',
                'title'    => esc_html__('Mobile Logo Dimensions', 'yomooh-core'),
                'subtitle' => esc_html__('Set height for mobile logo (width auto)', 'yomooh-core'),
				'units_extended'    => true,
                'width'    => false,
            ],
            [
                'id'       => 'mobile_header_layout',
                'type'     => 'button_set',
                'title'    => esc_html__('Logo Position', 'yomooh-core'),
                'subtitle' => esc_html__('Select mobile logo alignment', 'yomooh-core'),
                'options'  => [
                    'left'   => 'Left',
                    'center' => 'Center',
                    'right'  => 'Right'
                ],
                'default'  => 'left',
            ],
            [
                'id'       => 'mobile_nav_height',
                'type'     => 'dimensions',
                'title'    => esc_html__('Navigation Height', 'yomooh-core'),
                'subtitle' => esc_html__('Set height for mobile navigation bar (example 60px)', 'yomooh-core'),
                'units'    => ['px'],
                'width'    => false,
            ],
            [
                'id'       => 'mobile_header_sticky',
                'type'     => 'switch',
                'title'    => esc_html__('Sticky Mobile Header', 'yomooh-core'),
                'subtitle' => esc_html__('Enable sticky header on mobile', 'yomooh-core'),
                'default'  => true,
            ],
            [
                'id'       => 'mobile_header_bg',
                'type'     => 'color',
                'title'    => esc_html__('Mobile Header Background', 'yomooh-core'),
                'subtitle' => esc_html__('Set mobile header background color', 'yomooh-core'),
				'default' => '',
				'mode' => 'background',
				'transparent' => false
            ],
			[
                'id'       => 'mobile_menu_style',
                'type'     => 'button_set',
                'title'    => esc_html__('Mobile Menu Style', 'yomooh-core'),
                'subtitle' => esc_html__('Select mobile menu display style', 'yomooh-core'),
                'options'  => [
                    'dropdown' => 'Dropdown',
                    'sidebar' => 'Sidebar'
                ],
                'default'  => 'sidebar',
            ],
			[
                'id'       => 'header_mobile_isdarkmode',
                'type'     => 'switch',
                'title'    => esc_html__('Display Theme mode', 'yomooh-core'),
                'subtitle' => esc_html__('Show dark and light icon in header', 'yomooh-core'),
                'default'  => true,
            ],
            [
                'id'       => 'mobile_search_icon',
                'type'     => 'switch',
                'title'    => esc_html__('Show Search Icon', 'yomooh-core'),
                'subtitle' => esc_html__('Display search icon in mobile header', 'yomooh-core'),
                'default'  => true,
            ],
            [
                'id'       => 'mobile_header_signin_popup',
                'type'     => 'switch',
                'title'    => esc_html__('Popup Sign In', 'yomooh-core'),
                'subtitle' => esc_html__('Enable sign in popup modal in mobile header', 'yomooh-core'),
                'default'  => false,
            ]
            
        ];
    }

    protected function set_widget_option()
    {
        \Redux::setSection($this->opt_name, [
            'title'            => esc_html__('Mobile Header', 'yomooh-core'),
            'id'               => 'mobile_header_settings',
			'icon'  => 'custom-customizer',
            'subsection'       => true,
            'parent'           => 'header_settings',
            'desc'             => __('Configure all mobile header settings and responsive behavior', 'yomooh-core'),
            'customizer_width' => '500px',
            'fields'           => $this->options,
        ]);
    }
}