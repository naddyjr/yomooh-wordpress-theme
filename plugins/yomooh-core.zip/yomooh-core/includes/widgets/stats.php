<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class Yomooh_Stats_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct(
            'yomooh_stats_widget',
            __('Yomooh Stats', 'yomooh-core'),
            array(
                'description' => __('Display website statistics with icons.', 'yomooh-core'),
                'customize_selective_refresh' => true,
            )
        );
    }

    public function widget($args, $instance) {
        $title = apply_filters('widget_title', empty($instance['title']) ? '' : $instance['title'], $instance, $this->id_base);
        $show_users = !empty($instance['show_users']);
        $show_posts = !empty($instance['show_posts']);
        $show_comments = !empty($instance['show_comments']);
        
        // Get counts
        $user_count = count_users();
        $post_count = wp_count_posts()->publish;
        $comment_count = wp_count_comments()->approved;

        echo $args['before_widget'];

        if ($title) {
            echo $args['before_title'] . esc_html($title) . $args['after_title'];
        }

        $stats = array();
        
        if ($show_users) {
            $stats[] = array(
                'icon' => 'fas fa-users',
                'label' => __('Users', 'yomooh-core'),
                'count' => $user_count['total_users'],
                'class' => 'stat-users'
            );
        }
        
        if ($show_posts) {
            $stats[] = array(
                'icon' => 'fas fa-file-alt',
                'label' => __('Posts', 'yomooh-core'),
                'count' => $post_count,
                'class' => 'stat-posts'
            );
        }
        
        if ($show_comments) {
            $stats[] = array(
                'icon' => 'fas fa-comments',
                'label' => __('Comments', 'yomooh-core'),
                'count' => $comment_count,
                'class' => 'stat-comments'
            );
        }

        if (!empty($stats)) {
            echo '<div class="yomooh-stats-widget">';
            
            foreach ($stats as $stat) {
                echo '<div class="stat-item ' . esc_attr($stat['class']) . '">';
                echo '<div class="stat-icon"><i class="' . esc_attr($stat['icon']) . '"></i></div>';
                echo '<div class="stat-content">';
                echo '<div class="stat-label">' . esc_html($stat['label']) . '</div>';
                echo '<div class="stat-count">' . esc_html($this->format_number($stat['count'])) . '</div>';
                echo '</div>';
                echo '</div>';
            }
            
            echo '</div>';
        }

        echo $args['after_widget'];
    }

    private function format_number($number) {
        if ($number >= 1000000) {
            return round($number / 1000000, 1) . 'M';
        } elseif ($number >= 1000) {
            return round($number / 1000, 1) . 'K';
        }
        return $number;
    }

    public function form($instance) {
        $defaults = array(
            'title' => '',
            'show_users' => true,
            'show_posts' => true,
            'show_comments' => true
        );
        
        $instance = wp_parse_args((array) $instance, $defaults);
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:', 'yomooh-core'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" 
                   name="<?php echo $this->get_field_name('title'); ?>" 
                   type="text" value="<?php echo esc_attr($instance['title']); ?>" />
        </p>
        
        <p>
            <input class="checkbox" type="checkbox" id="<?php echo $this->get_field_id('show_users'); ?>" 
                   name="<?php echo $this->get_field_name('show_users'); ?>" 
                   <?php checked($instance['show_users'], true); ?> />
            <label for="<?php echo $this->get_field_id('show_users'); ?>"><?php _e('Display Users Count', 'yomooh-core'); ?></label>
        </p>
        
        <p>
            <input class="checkbox" type="checkbox" id="<?php echo $this->get_field_id('show_posts'); ?>" 
                   name="<?php echo $this->get_field_name('show_posts'); ?>" 
                   <?php checked($instance['show_posts'], true); ?> />
            <label for="<?php echo $this->get_field_id('show_posts'); ?>"><?php _e('Display Posts Count', 'yomooh-core'); ?></label>
        </p>
        
        <p>
            <input class="checkbox" type="checkbox" id="<?php echo $this->get_field_id('show_comments'); ?>" 
                   name="<?php echo $this->get_field_name('show_comments'); ?>" 
                   <?php checked($instance['show_comments'], true); ?> />
            <label for="<?php echo $this->get_field_id('show_comments'); ?>"><?php _e('Display Comments Count', 'yomooh-core'); ?></label>
        </p>
        <?php
    }

    public function update($new_instance, $old_instance) {
        $instance = $old_instance;
        $instance['title'] = sanitize_text_field($new_instance['title']);
        $instance['show_users'] = isset($new_instance['show_users']) ? (bool) $new_instance['show_users'] : false;
        $instance['show_posts'] = isset($new_instance['show_posts']) ? (bool) $new_instance['show_posts'] : false;
        $instance['show_comments'] = isset($new_instance['show_comments']) ? (bool) $new_instance['show_comments'] : false;
        
        return $instance;
    }
}