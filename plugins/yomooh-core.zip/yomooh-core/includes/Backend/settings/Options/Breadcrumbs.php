<?php
namespace Yomooh\Backend\settings\Options;
use Redux;

use Yomooh\Backend\settings\AdminOptions;

class Breadcrumbs extends AdminOptions
{
    protected $options;

    public function __construct($opt_name)
    {
        $this->opt_name = $opt_name;
        $this->options = $this->breadcrumbs_fields();
        $this->set_widget_option();
    }

    protected function breadcrumbs_fields()
    {
        return [
            [
                'id'       => 'breadcrumbs_enable',
                'type'     => 'switch',
                'title'    => esc_html__('Enable Breadcrumbs', 'yomooh-core'),
                'subtitle' => esc_html__('Display breadcrumbs navigation', 'yomooh-core'),
                'default'  => true,
            ],
            [
                'id'       => 'breadcrumbs_home_text',
                'type'     => 'text',
                'title'    => esc_html__('Home Text', 'yomooh-core'),
                'subtitle' => esc_html__('Text for home link', 'yomooh-core'),
                'default'  => esc_html__('Home', 'yomooh-core'),
                'required' => ['breadcrumbs_enable', '=', true],
            ],
            [
                'id'       => 'breadcrumbs_separator',
                'type'     => 'text',
                'title'    => esc_html__('Separator', 'yomooh-core'),
                'subtitle' => esc_html__('Character between breadcrumb items', 'yomooh-core'),
                'default'  => '/',
                'required' => ['breadcrumbs_enable', '=', true],
            ],
            [
                'id'       => 'breadcrumbs_show_current',
                'type'     => 'switch',
                'title'    => esc_html__('Show Current Page', 'yomooh-core'),
                'subtitle' => esc_html__('Display current page title in breadcrumbs', 'yomooh-core'),
                'default'  => true,
                'required' => ['breadcrumbs_enable', '=', true],
            ],
			[
                'id'       => 'breadcrumbs_position',
                'type'     => 'select',
                'title'    => esc_html__('Breadcrumb Position', 'yomooh-core'),
                'subtitle' => esc_html__('Choose the position for all page breadcrumb if enabled.', 'yomooh-core'),
                'options'  => [
                    'left' => 'Left',
                    'center'  => 'Center',
                ],
                'default'  => 'left',
            ],
			[
                'id'       => 'page_breadcrumbs_enable',
                'type'     => 'switch',
                'title'    => esc_html__('Single Page Breadcrumb', 'yomooh-core'),
                'subtitle' => esc_html__('Enable or disable the breadcrumb bar in the single page.', 'yomooh-core'),
                'default'  => true,
            ],
			[
                'id'       => 'archive_breadcrumbs_enable',
                'type'     => 'switch',
                'title'    => esc_html__('Archive Breadcrumb', 'yomooh-core'),
                'subtitle' => esc_html__('Enable or disable the breadcrumb in the archive pages.
', 'yomooh-core'),
                'default'  => true,
            ],
			[
                'id'       => 'post_breadcrumbs_enable',
                'type'     => 'switch',
                'title'    => esc_html__('Single Post Breadcrumb', 'yomooh-core'),
                'subtitle' => esc_html__('Enable or disable the breadcrumb bar in the single post.', 'yomooh-core'),
                'default'  => true,
            ],
			[
                'id'       => 'category_breadcrumbs_enable',
                'type'     => 'switch',
                'title'    => esc_html__('Category Breadcrumb', 'yomooh-core'),
                'subtitle' => esc_html__('Enable or disable the breadcrumb in the category pages.
', 'yomooh-core'),
                'default'  => true,
            ],
			[
                'id'       => 'search_breadcrumbs_enable',
                'type'     => 'switch',
                'title'    => esc_html__('Search Breadcrumb', 'yomooh-core'),
                'subtitle' => esc_html__('Enable or disable the breadcrumb in the search page.
', 'yomooh-core'),
                'default'  => true,
            ]
        ];
    }

    protected function set_widget_option()
    {
        \Redux::setSection($this->opt_name, [
            'title'            => esc_html__('Breadcrumbs', 'yomooh-core'),
            'id'               => 'breadcrumbs_settings',
            'icon'             => 'el el-random',
            'desc'             => __('Configure breadcrumbs navigation settings', 'yomooh-core'),
            'customizer_width' => '500px',
            'fields'           => $this->options,
        ]);
    }
}