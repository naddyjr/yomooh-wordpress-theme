<?php
namespace Yomooh\Backend\settings\Options;
use Redux;

use Yomooh\Backend\settings\AdminOptions;

class BodyLayout extends AdminOptions
{
    protected $options;

    public function __construct($opt_name)
    {
        $this->opt_name = $opt_name;
        $this->options = $this->body_layout_fields();
        $this->set_widget_option();
    }

    protected function body_layout_fields()
    {
        return [
            [
                'id'       => 'site_layout',
                'type'     => 'button_set',
                'title'    => esc_html__('Site Layout', 'yomooh-core'),
                'subtitle' => esc_html__('Select overall site layout style', 'yomooh-core'),
				'options'  => [
                    'default' => 'Default Layout',
                    'boxed' => 'Boxed Layout',
                ],
                'default'  => 'default',
            ],
             [
					'id' => 'body_backg_option',
					'type' => 'button_set',
					'title' => esc_html__('Body Background', 'yomooh-core'),
					'subtitle' => esc_html__('Select this option for body background.', 'yomooh-core'),
					'options' => array(
						'1' => esc_html__('Default', 'yomooh-core'),
						'2' => esc_html__('Color', 'yomooh-core'),
						'3' => esc_html__('Image', 'yomooh-core'),
					),
					'default' => '1'
				 ],
                [
					'id' => 'body_bg_color',
					'type' => 'color',
					'title' => esc_html__('background color', 'yomooh-core'),
					'subtitle' => esc_html__('Choose body background color', 'yomooh-core'),
					'required' => array('body_backg_option', '=', '2'),
					'default' => '',
					'mode' => 'background',
					'transparent' => false
				 ],

				[
					'id' => 'body_bg_image',
					'type' => 'media',
					'url' => false,
					'read-only' => false,
					'required' => array('body_backg_option', '=', '3'),
					'title' => esc_html__('background image.', 'yomooh-core'),
					'subtitle' => esc_html__('Choose body background image.', 'yomooh-core'),
				 ],
               [  'id' => 'is_page_padding',
					'type' => 'button_set',
					'title' => esc_html__('Page Padding', 'yomooh-core'),
					'subtitle'  =>  esc_html__('Adjust padding of your site pages.', 'yomooh-core'),
					'options' => array(
						'default' => esc_html__('Default', 'yomooh-core'),
						'custom' => esc_html__('Custom', 'yomooh-core'),
					),
					'default' => 'default'
                    ],
            [
                'id'       => 'body_padding',
                'type'     => 'spacing',
                'title'    => esc_html__('Body Padding', 'yomooh-core'),
                'subtitle' => esc_html__('Set padding around main content', 'yomooh-core'),
                'units'    => ['px', 'em', 'rem'],
                'required' => array('is_page_padding', '=', 'custom'),

            ]
        ];
    }

    protected function set_widget_option()
    {
        \Redux::setSection($this->opt_name, [
            'title'            => esc_html__('Body Layout', 'yomooh-core'),
            'id'               => 'body_layout_settings',
            'icon'             => 'el el-website',
            'desc'             => __('Configure global site layout and container settings', 'yomooh-core'),
            'customizer_width' => '500px',
            'fields'           => $this->options,
        ]);
    }
}