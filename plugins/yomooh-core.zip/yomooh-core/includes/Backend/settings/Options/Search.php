<?php
namespace Yomooh\Backend\settings\Options;
use Redux;
use Yomooh\Backend\settings\AdminOptions;

class Search extends AdminOptions
{
    protected $options;

    public function __construct($opt_name)
    {
        $this->opt_name = $opt_name;
        $this->options = $this->dependent_options();
        $this->set_widget_option();
    }

    protected function get_registered_sidebars()
    {
        return [
            'sidebar-1'    => __('Sidebar (Default)', 'yomooh-core'),
            'sidebar-blog' => __('Blog Sidebar', 'yomooh-core'),
            'sidebar-spage' => __('Single Page Sidebar', 'yomooh-core'),
            'sidebar-sblog' => __('Single Blog Sidebar', 'yomooh-core')
        ];
    }

    protected function dependent_options()
    {

        return [
            [
                'id'       => 'search_template_shortcode',
                'type'     => 'text',
                'title'    => esc_html__('Search Template Shortcode', 'yomooh-core'),
				'placeholder'    => esc_html__('[yomooh-template id="7"]', 'yomooh-core'),
                'subtitle' => esc_html__('Enter shortcode for custom search template', 'yomooh-core'),
                'default'  => '',
            ],
            [
                'id'       => 'search_layout',
                'type'     => 'image_select',
                'title'    => esc_html__('Search Page Layout', 'yomooh-core'),
                'subtitle' => esc_html__('Choose layout for search results page', 'yomooh-core'),
                'options'  => [
                    'left-sidebar' => [
                        'alt' => 'Left Sidebar',
                        'img' => YOMOOH_PLUGIN_URL . 'includes/Backend/settings/assets/images/left-sidebar.png'
                    ],
                    'right-sidebar' => [
                        'alt' => 'Right Sidebar',
                        'img' => YOMOOH_PLUGIN_URL . 'includes/Backend/settings/assets/images/sidebar-right.png'
                    ],
                    'no-sidebar' => [
                        'alt' => 'No Sidebar',
                        'img' => YOMOOH_PLUGIN_URL . 'includes/Backend/settings/assets/images/column-one.png'
                    ],
                ],
                'default'  => 'right-sidebar',
            ],
            [
                'id'       => 'search_sidebar',
                'type'     => 'select',
                'title'    => esc_html__('Assign a Sidebar', 'yomooh-core'),
                'subtitle' => esc_html__('Select which sidebar to display on search results', 'yomooh-core'),
                'options'  => $this->get_registered_sidebars(),
                'default'  => 'sidebar-1',
                'required' => ['search_layout', '!=', 'no-sidebar'],
            ],
			[
                'id'       => 'search_post_types',
                'type'     => 'textarea',
                'title'    => esc_html__('Searchable Post Types', 'yomooh-core'),
                'subtitle' => esc_html__('Select which post types to include in search results', 'yomooh-core'),
                'description' => esc_html__( 'Enter multiple post_type keys, using by commas. Leave blank to allow any post types.', 'yomooh-core' ),
					'placeholder' => 'post,',
					'default'     => 'post,',
					'rows'        => 1,
            ],
            [
                'id'       => 'disallow_search_post_types',
                'type'     => 'textarea',
                'title'    => esc_html__('Disallow Post Types', 'yomooh-core'),
                'subtitle' => esc_html__('The search page will not display any results for post types listed in this section.', 'yomooh-core'),
				'description' => esc_html__( 'Enter multiple post_type keys, using by commas. Leave blank for unrestricted access to any post types.', 'yomooh-core' ),
                'placeholder' => 'page, attachment',
				'default'     => 'page, attachment, e-landing-page',
				'rows'        => 1,
            ],
            [
                'id'       => 'search_pagination',
                'type'     => 'switch',
                'title'    => esc_html__('Enable Pagination', 'yomooh-core'),
                'subtitle' => esc_html__('Show pagination on search results', 'yomooh-core'),
                'default'  => true,
            ],
            [
                'id'       => 'search_results_per_page',
                'type'     => 'spinner',
                'title'    => esc_html__('Results Per Page', 'yomooh-core'),
                'subtitle' => esc_html__('Number of search results to show per page', 'yomooh-core'),
                'default'  => 10,
                'min'      => 1,
                'step'     => 1,
                'max'      => 50,
                'required' => ['search_pagination', '=', true],
            ],
            [
                'id'       => 'search_highlight',
                'type'     => 'switch',
                'title'    => esc_html__('Highlight Search Terms', 'yomooh-core'),
                'subtitle' => esc_html__('Highlight matching search terms in results', 'yomooh-core'),
                'default'  => true,
            ]
        ];
    }

    protected function set_widget_option()
    {
        \Redux::setSection($this->opt_name, [
            'title'            => esc_html__('Search Settings', 'yomooh-core'),
            'id'               => 'search_settings',
            'icon'             => 'el el-search',
            'desc'             => __('Configure how search functionality works on your site', 'yomooh-core'),
            'customizer_width' => '500px',
            'fields'           => $this->options,
        ]);
    }
}