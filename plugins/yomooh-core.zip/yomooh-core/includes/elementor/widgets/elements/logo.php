<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;

if (!defined('ABSPATH')) exit;

class Yomooh_Widget_Logo extends Widget_Base {

    public function get_name() {
        return 'yomooh_logo';
    }

    public function get_title() {
        return __('Yomooh Logo', 'yomooh-core');
    }

    public function get_icon() {
        return 'eicon-site-logo';
    }

    public function get_categories() {
    return ['yomooh-elements'];
    }

    protected function register_controls() {
        // Content Section
        $this->start_controls_section('content_section', [
            'label' => __('Content', 'yomooh-core'),
            'tab' => Controls_Manager::TAB_CONTENT,
        ]);

        $this->add_control('logo_image_light', [
            'label' => __('Light Mode Logo', 'yomooh-core'),
            'type' => Controls_Manager::MEDIA,
            'default' => [
                'url' => '',
            ],
        ]);

        $this->add_control('logo_image_dark', [
            'label' => __('Dark Mode Logo', 'yomooh-core'),
            'type' => Controls_Manager::MEDIA,
            'description' => __('Optional - Will use light logo if not set', 'yomooh-core'),
        ]);

        $this->add_control('logo_link', [
            'label' => __('Logo Link', 'yomooh-core'),
            'type' => Controls_Manager::URL,
            'placeholder' => __('https://yoursite.com', 'yomooh-core'),
        ]);

        $this->add_control('use_site_title', [
            'label' => __('Use Site Title as Fallback', 'yomooh-core'),
            'type' => Controls_Manager::SWITCHER,
            'label_on' => __('Yes', 'yomooh-core'),
            'label_off' => __('No', 'yomooh-core'),
            'return_value' => 'yes',
            'default' => 'yes',
            'condition' => [
                'logo_image_light[url]' => '',
            ],
        ]);

        $this->end_controls_section();

        // Style Section
        $this->start_controls_section('style_section', [
            'label' => __('Style', 'yomooh-core'),
            'tab' => Controls_Manager::TAB_STYLE,
        ]);

        $this->add_responsive_control('logo_width', [
            'label' => __('Width', 'yomooh-core'),
            'type' => Controls_Manager::SLIDER,
            'size_units' => ['px', '%', 'em', 'rem', 'vw'],
            'range' => [
                'px' => ['min' => 10, 'max' => 1000],
                '%' => ['min' => 1, 'max' => 100],
            ],
            'selectors' => [
                '{{WRAPPER}} .yomooh-logo' => 'width: {{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .yomooh-logo-text' => 'max-width: {{SIZE}}{{UNIT}};',
            ],
        ]);

        $this->add_responsive_control('logo_height', [
            'label' => __('Height', 'yomooh-core'),
            'type' => Controls_Manager::SLIDER,
            'size_units' => ['px', '%', 'em', 'rem', 'vh'],
            'range' => [
                'px' => ['min' => 10, 'max' => 1000],
            ],
            'selectors' => [
                '{{WRAPPER}} .yomooh-logo' => 'height: {{SIZE}}{{UNIT}};',
            ],
        ]);

        $this->add_responsive_control('alignment', [
            'label' => __('Alignment', 'yomooh-core'),
            'type' => Controls_Manager::CHOOSE,
            'options' => [
                'flex-start' => [
                    'title' => __('Left', 'yomooh-core'),
                    'icon' => 'eicon-text-align-left',
                ],
                'center' => [
                    'title' => __('Center', 'yomooh-core'),
                    'icon' => 'eicon-text-align-center',
                ],
                'flex-end' => [
                    'title' => __('Right', 'yomooh-core'),
                    'icon' => 'eicon-text-align-right',
                ],
            ],
            'default' => 'flex-start',
            'selectors' => [
                '{{WRAPPER}} .yomooh-logo-wrapper' => 'display: flex; justify-content: {{VALUE}};',
            ],
            'toggle' => true,
        ]);

        $this->add_control('hover_animation', [
            'label' => __('Hover Animation', 'yomooh-core'),
            'type' => Controls_Manager::HOVER_ANIMATION,
        ]);

        $this->end_controls_section();

        // Text Fallback Style
        $this->start_controls_section('text_style_section', [
            'label' => __('Text Fallback Style', 'yomooh-core'),
            'tab' => Controls_Manager::TAB_STYLE,
            'condition' => [
                'use_site_title' => 'yes',
                'logo_image_light[url]' => '',
            ],
        ]);

        $this->add_control('text_color', [
            'label' => __('Text Color', 'yomooh-core'),
            'type' => Controls_Manager::COLOR,
            'default' => '#ff0000',
            'selectors' => [
                '{{WRAPPER}} .yomooh-logo-text' => 'color: {{VALUE}};',
            ],
        ]);

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'text_typography',
                'selector' => '{{WRAPPER}} .yomooh-logo-text',
            ]
        );

        $this->end_controls_section();

        // Advanced Section
        $this->start_controls_section('advanced_section', [
            'label' => __('Advanced', 'yomooh-core'),
            'tab' => Controls_Manager::TAB_ADVANCED,
        ]);

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'logo_border',
                'selector' => '{{WRAPPER}} .yomooh-logo, {{WRAPPER}} .yomooh-logo-text',
            ]
        );

        $this->add_control('logo_border_radius', [
            'label' => __('Border Radius', 'yomooh-core'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%'],
            'selectors' => [
                '{{WRAPPER}} .yomooh-logo, {{WRAPPER}} .yomooh-logo-text' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'logo_box_shadow',
                'selector' => '{{WRAPPER}} .yomooh-logo, {{WRAPPER}} .yomooh-logo-text',
            ]
        );

        $this->add_control('logo_opacity', [
            'label' => __('Opacity', 'yomooh-core'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => ['max' => 1, 'min' => 0, 'step' => 0.01],
            ],
            'selectors' => [
                '{{WRAPPER}} .yomooh-logo, {{WRAPPER}} .yomooh-logo-text' => 'opacity: {{SIZE}};',
            ],
        ]);

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $light_logo = $settings['logo_image_light']['url'];
        $dark_logo = $settings['logo_image_dark']['url'] ?? $light_logo;
        $link = $settings['logo_link']['url'] ?? home_url('/');
        $animation_class = !empty($settings['hover_animation']) ? 'elementor-animation-' . $settings['hover_animation'] : '';
        $use_site_title = $settings['use_site_title'] === 'yes';

        $this->add_render_attribute('logo_wrapper', 'class', 'yomooh-logo-wrapper');
        $this->add_render_attribute('logo_link', [
            'href' => esc_url($link),
            'class' => 'yomooh-logo-link',
        ]);

        // If no logo image is set and fallback is enabled
        if (empty($light_logo) && $use_site_title) {
            $site_title = get_bloginfo('name');
            $formatted_title = ucwords($site_title);
            
            $this->add_render_attribute('logo_text', [
                'class' => 'yomooh-logo-text',
            ]);
            ?>
            <div <?php echo $this->get_render_attribute_string('logo_wrapper'); ?>>
                <a <?php echo $this->get_render_attribute_string('logo_link'); ?>>
                    <span <?php echo $this->get_render_attribute_string('logo_text'); ?>>
                        <?php echo esc_html($formatted_title); ?>
                    </span>
                </a>
            </div>
            <?php
        } else {
            $this->add_render_attribute('logo_img', [
                'src' => esc_url($light_logo),
                'alt' => get_bloginfo('name'),
                'class' => 'yomooh-logo light-logo ' . $animation_class,
            ]);
            $this->add_render_attribute('logo_img_dark', [
                'src' => esc_url($dark_logo),
                'alt' => get_bloginfo('name'),
                'class' => 'yomooh-logo dark-logo ' . $animation_class,
            ]);
            ?>
            <div <?php echo $this->get_render_attribute_string('logo_wrapper'); ?>>
                <a <?php echo $this->get_render_attribute_string('logo_link'); ?>>
                    <img <?php echo $this->get_render_attribute_string('logo_img'); ?> />
                    <?php if ($dark_logo !== $light_logo) : ?>
                        <img <?php echo $this->get_render_attribute_string('logo_img_dark'); ?> />
                    <?php endif; ?>
                </a>
            </div>
            <?php
        }
    }
}