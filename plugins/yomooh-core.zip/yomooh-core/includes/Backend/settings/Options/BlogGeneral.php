<?php
namespace Yomooh\Backend\settings\Options;
use Redux;

use Yomooh\Backend\settings\AdminOptions;

class BlogGeneral extends AdminOptions
{
    protected $options;

    public function __construct($opt_name)
    {
        $this->opt_name = $opt_name;
        $this->options = $this->blog_general_fields();
        $this->set_widget_option();
    }
protected function get_registered_sidebars()
    {
        return [
            'sidebar-1'    => __('Sidebar (Default)', 'yomooh-core'),
            'sidebar-blog' => __('Blog Sidebar', 'yomooh-core'),
            'sidebar-spage' => __('Single Page Sidebar', 'yomooh-core'),
            'sidebar-sblog' => __('Single Blog Sidebar', 'yomooh-core')
        ];
    }
    protected function blog_general_fields()
    {
        return [
            [
                'id'       => 'blog_layout',
                'type'     => 'button_set',
                'title'    => esc_html__('Blog Layout', 'yomooh-core'),
                'subtitle' => esc_html__('Select blog archive layout', 'yomooh-core'),
				'options' => [
					'standard'  => esc_html__( 'Standard', 'yomooh-core' ),
					'grid' => esc_html__( 'Grid', 'yomooh-core' ),
                    'list' => esc_html__( 'List', 'yomooh-core' ),
				],
                'default'  => 'standard',
            ],
            [
                'id'       => 'blog_columns',
                'type'     => 'button_set',
                'title'    => esc_html__('Columns', 'yomooh-core'),
                'subtitle' => esc_html__('Number of columns for grid/masonry layout', 'yomooh-core'),
                'options'  => [
                    '2' => '2 Columns',
                    '3' => '3 Columns',
                    '4' => '4 Columns'
                ],
                'default'  => '3',
                'required' => ['blog_layout', '=', 'grid'],
            ],
            [
                'id'       => 'blog_sidebar',
                'type'     => 'button_set',
                'title'    => esc_html__('Sidebar Position', 'yomooh-core'),
                'subtitle' => esc_html__('Select sidebar position for blog', 'yomooh-core'),
				'options' => [
					'left-sidebar'  => esc_html__( 'Left Sidebar', 'yomooh-core' ),
					'right-sidebar' => esc_html__( 'Right Sidebar', 'yomooh-core' ),
                    'no-sidebar' => esc_html__( 'No Sidebar', 'yomooh-core' ),
				],
                'default'  => 'right-sidebar',
            ],
            [
                'id'       => 'blogarchive_sidebar',
                'type'     => 'select',
                'title'    => esc_html__('Assign a Sidebar', 'yomooh-core'),
                'subtitle' => esc_html__('Select which sidebar to display on blog archive pages', 'yomooh-core'),
                'options'  => $this->get_registered_sidebars(),
                'default'  => 'sidebar-1',
                'required' => ['blog_sidebar', '!=', 'no-sidebar'],
            ],
            [
                'id'       => 'blog_posts_per_page',
                'type'     => 'spinner',
                'title'    => esc_html__('Posts Per Page', 'yomooh-core'),
                'subtitle' => esc_html__('Number of posts to show per page', 'yomooh-core'),
                'default'  => '10',
                'min'      => '1',
                'step'     => '1',
                'max'      => '50',
            ],
            [
                'id'       => 'blog_excerpt_length',
                'type'     => 'spinner',
                'title'    => esc_html__('Excerpt Length', 'yomooh-core'),
                'subtitle' => esc_html__('Number of words in post excerpt', 'yomooh-core'),
                'default'  => '30',
                'min'      => '10',
                'step'     => '5',
                'max'      => '100',
            ],
            [
                'id'       => 'blog_pagination',
                'type'     => 'button_set',
                'title'    => esc_html__('Pagination Type', 'yomooh-core'),
                'subtitle' => esc_html__('Select blog pagination style', 'yomooh-core'),
                'options'  => [
                    'standard' => 'Standard',
                    'loadmore' => 'Load More',
                    'infinite' => 'Infinite Scroll'
                ],
                'default'  => 'standard',
            ],
            [
                'id'       => 'blog_featured_image',
                'type'     => 'switch',
                'title'    => esc_html__('Show Featured Image', 'yomooh-core'),
                'subtitle' => esc_html__('Display featured image for each post', 'yomooh-core'),
                'default'  => true,
            ],
            [
                'id'       => 'blog_meta',
                'type'     => 'checkbox',
                'title'    => esc_html__('Post Meta', 'yomooh-core'),
                'subtitle' => esc_html__('Select which meta items to display', 'yomooh-core'),
                'options'  => [
                    'author' => 'Author',
                    'date' => 'Date',
                    'categories' => 'Categories',
                    'comments' => 'Comments',
                    'tags' => 'Tags',
					'reading_time' => 'Reading time',
                ],
                'default'  => [
                    'author' => true,
                    'date' => true,
                    'categories' => true,
                    'comments' => true,
                    'tags' => false,
                ],
            ],
            [
                'id'       => 'blog_read_more',
                'type'     => 'text',
                'title'    => esc_html__('Read More Text', 'yomooh-core'),
                'subtitle' => esc_html__('Text for "read more" link', 'yomooh-core'),
                'default'  => esc_html__('Read More', 'yomooh-core'),
            ]
        ];
    }

    protected function set_widget_option()
    {
        \Redux::setSection($this->opt_name, [
            'title'            => esc_html__('Blog General', 'yomooh-core'),
            'id'               => 'blog_general_settings',
            'icon'             => 'el el-list-alt',
            'desc'             => __('Configure general blog archive settings', 'yomooh-core'),
            'customizer_width' => '500px',
            'fields'           => $this->options,
        ]);
    }
}