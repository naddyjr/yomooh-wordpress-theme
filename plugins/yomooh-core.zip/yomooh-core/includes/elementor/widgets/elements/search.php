<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Icons_Manager;

if (!defined('ABSPATH')) exit;

class Yomooh_Search_Widget extends Widget_Base {

    public function get_name() {
        return 'yomooh_search';
    }

    public function get_title() {
        return __('Yomooh Search', 'yomooh-core');
    }

    public function get_icon() {
        return 'eicon-search';
    }

    public function get_categories() {
        return ['yomooh-elements'];
    }

    protected function register_controls() {
        // Content Tab
        $this->start_controls_section('content_section', [
            'label' => __('Search Settings', 'yomooh-core'),
            'tab' => Controls_Manager::TAB_CONTENT,
        ]);

        $this->add_control('show_label', [
            'label' => __('Show Label', 'yomooh-core'),
            'type' => Controls_Manager::SWITCHER,
            'label_on' => __('Show', 'yomooh-core'),
            'label_off' => __('Hide', 'yomooh-core'),
            'return_value' => 'yes',
            'default' => 'no',
        ]);

        $this->add_control('label_text', [
            'label' => __('Label Text', 'yomooh-core'),
            'type' => Controls_Manager::TEXT,
            'default' => __('Search', 'yomooh-core'),
            'condition' => [
                'show_label' => 'yes',
            ],
        ]);

        $this->add_control('placeholder', [
            'label' => __('Placeholder', 'yomooh-core'),
            'type' => Controls_Manager::TEXT,
            'default' => __('Search...', 'yomooh-core'),
        ]);

        $this->add_control('search_icon', [
            'label' => __('Search Icon', 'yomooh-core'),
            'type' => Controls_Manager::ICONS,
            'default' => [
                'value' => 'fas fa-search',
                'library' => 'fa-solid',
            ],
        ]);
		// New control for icon position
        $this->add_control('icon_position', [
            'label' => __('Icon Position', 'yomooh-core'),
            'type' => Controls_Manager::SELECT,
            'options' => [
                'outside' => __('Outside Input', 'yomooh-core'),
                'inside' => __('Inside Input', 'yomooh-core'),
            ],
            'default' => 'outside',
        ]);

        $this->add_control('submit_type', [
            'label' => __('Submit Type', 'yomooh-core'),
            'type' => Controls_Manager::SELECT,
            'options' => [
                'icon' => __('Icon', 'yomooh-core'),
                'button' => __('Button', 'yomooh-core'),
            ],
            'default' => 'icon',
        ]);

        $this->add_control('submit_icon', [
            'label' => __('Submit Icon', 'yomooh-core'),
            'type' => Controls_Manager::ICONS,
            'default' => [
                'value' => 'fas fa-arrow-right',
                'library' => 'fa-solid',
            ],
            'condition' => [
                'submit_type' => 'icon',
            ],
        ]);

        $this->add_control('button_text', [
            'label' => __('Button Text', 'yomooh-core'),
            'type' => Controls_Manager::TEXT,
            'default' => __('Search', 'yomooh-core'),
            'condition' => [
                'submit_type' => 'button',
            ],
        ]);

        $this->end_controls_section();

        // Style Tab - Search Container
        $this->start_controls_section('container_style_section', [
            'label' => __('Container', 'yomooh-core'),
            'tab' => Controls_Manager::TAB_STYLE,
        ]);

        $this->add_responsive_control('container_margin', [
            'label' => __('Margin', 'yomooh-core'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%', 'em'],
            'selectors' => [
                '{{WRAPPER}} .yomooh-search-containers' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->add_responsive_control('container_padding', [
            'label' => __('Padding', 'yomooh-core'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%', 'em'],
            'selectors' => [
                '{{WRAPPER}} .yomooh-search-containers' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'container_border',
                'selector' => '{{WRAPPER}} .yomooh-search-containers',
            ]
        );

        $this->add_control('container_border_radius', [
            'label' => __('Border Radius', 'yomooh-core'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%'],
            'selectors' => [
                '{{WRAPPER}} .yomooh-search-containers' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->add_control('container_bg_color', [
            'label' => __('Background Color', 'yomooh-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .yomooh-search-containers' => 'background-color: {{VALUE}};',
            ],
        ]);

        $this->end_controls_section();

        // Style Tab - Label
        $this->start_controls_section('label_style_section', [
            'label' => __('Label', 'yomooh-core'),
            'tab' => Controls_Manager::TAB_STYLE,
            'condition' => [
                'show_label' => 'yes',
            ],
        ]);

        $this->add_control('label_color', [
            'label' => __('Text Color', 'yomooh-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .yomooh-search-label' => 'color: {{VALUE}};',
            ],
        ]);

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'label_typography',
                'selector' => '{{WRAPPER}} .yomooh-search-label',
            ]
        );

        $this->add_responsive_control('label_margin', [
            'label' => __('Margin', 'yomooh-core'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%', 'em'],
            'selectors' => [
                '{{WRAPPER}} .yomooh-search-label' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->add_responsive_control('label_align', [
            'label' => __('Alignment', 'yomooh-core'),
            'type' => Controls_Manager::CHOOSE,
            'options' => [
                'left' => [
                    'title' => __('Left', 'yomooh-core'),
                    'icon' => 'eicon-text-align-left',
                ],
                'center' => [
                    'title' => __('Center', 'yomooh-core'),
                    'icon' => 'eicon-text-align-center',
                ],
                'right' => [
                    'title' => __('Right', 'yomooh-core'),
                    'icon' => 'eicon-text-align-right',
                ],
            ],
            'default' => 'left',
            'selectors' => [
                '{{WRAPPER}} .yomooh-search-label' => 'text-align: {{VALUE}};',
            ],
        ]);

        $this->end_controls_section();

        // Style Tab - Input Field
        $this->start_controls_section('input_style_section', [
            'label' => __('Input Field', 'yomooh-core'),
            'tab' => Controls_Manager::TAB_STYLE,
        ]);

        $this->add_control('input_text_color', [
            'label' => __('Text Color', 'yomooh-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .yomooh-search-inputs' => 'color: {{VALUE}};',
            ],
        ]);

        $this->add_control('input_placeholder_color', [
            'label' => __('Placeholder Color', 'yomooh-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .yomooh-search-inputs::placeholder' => 'color: {{VALUE}};',
                '{{WRAPPER}} .yomooh-search-inputs::-webkit-input-placeholder' => 'color: {{VALUE}};',
                '{{WRAPPER}} .yomooh-search-inputs::-moz-placeholder' => 'color: {{VALUE}};',
                '{{WRAPPER}} .yomooh-search-inputs:-ms-input-placeholder' => 'color: {{VALUE}};',
                '{{WRAPPER}} .yomooh-search-inputs:-moz-placeholder' => 'color: {{VALUE}};',
            ],
        ]);

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'input_typography',
                'selector' => '{{WRAPPER}} .yomooh-search-inputs',
            ]
        );

        $this->add_control('input_bg_color', [
            'label' => __('Background Color', 'yomooh-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .yomooh-search-inputs' => 'background-color: {{VALUE}};',
            ],
        ]);

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'input_border',
                'selector' => '{{WRAPPER}} .yomooh-search-inputs',
            ]
        );

        $this->add_control('input_border_radius', [
            'label' => __('Border Radius', 'yomooh-core'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%'],
            'selectors' => [
                '{{WRAPPER}} .yomooh-search-inputs' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->add_responsive_control('input_padding', [
            'label' => __('Padding', 'yomooh-core'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%', 'em'],
            'selectors' => [
                '{{WRAPPER}} .yomooh-search-inputs' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->add_responsive_control('input_margin', [
            'label' => __('Margin', 'yomooh-core'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%', 'em'],
            'selectors' => [
                '{{WRAPPER}} .yomooh-search-inputs' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'input_box_shadow',
                'selector' => '{{WRAPPER}} .yomooh-search-inputs',
            ]
        );

        $this->end_controls_section();

        // Style Tab - Search Icon
        $this->start_controls_section('search_icon_style_section', [
            'label' => __('Search Icon', 'yomooh-core'),
            'tab' => Controls_Manager::TAB_STYLE,
        ]);

        $this->add_control('search_icon_color', [
            'label' => __('Color', 'yomooh-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .yomooh-search-icons' => 'color: {{VALUE}};',
            ],
        ]);

        $this->add_control('search_icon_size', [
            'label' => __('Size', 'yomooh-core'),
            'type' => Controls_Manager::SLIDER,
            'size_units' => ['px'],
            'range' => [
                'px' => [
                    'min' => 10,
                    'max' => 50,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .yomooh-search-icons' => 'font-size: {{SIZE}}{{UNIT}};',
            ],
        ]);

        $this->add_responsive_control('search_icon_spacing', [
            'label' => __('Spacing', 'yomooh-core'),
            'type' => Controls_Manager::SLIDER,
            'size_units' => ['px'],
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 50,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .yomooh-search-icons' => 'margin-right: {{SIZE}}{{UNIT}};',
            ],
        ]);

        $this->end_controls_section();

        // Style Tab - Submit Button/Icon
        $this->start_controls_section('submit_style_section', [
            'label' => __('Submit Button', 'yomooh-core'),
            'tab' => Controls_Manager::TAB_STYLE,
        ]);

        $this->add_control('submit_icon_color', [
            'label' => __('Icon Color', 'yomooh-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .yomooh-search-submit-icons' => 'color: {{VALUE}};',
                '{{WRAPPER}} .yomooh-search-submit-buttons' => 'color: {{VALUE}};',
            ],
        ]);

        $this->add_control('submit_icon_hover_color', [
            'label' => __('Icon Hover Color', 'yomooh-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .yomooh-search-submit-icons:hover' => 'color: {{VALUE}};',
                '{{WRAPPER}} .yomooh-search-submit-buttons:hover' => 'color: {{VALUE}};',
            ],
        ]);

        $this->add_control('submit_icon_size', [
            'label' => __('Icon Size', 'yomooh-core'),
            'type' => Controls_Manager::SLIDER,
            'size_units' => ['px'],
            'range' => [
                'px' => [
                    'min' => 10,
                    'max' => 50,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .yomooh-search-submit-icons' => 'font-size: {{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .yomooh-search-submit-buttons' => 'font-size: {{SIZE}}{{UNIT}};',
            ],
            'condition' => [
                'submit_type' => 'icon',
            ],
        ]);

        $this->add_control('submit_button_bg_color', [
            'label' => __('Background Color', 'yomooh-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .yomooh-search-submit-buttons' => 'background-color: {{VALUE}};',
            ],
            'condition' => [
                'submit_type' => 'button',
            ],
        ]);

        $this->add_control('submit_button_hover_bg_color', [
            'label' => __('Hover Background Color', 'yomooh-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .yomooh-search-submit-buttons:hover' => 'background-color: {{VALUE}};',
            ],
            'condition' => [
                'submit_type' => 'button',
            ],
        ]);

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'button_typography',
                'selector' => '{{WRAPPER}} .yomooh-search-submit-buttons',
                'condition' => [
                    'submit_type' => 'button',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'button_border',
                'selector' => '{{WRAPPER}} .yomooh-search-submit-buttons',
                'condition' => [
                    'submit_type' => 'button',
                ],
            ]
        );

        $this->add_control('button_border_radius', [
            'label' => __('Border Radius', 'yomooh-core'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%'],
            'selectors' => [
                '{{WRAPPER}} .yomooh-search-submit-buttons' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
            'condition' => [
                'submit_type' => 'button',
            ],
        ]);
		$this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'bgcard_background',
                'label' => __('Background', 'yomooh-core'),
                'type' => Controls_Manager::COLOR,
				'selector' => '{{WRAPPER}} .yomooh-search-submit-icons',
				'condition' => [
                'submit_type' => 'icon',
            ],
            ]
        );
		$this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'bgcard_border',
                'selector' => '{{WRAPPER}} .yomooh-search-submit-icons',
				'condition' => [
                'submit_type' => 'icon',
            ],
            ]
        );

        $this->add_control(
            'bgcard_border_radius',
            [
                'label' => __('Border Radius', 'yomooh-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
				'condition' => [
                'submit_type' => 'icon',
            ],
                'selectors' => [
                    '{{WRAPPER}} .yomooh-search-submit-icons' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control('button_padding', [
            'label' => __('Padding', 'yomooh-core'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%', 'em'],
            'selectors' => [
                '{{WRAPPER}} .yomooh-search-submit-buttons' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
            'condition' => [
                'submit_type' => 'button',
            ],
        ]);

        $this->add_responsive_control('button_margin', [
            'label' => __('Margin', 'yomooh-core'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%', 'em'],
            'selectors' => [
                '{{WRAPPER}} .yomooh-search-submit-buttons' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
            'condition' => [
                'submit_type' => 'button',
            ],
        ]);

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_box_shadow',
                'selector' => '{{WRAPPER}} .yomooh-search-submit-buttons',
                'condition' => [
                    'submit_type' => 'button',
                ],
            ]
        );

        $this->add_responsive_control('submit_icon_spacing', [
            'label' => __('Spacing', 'yomooh-core'),
            'type' => Controls_Manager::SLIDER,
            'size_units' => ['px'],
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 50,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .yomooh-search-submit-icons' => 'margin-left: {{SIZE}}{{UNIT}};',
            ],
            'condition' => [
                'submit_type' => 'icon',
            ],
        ]);

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        
        // Fallback icon in case no icon is selected
        $fallback_icon = [
            'value' => 'fas fa-search',
            'library' => 'fa-solid',
        ];
        
        $search_icon = !empty($settings['search_icon']) ? $settings['search_icon'] : $fallback_icon;
        $submit_icon = !empty($settings['submit_icon']) ? $settings['submit_icon'] : [
            'value' => 'fas fa-arrow-right',
            'library' => 'fa-solid',
        ];
        ?>
        <div class="yomooh-search-containers">
            <?php if ($settings['show_label'] === 'yes') : ?>
                <label class="yomooh-search-label" for="yomooh-search-inputs-<?php echo esc_attr($this->get_id()); ?>">
                    <?php echo esc_html($settings['label_text']); ?>
                </label>
            <?php endif; ?>
            
            <form role="search" method="get" class="yomooh-search-forms" action="<?php echo esc_url(home_url('/')); ?>">
                <div class="yomooh-search-wrappers">
                   <?php if ($settings['icon_position'] === 'outside') : ?>
                        <?php if (!empty($search_icon['value'])) : ?>
                            <span class="yomooh-search-icons">
                                <?php 
                                Icons_Manager::render_icon($search_icon, [
                                    'aria-hidden' => 'true',
                                    'class' => 'yomooh-search-icon-i'
                                ]); 
                                ?>
                            </span>
                        <?php endif; ?>
                    <?php endif; ?>
                    
                    <input type="search" 
                           id="yomooh-search-inputs-<?php echo esc_attr($this->get_id()); ?>" 
                           class="yomooh-search-inputs" 
                           placeholder="<?php echo esc_attr($settings['placeholder']); ?>" 
                           value="<?php echo get_search_query(); ?>" 
                           name="s" 
                           aria-label="<?php echo esc_attr__('Search input', 'yomooh-core'); ?>" />
                     <?php if ($settings['icon_position'] === 'inside') : ?>
                            <?php if (!empty($search_icon['value'])) : ?>
                                <span class="yomooh-search-icons inside-icon">
                                    <?php 
                                    Icons_Manager::render_icon($search_icon, [
                                        'aria-hidden' => 'true',
                                        'class' => 'yomooh-search-icon-i'
                                    ]); 
                                    ?>
                                </span>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php if ($settings['submit_type'] === 'icon') : ?>
                        <button type="submit" class="yomooh-search-submit-icons" aria-label="<?php echo esc_attr__('Submit search', 'yomooh-core'); ?>">
                            <?php 
                            Icons_Manager::render_icon($submit_icon, [
                                'aria-hidden' => 'true',
                                'class' => 'yomooh-submit-icon-i'
                            ]); 
                            ?>
                        </button>
                    <?php else : ?>
                        <button type="submit" class="yomooh-search-submit-buttons">
                            <?php echo esc_html($settings['button_text']); ?>
                        </button>
                    <?php endif; ?>
                </div>
            </form>
        </div>
        <?php
    }

    protected function content_template() {
        ?>
        <#
        // Get icon HTML or use fallback
        var searchIconHTML = elementor.helpers.renderIcon(view, settings.search_icon || { value: 'fas fa-search', library: 'fa-solid' }, 
            { 'aria-hidden': true, 'class': 'yomooh-search-icon-i' }, 'i', 'object' );
        
        var submitIconHTML = elementor.helpers.renderIcon(view, settings.submit_icon || { value: 'fas fa-arrow-right', library: 'fa-solid' }, 
            { 'aria-hidden': true, 'class': 'yomooh-submit-icon-i' }, 'i', 'object' );
        #>
        
        <div class="yomooh-search-containers">
            <# if (settings.show_label === 'yes') { #>
                <label class="yomooh-search-label" for="yomooh-search-inputs-{{ view.getID() }}">
                    {{{ settings.label_text }}}
                </label>
            <# } #>
            
            <form role="search" method="get" class="yomooh-search-forms" action="">
                <div class="yomooh-search-wrappers">
                    <# if (settings.icon_position === 'outside') { #>
                        <# if (searchIconHTML.value) { #>
                            <span class="yomooh-search-icons">
                                {{{ searchIconHTML.value }}}
                            </span>
                        <# } #>
                    <# } #>
                    
                    <div class="yomooh-input-wrappers">
                        <input type="search" 
                               id="yomooh-search-inputs-{{ view.getID() }}" 
                               class="yomooh-search-input" 
                               placeholder="{{ settings.placeholder }}" 
                               name="s" 
                               aria-label="<?php echo esc_attr__('Search input', 'yomooh-core'); ?>" />
                        
                        <# if (settings.icon_position === 'inside') { #>
                            <# if (searchIconHTML.value) { #>
                                <span class="yomooh-search-icons inside-icon">
                                    {{{ searchIconHTML.value }}}
                                </span>
                            <# } #>
                        <# } #>
                    </div>
                    
                    <# if (settings.submit_type === 'icon') { #>
                        <button type="submit" class="yomooh-search-submit-icons" aria-label="<?php echo esc_attr__('Submit search', 'yomooh-core'); ?>">
                            {{{ submitIconHTML.value }}}
                        </button>
                    <# } else { #>
                        <button type="submit" class="yomooh-search-submit-buttons">
                            {{{ settings.button_text }}}
                        </button>
                    <# } #>
                </div>
            </form>
        </div>
        <?php
    }
}