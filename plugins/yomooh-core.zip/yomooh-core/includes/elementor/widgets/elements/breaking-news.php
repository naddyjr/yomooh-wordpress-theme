<?php

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Background;
use Elementor\Icons_Manager;
if (!defined('ABSPATH')) exit;

class Yomooh_Breaking_News extends Widget_Base {

    public function get_name() {
        return 'breaking-news';
    }

    public function get_title() {
        return __('Breaking News', 'yomooh-core');
    }

    public function get_icon() {
        return 'eicon-posts-ticker';
    }

    public function get_categories() {
        return ['yomooh-elements'];
    }

    public function get_script_depends() {
    return ['swiper'];
	}

	public function get_style_depends() {
		return ['swiper'];
	}

    protected function register_controls() {
        // Content Tab - Label Section
        $this->start_controls_section(
            'label_section',
            [
                'label' => __('Label', 'yomooh-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'label_text',
            [
                'label' => __('Label Text', 'yomooh-core'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Breaking News', 'yomooh-core'),
                'placeholder' => __('Breaking News', 'yomooh-core'),
            ]
        );

        $this->add_control(
            'label_icon',
            [
                'label' => __('Label Icon', 'yomooh-core'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-bolt',
                    'library' => 'fa-solid',
                ],
            ]
        );

        $this->add_control(
            'icon_position',
            [
                'label' => __('Icon Position', 'yomooh-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'before',
                'options' => [
                    'before' => __('Before Text', 'yomooh-core'),
                    'after' => __('After Text', 'yomooh-core'),
                ],
            ]
        );

        $this->end_controls_section();

        // Content Tab - Posts Section
        $this->start_controls_section(
            'posts_section',
            [
                'label' => __('Posts', 'yomooh-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'post_type',
            [
                'label' => __('Post Type', 'yomooh-core'),
                'type' => Controls_Manager::SELECT,
                'options' => $this->get_post_types(),
                'default' => 'post',
            ]
        );

        $this->add_control(
            'category_filter',
            [
                'label' => __('Category Filter', 'yomooh-core'),
                'type' => Controls_Manager::SELECT2,
                'options' => $this->get_post_categories(),
                'multiple' => true,
                'label_block' => true,
                'condition' => [
                    'post_type' => 'post',
                ],
            ]
        );

        $this->add_control(
            'author_filter',
            [
                'label' => __('Author Filter', 'yomooh-core'),
                'type' => Controls_Manager::SELECT2,
                'options' => $this->get_authors(),
                'multiple' => true,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'order_by',
            [
                'label' => __('Order By', 'yomooh-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'date' => __('Date', 'yomooh-core'),
                    'title' => __('Title', 'yomooh-core'),
                    'rand' => __('Random', 'yomooh-core'),
                    'comment_count' => __('Comment Count', 'yomooh-core'),
                    'modified' => __('Last Modified', 'yomooh-core'),
                ],
                'default' => 'date',
            ]
        );

        $this->add_control(
            'order',
            [
                'label' => __('Order', 'yomooh-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'ASC' => __('Ascending', 'yomooh-core'),
                    'DESC' => __('Descending', 'yomooh-core'),
                ],
                'default' => 'DESC',
            ]
        );

        $this->add_control(
            'posts_per_page',
            [
                'label' => __('Number of Posts', 'yomooh-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => 5,
                'min' => 1,
                'max' => 50,
            ]
        );

        $this->end_controls_section();

        // Content Tab - Slider Settings
        $this->start_controls_section(
            'slider_settings',
            [
                'label' => __('Slider Settings', 'yomooh-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'slides_per_view',
            [
                'label' => __('Slides Per View', 'yomooh-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => __('1', 'yomooh-core'),
                    '2' => __('2', 'yomooh-core'),
                    '3' => __('3', 'yomooh-core'),
                ],
                'default' => '1',
            ]
        );

        $this->add_control(
            'autoplay',
            [
                'label' => __('Autoplay', 'yomooh-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'yomooh-core'),
                'label_off' => __('No', 'yomooh-core'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'autoplay_speed',
            [
                'label' => __('Autoplay Speed (ms)', 'yomooh-core'),
                'type' => Controls_Manager::NUMBER,
                'min' => 100,
                'max' => 10000,
                'step' => 100,
                'default' => 3000,
                'condition' => [
                    'autoplay' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'loop',
            [
                'label' => __('Infinite Loop', 'yomooh-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'yomooh-core'),
                'label_off' => __('No', 'yomooh-core'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'show_arrows',
            [
                'label' => __('Show Navigation Arrows', 'yomooh-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'yomooh-core'),
                'label_off' => __('Hide', 'yomooh-core'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->end_controls_section();

        // Style Tab - Label Style
        $this->start_controls_section(
            'label_style_section',
            [
                'label' => __('Label', 'yomooh-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'label_background',
                'label' => __('Background', 'yomooh-core'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .breaking-news-label',
            ]
        );

        $this->add_control(
            'label_text_color',
            [
                'label' => __('Text Color', 'yomooh-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .breaking-news-label-text' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'label_typography',
                'selector' => '{{WRAPPER}} .breaking-news-label-text',
            ]
        );

        $this->add_control(
            'label_icon_color',
            [
                'label' => __('Icon Color', 'yomooh-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .breaking-news-label-icon' => 'color: {{VALUE}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'label_icon_size',
            [
                'label' => __('Icon Size', 'yomooh-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em'],
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .breaking-news-label-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'label_icon_spacing',
            [
                'label' => __('Icon Spacing', 'yomooh-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .breaking-news-label-icon.before' => 'margin-right: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .breaking-news-label-icon.after' => 'margin-left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'label_border',
                'selector' => '{{WRAPPER}} .breaking-news-label',
            ]
        );

        $this->add_control(
            'label_border_radius',
            [
                'label' => __('Border Radius', 'yomooh-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .breaking-news-label' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'label_padding',
            [
                'label' => __('Padding', 'yomooh-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .breaking-news-label' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'label_margin',
            [
                'label' => __('Margin', 'yomooh-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .breaking-news-label' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Style Tab - Post Title Style
        $this->start_controls_section(
            'title_style_section',
            [
                'label' => __('Post Title', 'yomooh-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __('Color', 'yomooh-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .breaking-news-title a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'title_hover_color',
            [
                'label' => __('Hover Color', 'yomooh-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .breaking-news-title a:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .breaking-news-title',
                'fields_options' => [
                    'font_size' => [
                        'responsive' => true, 
                    ],
                    'line_height' => [
                        'responsive' => true,
                    ]
                ]
            ]
        );

        $this->add_responsive_control(
            'title_margin',
            [
                'label' => __('Margin', 'yomooh-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .breaking-news-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'title_padding',
            [
                'label' => __('Padding', 'yomooh-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .breaking-news-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Style Tab - Background Style
        $this->start_controls_section(
            'background_style_section',
            [
                'label' => __('Background', 'yomooh-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'background',
                'label' => __('Background', 'yomooh-core'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .breaking-news-container',
            ]
        );

        $this->add_control(
            'background_hover_color',
            [
                'label' => __('Hover Color', 'yomooh-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .breaking-news-container:hover' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'background_background' => 'classic',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'border',
                'selector' => '{{WRAPPER}} .breaking-news-container',
            ]
        );

        $this->add_control(
            'border_radius',
            [
                'label' => __('Border Radius', 'yomooh-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .breaking-news-container' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'padding',
            [
                'label' => __('Padding', 'yomooh-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .breaking-news-container' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'margin',
            [
                'label' => __('Margin', 'yomooh-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .breaking-news-container' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Style Tab - Navigation Arrows
        $this->start_controls_section(
            'arrow_style_section',
            [
                'label' => __('Navigation Arrows', 'yomooh-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'arrow_size',
            [
                'label' => __('Size', 'yomooh-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 60,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 20,
                ],
                'selectors' => [
                    '{{WRAPPER}} .breaking-news-arrow' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'arrow_color',
            [
                'label' => __('Color', 'yomooh-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .breaking-news-arrow' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'arrow_hover_color',
            [
                'label' => __('Hover Color', 'yomooh-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .breaking-news-arrow:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'arrow_background',
            [
                'label' => __('Background Color', 'yomooh-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .breaking-news-arrow' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'arrow_background_hover',
            [
                'label' => __('Background Hover Color', 'yomooh-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .breaking-news-arrow:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'arrow_border',
                'selector' => '{{WRAPPER}} .breaking-news-arrow',
            ]
        );

        $this->add_control(
            'arrow_border_radius',
            [
                'label' => __('Border Radius', 'yomooh-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .breaking-news-arrow' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'arrow_padding',
            [
                'label' => __('Padding', 'yomooh-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .breaking-news-arrow' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        // Query args
        $args = [
            'post_type' => $settings['post_type'],
            'posts_per_page' => $settings['posts_per_page'],
            'orderby' => $settings['order_by'],
            'order' => $settings['order'],
        ];

        // Category filter
        if ($settings['post_type'] === 'post' && !empty($settings['category_filter'])) {
            $args['category__in'] = $settings['category_filter'];
        }

        // Author filter
        if (!empty($settings['author_filter'])) {
            $args['author__in'] = $settings['author_filter'];
        }
        $query = new \WP_Query($args);

        if ($query->have_posts()) :
            $this->add_render_attribute('breaking-news', 'class', 'breaking-news-container');
            $this->add_render_attribute('slider', 'class', 'breaking-news-slider');
            $this->add_render_attribute('slider', 'data-settings', wp_json_encode([
                'slidesPerView' => $settings['slides_per_view'],
                'autoplay' => $settings['autoplay'] === 'yes' ? [
                    'delay' => $settings['autoplay_speed'],
                    'disableOnInteraction' => false,
                ] : false,
                'loop' => $settings['loop'] === 'yes',
                'navigation' => [
                    'nextEl' => '.breaking-news-next-' . $this->get_id(),
                    'prevEl' => '.breaking-news-prev-' . $this->get_id(),
                ],
            ]));
		$icon = $settings['label_icon'];
        if (empty($icon['value'])) {
            $icon = [
                'value' => 'fas fa-bolt',
                'library' => 'fa-solid',
            ];
        }
            ?>
            <div <?php echo $this->get_render_attribute_string('breaking-news'); ?>>
                <div class="breaking-news-label">
                     <?php if ($settings['icon_position'] === 'before') : ?>
                    <span class="breaking-news-label-icon before">
                        <?php Icons_Manager::render_icon($icon, [
                            'aria-hidden' => 'true',
                            'class' => 'breaking-news-icon'
                        ]); ?>
                    </span>
                <?php endif; ?>
                    
                    <span class="breaking-news-label-text"><?php echo esc_html($settings['label_text']); ?></span>
                    
                    <?php if ($settings['icon_position'] === 'after') : ?>
                    <span class="breaking-news-label-icon after">
                        <?php Icons_Manager::render_icon($icon, [
                            'aria-hidden' => 'true',
                            'class' => 'breaking-news-icon'
                        ]); ?>
                    </span>
                <?php endif; ?>
                </div>
                
                <div <?php echo $this->get_render_attribute_string('slider'); ?>>
                    <div class="swiper-container">
                        <div class="swiper-wrapper">
                            <?php while ($query->have_posts()) : $query->the_post(); ?>
                                <div class="swiper-slide">
                                    <h3 class="breaking-news-title">
                                        <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                    </h3>
                                </div>
                            <?php endwhile; ?>
                        </div>
                    </div>
                    
                    <?php if ($settings['show_arrows'] === 'yes') : ?>
                        <div class="breaking-news-arrow breaking-news-next breaking-news-next-<?php echo $this->get_id(); ?>">
                            <i class="fas fa-chevron-right"></i>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php
            wp_reset_postdata();
        else :
            echo '<p>' . __('No posts found', 'yomooh-core') . '</p>';
        endif;
    }

    protected function get_post_types() {
        $post_types = get_post_types(['public' => true], 'objects');
        $options = [];

        foreach ($post_types as $post_type) {
            if ($post_type->name !== 'elementor_library') {
                $options[$post_type->name] = $post_type->label;
            }
        }

        return $options;
    }

    protected function get_post_categories() {
        $categories = get_categories(['hide_empty' => false]);
        $options = [];

        foreach ($categories as $category) {
            $options[$category->term_id] = $category->name;
        }

        return $options;
    }

    protected function get_authors() {
    $users = get_users([
        'capability' => 'edit_posts',
        'has_published_posts' => true,
        'fields' => ['ID', 'display_name']
    ]);

    $options = [];

    foreach ($users as $user) {
        $options[$user->ID] = $user->display_name;
    }

    return $options;
}
}