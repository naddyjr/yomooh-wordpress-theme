<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class Yomooh_Template_System {

    public function __construct() {
        add_action('init', [$this, 'register_post_type']);
        add_action('add_meta_boxes', [$this, 'add_meta_boxes']);
        add_action('save_post', [$this, 'save_template_shortcode'], 10, 2);
        add_filter('manage_yomooh_template_posts_columns', [$this, 'add_template_columns']);
        add_action('manage_yomooh_template_posts_custom_column', [$this, 'template_column_content'], 10, 2);
        add_filter('template_include', [$this, 'load_yomooh_template']); 
        add_filter('query_vars', [$this, 'add_query_vars']);
        
        // Disable canonical redirect for our custom URL pattern
        add_filter('redirect_canonical', [$this, 'disable_canonical_redirect'], 10, 2);

        // Register Elementor support
        add_action('elementor/init', [$this, 'register_elementor_support']);
    }

    // Disable canonical redirect for our custom URL pattern
    public function disable_canonical_redirect($redirect_url, $requested_url) {
        if (strpos($requested_url, 'yomooh-template?page-title=') !== false) {
            return false;
        }
        return $redirect_url;
    }

    public function add_query_vars($vars) {
        $vars[] = 'page-title';
        return $vars;
    }
    // Register custom post type for templates
    public function register_post_type() {
        $labels = array(
            'name' => __('Yomooh Templates', 'yomooh-core'),
            'singular_name' => __('Yomooh Template', 'yomooh-core'),
            'menu_name' => __('Yomooh Templates', 'yomooh-core'),
            'name_admin_bar' => __('Yomooh Template', 'yomooh-core'),
            'add_new' => __('Add New', 'yomooh-core'),
            'add_new_item' => __('Add New Template', 'yomooh-core'),
            'new_item' => __('New Template', 'yomooh-core'),
            'edit_item' => __('Edit Template', 'yomooh-core'),
            'view_item' => __('View Template', 'yomooh-core'),
            'all_items' => __('All Templates', 'yomooh-core'),
            'search_items' => __('Search Templates', 'yomooh-core'),
            'not_found' => __('No templates found.', 'yomooh-core'),
            'not_found_in_trash' => __('No templates found in Trash.', 'yomooh-core')
        );

        $args = array(
            'labels' => $labels,
            'public' => true,
            'publicly_queryable' => true,
            'show_ui' => true,
            'show_in_menu' => true,
            'query_var' => true,
            'rewrite' => false,
            'capability_type' => 'post',
            'has_archive' => true,
            'hierarchical' => false,
            'menu_position' => null,
			'menu_icon'      => 'dashicons-art',
            'supports' => array('title', 'editor', 'elementor'),
            'show_in_rest' => true,
        );

        register_post_type('yomooh_template', $args);
    }

    // Add meta boxes
    public function add_meta_boxes() {
        add_meta_box(
            'yomooh_template_shortcode',
            __('Template Shortcode', 'yomooh-core'),
            [$this, 'render_shortcode_meta_box'],
            'yomooh_template',
            'side',
            'high'
        );
    }

    // Render shortcode meta box
    public function render_shortcode_meta_box($post) {
        $shortcode = '[yomooh-template id="' . $post->ID . '"]';
        echo '<input type="text" class="widefat" value=\'' . esc_attr($shortcode) . '\' readonly onclick="this.select()">';
        echo '<p class="description">' . __('Copy this shortcode to display this template anywhere on your site.', 'yomooh-core') . '</p>';
    }

    // Save template shortcode (though it's auto-generated)
    public function save_template_shortcode($post_id, $post) {
        if ($post->post_type != 'yomooh_template') {
            return;
        }
        
        // Ensure the shortcode meta exists
        $shortcode = '[yomooh-template id="' . $post_id . '"]';
        update_post_meta($post_id, '_yomooh_template_shortcode', $shortcode);
    }

    // Add template shortcode column to admin list
    public function add_template_columns($columns) {
        $new_columns = array();
        
        foreach ($columns as $key => $value) {
            $new_columns[$key] = $value;
            if ($key === 'date') {
                $new_columns['template_shortcode'] = __('Template Shortcode', 'yomooh-core');
            }
        }
        
        return $new_columns;
    }

    // Content for template shortcode column
    public function template_column_content($column, $post_id) {
        if ($column == 'template_shortcode') {
            $shortcode = '[yomooh-template id="' . $post_id . '"]';
            echo '<input type="text" class="widefat" value=\'' . esc_attr($shortcode) . '\' readonly onclick="this.select()" style="width:100%; max-width:300px;">';
        }
    }

    // Load custom template for single view
      public function load_yomooh_template($template) {
        global $wp_query;
        
        // Check for our query parameter
        $page_title = get_query_var('page-title');
        
        if (is_singular('yomooh_template') || !empty($page_title)) {
            // If we have a page-title parameter, find the template
            if (!empty($page_title)) {
                $template_post = get_page_by_title($page_title, OBJECT, 'yomooh_template');
                if ($template_post) {
                    $wp_query->is_singular = true;
                    $wp_query->is_single = true;
                    $wp_query->queried_object = $template_post;
                    $wp_query->queried_object_id = $template_post->ID;
                    $wp_query->post = $template_post;
                    $wp_query->posts = array($template_post);
                    $wp_query->post_count = 1;
                }
            }
            
            // Load our custom template
            $custom_template = YOMOOH_PLUGIN_DIR . 'includes/elementor/template/yomooh-template.php';
            if (file_exists($custom_template)) {
                return $custom_template;
            }
        }
        
        return $template;
    }

    // Register Elementor support
    public function register_elementor_support() {
        add_post_type_support('yomooh_template', 'elementor');
    }

    // Shortcode handler
    public static function template_shortcode($atts) {
        $atts = shortcode_atts(array(
            'id' => 0,
        ), $atts, 'yomooh-template');

        if (!$atts['id']) {
            return '';
        }

        $template_post = get_post($atts['id']);
        
        if (!$template_post || $template_post->post_type != 'yomooh_template') {
            return '';
        }

        // Check if Elementor is active and the template is built with Elementor
        if (defined('ELEMENTOR_PATH') && class_exists('Elementor\Plugin')) {
            $elementor_instance = Elementor\Plugin::instance();
            return $elementor_instance->frontend->get_builder_content_for_display($atts['id']);
        }

        // Fallback to regular content
        return apply_filters('the_content', $template_post->post_content);
    }
}

// Initialize the template system
new Yomooh_Template_System();

// Register the shortcode
add_shortcode('yomooh-template', ['Yomooh_Template_System', 'template_shortcode']);