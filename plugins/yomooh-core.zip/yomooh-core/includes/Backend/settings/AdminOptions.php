<?php
namespace Yomooh\Backend\settings;

use Redux;
use Yomooh\Backend\settings\Options\Header;
use Yomooh\Backend\settings\Options\MobileHeader;
use Yomooh\Backend\settings\Options\Footer;
use Yomooh\Backend\settings\Options\BodyLayout;
use Yomooh\Backend\settings\Options\Typography;
use Yomooh\Backend\settings\Options\Category;
use Yomooh\Backend\settings\Options\BlogGeneral;
use Yomooh\Backend\settings\Options\BlogSingle;
use Yomooh\Backend\settings\Options\Breadcrumbs;
use Yomooh\Backend\settings\Options\Newsletter;
use Yomooh\Backend\settings\Options\SocialLinks;
use Yomooh\Backend\settings\Options\CustomCode;
use Yomooh\Backend\settings\Options\F404;
use Yomooh\Backend\settings\Options\Search;
use Yomooh\Backend\settings\Options\SinglePage;
use Yomooh\Backend\settings\Options\WooCommerceSettings;

class AdminOptions 
{
    protected $page_slug = 'yomooh_options';
    protected $opt_name = 'yomooh_options';
    private $is_customizer;
  	private $plugin_url;

    public function get_opt_name()
    {
        return $this->opt_name;
    }

    public function init()
    {
        $this->is_customizer = is_customize_preview();
        $redux_opt_name = $this->opt_name;
		$this->plugin_url = YOMOOH_PLUGIN_URL;
        // Initialize Redux
		add_action('after_setup_theme', array($this, 'init_redux_options'));
       add_action('redux/page/' . $this->opt_name . '/form/before', [$this, 'render_dashboard_content']);
        add_action('redux/page/' . $this->opt_name . '/enqueue', array($this, 'som_redux_admin_styles'));
        add_action('wp_ajax_som_save_redux_style_action', [$this, 'som_save_redux_style']);
        add_action('wp_ajax_nopriv_som_save_redux_style_action', [$this, 'som_save_redux_style']);
       add_action("redux/options/{$this->opt_name}/saved", [$this, 'refresh_redux_styles_on_save']);
        add_action("admin_enqueue_scripts", [$this, "som_dequeue_unnecessary_scripts"], 11);
		add_action('admin_menu', [$this, 'add_ym_admin_menus']);
        /* redux fields overload */
        if (!$this->is_customizer) {
            add_filter("redux/$redux_opt_name/field/class/dimensions", function () {
                return dirname(__FILE__) . "/fields/dimensions/class-redux-dimensions.php";
            });
            add_filter("redux/$redux_opt_name/field/class/spacing", function () {
                return dirname(__FILE__) . "/fields/spacing/class-redux-spacing.php";
            });
            add_filter("redux/$redux_opt_name/field/class/media", function () {
                return dirname(__FILE__) . "/fields/media/class-redux-media.php";
            });
            add_filter("redux/$redux_opt_name/field/class/raw", function () {
                return dirname(__FILE__) . "/fields/raw/class-redux-raw.php";
            });
        }
    }

	public function add_ym_admin_menus() {
	 add_menu_page(
        'Yomooh Dashboard', // Page title
        'Yomooh theme',     // Menu title
        'manage_options',
        'yomooh-admin',
        '', 
		 'data:image/svg+xml;base64,' . base64_encode('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"><path d="M16 19.25a3.25 3.25 0 1 1 6.5 0 3.25 3.25 0 0 1-6.5 0Zm-14.5 0a3.25 3.25 0 1 1 6.5 0 3.25 3.25 0 0 1-6.5 0Zm0-14.5a3.25 3.25 0 1 1 6.5 0 3.25 3.25 0 0 1-6.5 0ZM4.75 3a1.75 1.75 0 1 0 .001 3.501A1.75 1.75 0 0 0 4.75 3Zm0 14.5a1.75 1.75 0 1 0 .001 3.501A1.75 1.75 0 0 0 4.75 17.5Zm14.5 0a1.75 1.75 0 1 0 .001 3.501 1.75 1.75 0 0 0-.001-3.501Z"></path><path d="M13.405 1.72a.75.75 0 0 1 0 1.06L12.185 4h4.065A3.75 3.75 0 0 1 20 7.75v8.75a.75.75 0 0 1-1.5 0V7.75a2.25 2.25 0 0 0-2.25-2.25h-4.064l1.22 1.22a.75.75 0 0 1-1.061 1.06l-2.5-2.5a.75.75 0 0 1 0-1.06l2.5-2.5a.75.75 0 0 1 1.06 0ZM4.75 7.25A.75.75 0 0 1 5.5 8v8A.75.75 0 0 1 4 16V8a.75.75 0 0 1 .75-.75Z"></path></svg>'),
        2
    );
	// First submenu: Dashboard (matches top-level menu page)
    add_submenu_page(
        'yomooh-admin',
        'Dashboard',
        'Dashboard',
        'manage_options',
        'yomooh-admin',
        '',
        1
    );
    remove_submenu_page('yomooh-admin', 'yomooh-admin');
}
	public function refresh_redux_styles_on_save()
{
    // Force inline CSS refresh by removing and re-adding the inline style
    add_action('admin_enqueue_scripts', [$this, 'som_redux_admin_styles'], 999);
}
    public function som_dequeue_unnecessary_scripts($screen) {
        if ($screen !== "toplevel_page_" . $this->page_slug) return;

        wp_deregister_style("select2");
        wp_deregister_script("select2");
        wp_deregister_script("gamipress-select2-js");
    }

    function som_redux_admin_styles()
    {
        global $is_dark_mode;
        $root = '';

        // remove admin notice for theme redux option page;
        remove_all_actions("admin_notices");
        wp_enqueue_script('underscore');
        $js_url     = YOMOOH_PLUGIN_URL . 'includes/Backend/settings/assets/js/redux-template.min.js';
        $version    = YOMOOH_VERSION;
        $root_vars  = [
            "--redux-sidebar-color:#121623",
            "--redux-top-header:#f5f7ff",
            "--submenu-border-color:#262b3b",
            "--border-color-light:#ededed",
            "--content-backgrand-color:#fff",
            "--sub-fields-back:#fff;",
            "--input-border-color:#d8e1f5",
            "--input-btn-back:#edeffc",
            "--input-back-color:#f5f7ff",
            "--white-color-nochage:#fff",
            "--redux-text-color:#69748c",/* font color */
            "--text-heading-color:#121623",
            "--submenu-hover-color:#fff",
            "--redux-primary-color:#de3a53",
            "--font-weight-medium:500", /* font weight */
            "--notice-yellow-back:#fbf5e2",
            "--notice-yellow-color:#f7a210",
            "--code-editor-active:#e6edff",
            "--notice-green-back:#d1f1be",
            "--redux-sidebar-color:#f5f7ff",
            "--active-tab-color:#f5f0f0",
            "--no-changeborder-color-light:#ededed",
            "--submenu-hover-color:#de3a53",
            "--submenu-active-color:#de3a53",
            "--submenu-border-color:#e5e9e7",
            "--redux-menu-lable:#aeb1b9",
            "--redux-menu-color:#353840",
            "--wp-content-back:#f0f0f1",
        ];
        $version = time(); // Use a timestamp to avoid caching during dev
        wp_enqueue_style('redux-template', YOMOOH_PLUGIN_URL . '/includes/Backend/settings/assets/css/redux-template.min.css', [], $version);
        wp_enqueue_style('redux-custom-font', YOMOOH_PLUGIN_URL . '/includes/Backend/settings/assets/css/redux-font/redux-custom-font.css', true);
        $root .= ':root{' . implode(";", $root_vars) . '}';
        $is_dark_mode = get_option($this->page_slug . "_is_redux_dark_mode", true);

        if (!$is_dark_mode) {
            wp_add_inline_style("redux-template", $root);
        }

        wp_register_script('custom_redux_options', false);
        wp_localize_script('custom_redux_options', 'custom_redux_options_params', array(
            'ajaxUrl'       => admin_url() . 'admin-ajax.php',
            'root'          => $root,
            'action'        => "som_save_redux_style_action",
            'is_dark_mode'  => $is_dark_mode ? true : false
        ));
        wp_enqueue_script('custom_redux_options');

        wp_enqueue_script('redux-template', $js_url, ['jquery'], $version, true);
    }

    public function som_save_redux_style()
    {
        $is_dark_mode = isset($_GET['is_dark_mode']) && $_GET['is_dark_mode'] == 1 ? 1 : 0;
        update_option($this->page_slug . "_is_redux_dark_mode", $is_dark_mode);
    }
public function render_dashboard_content()
{
    global $pagenow;
        if (isset($_GET['page']) && $_GET['page'] === $this->page_slug && !isset($_GET['tab'])) {
            yomooh_dashboard('options');
        }
    }

    public function init_redux_options()
    {
        if (!class_exists('Redux')) {
            return;
        }
    $name = "Yomooh Options";
    $version = YOMOOH_VERSION;

    $args = array(
        'opt_name'             => $this->opt_name,
        'display_name'         => $name,
        'display_version'      => $version,
        'menu_type'  => 'submenu',
		'page_parent' => 'yomooh-admin',
		'allow_sub_menu' => false,
		'page_priority'        => 10,
        'menu_title'           => esc_html__('Yomooh Settings', 'yomooh-core'),
        'page_title'           => esc_html__('Yomooh Settings', 'yomooh-core'),
        'google_api_key'       => '',
        'google_update_weekly' => false,
        'async_typography'     => true,
        'admin_bar'            => false,
        'admin_bar_icon'       => 'dashicons-admin-settings',
        'admin_bar_priority'   => '',
        'global_variable'      => $this->opt_name,
        'dev_mode'             => false,
        'update_notice'        => false,
        'customizer'           => false,
        'class'                => 'redux-content',
        'page_permissions'     => 'manage_options',
        'menu_icon'            => $this->plugin_url . 'assets/images/icon.png',
        'page_icon'            => 'icon-themes',
        'page_slug'            => $this->page_slug,
        'save_defaults'        => true,
        'default_show'         => false,
        'default_mark'         => '',
        'show_import_export'   => true,
        'show_options_object'  => true,
        'templates_path'       => !$this->is_customizer ? YOMOOH_PLUGIN_DIR . 											'includes/Backend/settings/templates/panel/' : '',
        'use_cdn'              => true,
        'transient_time'       => 60 * MINUTE_IN_SECONDS,
        'output'              => true,
        'output_tag'          => true,
        'database'            => '',
        'system_info'         => false,
        'footer_credit'       => '',
        'hide_expand'         => true,
        'hints'              => array(
            'icon'          => 'el el-question-sign',
            'icon_position' => 'right',
            'icon_color'    => 'lightgray',
            'icon_size'     => 'normal',
            'tip_style'     => array(
                'color'   => 'light',
                'shadow'  => true,
                'rounded' => false,
                'style'   => '',
            ),
            'tip_position'  => array(
                'my' => 'top left',
                'at' => 'bottom right',
            ),
            'tip_effect'    => array(
                'show' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'mouseover',
                ),
                'hide' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'click mouseleave',
                ),
            ),
        )
    );

    \Redux::setArgs($this->opt_name, $args);
        $this->add_redux_sections();
    }

protected function add_redux_sections()
    {
	 new Header($this->opt_name);
     new MobileHeader($this->opt_name);
     new Footer($this->opt_name);
     new BodyLayout($this->opt_name);
     new BlogGeneral($this->opt_name);
     new BlogSingle($this->opt_name);
     new SinglePage($this->opt_name);
     new Category($this->opt_name);
     new Search($this->opt_name);
     new Typography($this->opt_name);
     new Breadcrumbs($this->opt_name);
	 new F404($this->opt_name);
     if (class_exists('WooCommerce')) {
       new WooCommerceSettings($this->opt_name);
     }
     new Newsletter($this->opt_name);
     new SocialLinks($this->opt_name);
     new CustomCode($this->opt_name);
    }
}