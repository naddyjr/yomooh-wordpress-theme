<?php
namespace Yomooh\Backend\settings\Options;
use Redux;
use Yomooh\Backend\settings\AdminOptions;

class SinglePage extends AdminOptions
{
    protected $options;

    public function __construct($opt_name)
    {
        $this->opt_name = $opt_name;
        $this->options = $this->dependent_options();
        $this->set_widget_option();
    }

    protected function get_registered_sidebars()
    {
        return [
            'sidebar-1'    => __('Sidebar (Default)', 'yomooh-core'),
            'sidebar-blog' => __('Blog Sidebar', 'yomooh-core'),
            'sidebar-spage' => __('Single Page Sidebar', 'yomooh-core'),
            'sidebar-sblog' => __('Single Blog Sidebar', 'yomooh-core')
        ];
    }

    protected function dependent_options()
    {
        return [
            [
                'id'       => 'page_header_style',
                'type'     => 'select',
                'title'    => esc_html__('Page Header Layout', 'yomooh-core'),
                'subtitle' => esc_html__('Select a header layout for the single page.', 'yomooh-core'),
                'options'  => [
                    'left-heading' => 'Left Heading',
                    'no-heading'  => 'No heading',
                ],
                'default'  => 'left-heading',
            ],
            [
                'id'       => 'pagelayout',
                'type'     => 'image_select',
                'title'    => esc_html__('Single Page Layout', 'yomooh-core'),
                'subtitle' => esc_html__('Choose layout for Single Page', 'yomooh-core'),
                'options'  => [
                    'left-sidebar' => [
                        'alt' => 'Left Sidebar',
                        'img' => YOMOOH_PLUGIN_URL . 'includes/Backend/settings/assets/images/left-sidebar.png'
                    ],
                    'right-sidebar' => [
                        'alt' => 'Right Sidebar',
                        'img' => YOMOOH_PLUGIN_URL . 'includes/Backend/settings/assets/images/sidebar-right.png'
                    ],
                    'no-sidebar' => [
                        'alt' => 'No Sidebar',
                        'img' => YOMOOH_PLUGIN_URL . 'includes/Backend/settings/assets/images/column-one.png'
                    ],
                ],
                'default'  => 'right-sidebar',
            ],
            [
                'id'       => 'page_sidebar',
                'type'     => 'select',
                'title'    => esc_html__('Assign a Sidebar', 'yomooh-core'),
                'subtitle' => esc_html__('Select which sidebar to display on single page', 'yomooh-core'),
                'options'  => $this->get_registered_sidebars(),
                'default'  => 'sidebar-1',
                'required' => ['pagelayout', '!=', 'no-sidebar'],
            ]
        ];
    }

    protected function set_widget_option()
    {
        \Redux::setSection($this->opt_name, [
            'title'            => esc_html__('Single Page', 'yomooh-core'),
            'id'               => 'single_page',
            'icon'             => 'el el-list-alt',
            'desc'             => __('Customize the layout and style of the single page.', 'yomooh-core'),
            'customizer_width' => '500px',
            'fields'           => $this->options,
        ]);
    }
}