<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Control_Media; 
if (!defined('ABSPATH')) exit;

class Yomooh_Widget_Image extends Widget_Base {

    public function get_name() {
        return 'yomooh_image';
    }

    public function get_title() {
        return __('Yomooh Image', 'yomooh-core');
    }

    public function get_icon() {
        return 'eicon-image';
    }

    public function get_categories() {
        return ['yomooh-elements'];
    }

    protected function register_controls() {
        // Content Tab
        $this->start_controls_section('content_section', [
            'label' => __('Image Settings', 'yomooh-core'),
            'tab' => Controls_Manager::TAB_CONTENT,
        ]);

        $this->add_control('image', [
            'label' => __('Choose Image', 'yomooh-core'),
            'type' => Controls_Manager::MEDIA,
            'default' => [
                'url' => \Elementor\Utils::get_placeholder_image_src(),
            ],
        ]);

        $this->add_control('lazy_load', [
            'label' => __('Lazy Load', 'yomooh-core'),
            'type' => Controls_Manager::SWITCHER,
            'default' => 'yes',
            'label_on' => __('Enable', 'yomooh-core'),
            'label_off' => __('Disable', 'yomooh-core'),
        ]);

        $this->add_control('image_resolution', [
            'label' => __('Image Resolution', 'yomooh-core'),
            'type' => Controls_Manager::SELECT,
            'default' => 'full',
            'options' => [
                'thumbnail' => __('Thumbnail', 'yomooh-core'),
                'medium' => __('Medium', 'yomooh-core'),
                'large' => __('Large', 'yomooh-core'),
                'full' => __('Full', 'yomooh-core'),
            ],
        ]);

        $this->add_control('image_align', [
            'label' => __('Alignment', 'yomooh-core'),
            'type' => Controls_Manager::CHOOSE,
            'options' => [
                'left' => [
                    'title' => __('Left', 'yomooh-core'),
                    'icon' => 'eicon-text-align-left',
                ],
                'center' => [
                    'title' => __('Center', 'yomooh-core'),
                    'icon' => 'eicon-text-align-center',
                ],
                'right' => [
                    'title' => __('Right', 'yomooh-core'),
                    'icon' => 'eicon-text-align-right',
                ],
            ],
            'default' => 'center',
            'toggle' => true,
            'selectors' => [
                '{{WRAPPER}} .yomooh-image-wrapper' => 'text-align: {{VALUE}};',
            ],
        ]);

        $this->add_control('caption_source', [
            'label' => __('Caption', 'yomooh-core'),
            'type' => Controls_Manager::SELECT,
            'default' => 'none',
            'options' => [
                'none' => __('None', 'yomooh-core'),
                'attachment' => __('Attachment Caption', 'yomooh-core'),
                'custom' => __('Custom Caption', 'yomooh-core'),
            ],
        ]);

        $this->add_control('caption', [
            'label' => __('Custom Caption', 'yomooh-core'),
            'type' => Controls_Manager::TEXT,
            'default' => __('Enter your image caption', 'yomooh-core'),
            'placeholder' => __('Enter your image caption', 'yomooh-core'),
            'condition' => [
                'caption_source' => 'custom',
            ],
            'dynamic' => [
                'active' => true,
            ],
        ]);

        $this->add_control('link_to', [
            'label' => __('Link', 'yomooh-core'),
            'type' => Controls_Manager::SELECT,
            'default' => 'none',
            'options' => [
                'none' => __('None', 'yomooh-core'),
                'file' => __('Media File', 'yomooh-core'),
                'custom' => __('Custom URL', 'yomooh-core'),
            ],
        ]);

        $this->add_control('link', [
            'label' => __('Link', 'yomooh-core'),
            'type' => Controls_Manager::URL,
            'dynamic' => [
                'active' => true,
            ],
            'placeholder' => __('https://your-link.com', 'yomooh-core'),
            'condition' => [
                'link_to' => 'custom',
            ],
            'show_label' => false,
        ]);

        $this->end_controls_section();

        // Style Tab - Image
        $this->start_controls_section('style_image_section', [
            'label' => __('Image', 'yomooh-core'),
            'tab' => Controls_Manager::TAB_STYLE,
        ]);

        $this->add_responsive_control('image_width', [
            'label' => __('Width', 'yomooh-core'),
            'type' => Controls_Manager::SLIDER,
            'size_units' => ['px', '%'],
            'range' => [
                'px' => ['min' => 10, 'max' => 2000],
                '%' => ['min' => 1, 'max' => 100],
            ],
            'selectors' => [
                '{{WRAPPER}} .yomooh-image img' => 'width: {{SIZE}}{{UNIT}};',
            ],
        ]);

        $this->add_responsive_control('image_max_width', [
            'label' => __('Max Width', 'yomooh-core'),
            'type' => Controls_Manager::SLIDER,
            'size_units' => ['px', '%'],
            'range' => [
                'px' => ['min' => 10, 'max' => 2000],
                '%' => ['min' => 1, 'max' => 100],
            ],
            'selectors' => [
                '{{WRAPPER}} .yomooh-image img' => 'max-width: {{SIZE}}{{UNIT}};',
            ],
        ]);

        $this->add_responsive_control('image_height', [
            'label' => __('Height', 'yomooh-core'),
            'type' => Controls_Manager::SLIDER,
            'size_units' => ['px', 'vh'],
            'range' => [
                'px' => ['min' => 10, 'max' => 1200],
                'vh' => ['min' => 1, 'max' => 100],
            ],
            'selectors' => [
                '{{WRAPPER}} .yomooh-image img' => 'height: {{SIZE}}{{UNIT}};',
            ],
        ]);

        $this->add_control('image_opacity', [
            'label' => __('Opacity', 'yomooh-core'),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => ['max' => 1, 'min' => 0, 'step' => 0.01],
            ],
            'selectors' => [
                '{{WRAPPER}} .yomooh-image img' => 'opacity: {{SIZE}};',
            ],
        ]);

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'image_border',
                'selector' => '{{WRAPPER}} .yomooh-image img',
            ]
        );

        $this->add_responsive_control('image_border_radius', [
            'label' => __('Border Radius', 'yomooh-core'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%'],
            'selectors' => [
                '{{WRAPPER}} .yomooh-image img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'image_box_shadow',
                'selector' => '{{WRAPPER}} .yomooh-image img',
            ]
        );

        $this->add_control('hover_animation', [
            'label' => __('Hover Animation', 'yomooh-core'),
            'type' => Controls_Manager::HOVER_ANIMATION,
        ]);

        $this->end_controls_section();

        // Style Tab - Caption
        $this->start_controls_section('style_caption_section', [
            'label' => __('Caption', 'yomooh-core'),
            'tab' => Controls_Manager::TAB_STYLE,
            'condition' => [
                'caption_source!' => 'none',
            ],
        ]);

        $this->add_control('caption_color', [
            'label' => __('Text Color', 'yomooh-core'),
            'type' => Controls_Manager::COLOR,
            'global' => [
                'default' => Global_Colors::COLOR_TEXT,
            ],
            'selectors' => [
                '{{WRAPPER}} .yomooh-image-caption' => 'color: {{VALUE}};',
            ],
        ]);

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'caption_typography',
                'global' => [
                    'default' => Global_Typography::TYPOGRAPHY_TEXT,
                ],
                'selector' => '{{WRAPPER}} .yomooh-image-caption',
            ]
        );

        $this->add_responsive_control('caption_align', [
            'label' => __('Alignment', 'yomooh-core'),
            'type' => Controls_Manager::CHOOSE,
            'options' => [
                'left' => [
                    'title' => __('Left', 'yomooh-core'),
                    'icon' => 'eicon-text-align-left',
                ],
                'center' => [
                    'title' => __('Center', 'yomooh-core'),
                    'icon' => 'eicon-text-align-center',
                ],
                'right' => [
                    'title' => __('Right', 'yomooh-core'),
                    'icon' => 'eicon-text-align-right',
                ],
            ],
            'default' => 'center',
            'selectors' => [
                '{{WRAPPER}} .yomooh-image-caption' => 'text-align: {{VALUE}};',
            ],
        ]);

        $this->add_responsive_control('caption_padding', [
            'label' => __('Padding', 'yomooh-core'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%', 'em'],
            'selectors' => [
                '{{WRAPPER}} .yomooh-image-caption' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->add_responsive_control('caption_margin', [
            'label' => __('Margin', 'yomooh-core'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%', 'em'],
            'selectors' => [
                '{{WRAPPER}} .yomooh-image-caption' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        if (empty($settings['image']['url'])) {
            return;
        }

        $has_caption = $settings['caption_source'] !== 'none';
        $image_url = $settings['image']['url'];
        $image_html = '';

        // Get image by resolution
        if ($settings['image_resolution'] !== 'full') {
            $image_id = attachment_url_to_postid($image_url);
            if ($image_id) {
                $image_src = wp_get_attachment_image_src($image_id, $settings['image_resolution']);
                if ($image_src) {
                    $image_url = $image_src[0];
                }
            }
        }

        // Lazy load attribute
        $loading_attr = $settings['lazy_load'] === 'yes' ? 'loading="lazy"' : '';

        // Image HTML
        $this->add_render_attribute('image', [
            'src' => esc_url($image_url),
            'alt' => Control_Media::get_image_alt($settings['image']),
            'title' => Control_Media::get_image_title($settings['image']),
            $loading_attr,
        ]);

        $image_html = '<img ' . $this->get_render_attribute_string('image') . '>';

        // Link
        if ($settings['link_to'] !== 'none') {
            $link_url = ($settings['link_to'] === 'file') ? $settings['image']['url'] : $settings['link']['url'];

            $this->add_render_attribute('link', [
                'href' => esc_url($link_url),
                'data-elementor-open-lightbox' => 'no',
            ]);

            if ($settings['link']['is_external']) {
                $this->add_render_attribute('link', 'target', '_blank');
            }

            if ($settings['link']['nofollow']) {
                $this->add_render_attribute('link', 'rel', 'nofollow');
            }

            $image_html = '<a ' . $this->get_render_attribute_string('link') . '>' . $image_html . '</a>';
        }

        // Caption
        $caption = '';
        if ($has_caption) {
            $caption = $settings['caption_source'] === 'attachment' 
                ? wp_get_attachment_caption($settings['image']['id']) 
                : $settings['caption'];
        }

        // Hover animation
        $animation_class = !empty($settings['hover_animation']) ? 'elementor-animation-' . $settings['hover_animation'] : '';
        ?>
        <div class="yomooh-image-wrapper">
            <figure class="yomooh-image <?php echo esc_attr($animation_class); ?>">
                <?php echo $image_html; ?>
                <?php if ($has_caption && !empty($caption)) : ?>
                    <figcaption class="yomooh-image-caption"><?php echo esc_html($caption); ?></figcaption>
                <?php endif; ?>
            </figure>
        </div>
        <?php
    }
}