<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class Yomooh_Banner_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct(
            'yomooh_banner_widget',
            __('Yomooh Banner', 'yomooh-core'),
            array(
                'description' => __('A customizable banner with title, description, image, and button.', 'yomooh-core'),
                'customize_selective_refresh' => true,
            )
        );
    }

    public function widget($args, $instance) {
        $title = apply_filters('widget_title', empty($instance['title']) ? '' : $instance['title'], $instance, $this->id_base);
        $description = empty($instance['description']) ? '' : $instance['description'];
        $bg_image = empty($instance['bg_image']) ? '' : $instance['bg_image'];
        $button_label = empty($instance['button_label']) ? '' : $instance['button_label'];
        $button_url = empty($instance['button_url']) ? '' : $instance['button_url'];

        echo $args['before_widget'];

        // Inline styles for background image
        $style = $bg_image ? 'style="background-image: url(' . esc_url($bg_image) . ')"' : '';
        
        echo '<div class="yomooh-banner-widget" ' . $style . '>';
        echo '<div class="banner-overlay"></div>';
        echo '<div class="banner-content">';
        
        if ($title) {
            echo $args['before_title'] . esc_html($title) . $args['after_title'];
        }
        
        if ($description) {
            echo '<div class="banner-description">' . wp_kses_post(wpautop($description)) . '</div>';
        }
        
        if ($button_label && $button_url) {
            echo '<a href="' . esc_url($button_url) . '" class="banner-button">' . esc_html($button_label) . '</a>';
        }
        
        echo '</div>'; // .banner-content
        echo '</div>'; 
        
        echo $args['after_widget'];
    }

    public function form($instance) {
        $defaults = array(
            'title' => '',
            'description' => '',
            'bg_image' => '',
            'button_label' => '',
            'button_url' => ''
        );
        
        $instance = wp_parse_args((array) $instance, $defaults);
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:', 'yomooh-core'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" 
                   name="<?php echo $this->get_field_name('title'); ?>" 
                   type="text" value="<?php echo esc_attr($instance['title']); ?>" />
        </p>
        
        <p>
            <label for="<?php echo $this->get_field_id('description'); ?>"><?php _e('Description:', 'yomooh-core'); ?></label>
            <textarea class="widefat" rows="5" id="<?php echo $this->get_field_id('description'); ?>" 
                      name="<?php echo $this->get_field_name('description'); ?>"><?php echo esc_textarea($instance['description']); ?></textarea>
        </p>
        
        <p>
            <label for="<?php echo $this->get_field_id('bg_image'); ?>"><?php _e('Background Image URL:', 'yomooh-core'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('bg_image'); ?>" 
                   name="<?php echo $this->get_field_name('bg_image'); ?>" 
                   type="text" value="<?php echo esc_url($instance['bg_image']); ?>" />
           
        </p>
        
        <p>
            <label for="<?php echo $this->get_field_id('button_label'); ?>"><?php _e('Button Label:', 'yomooh-core'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('button_label'); ?>" 
                   name="<?php echo $this->get_field_name('button_label'); ?>" 
                   type="text" value="<?php echo esc_attr($instance['button_label']); ?>" />
        </p>
        
        <p>
            <label for="<?php echo $this->get_field_id('button_url'); ?>"><?php _e('Button URL:', 'yomooh-core'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('button_url'); ?>" 
                   name="<?php echo $this->get_field_name('button_url'); ?>" 
                   type="text" value="<?php echo esc_url($instance['button_url']); ?>" />
        </p>
        
        <?php
    }

    public function update($new_instance, $old_instance) {
        $instance = $old_instance;
        $instance['title'] = sanitize_text_field($new_instance['title']);
        $instance['description'] = wp_kses_post($new_instance['description']);
        $instance['bg_image'] = esc_url_raw($new_instance['bg_image']);
        $instance['button_label'] = sanitize_text_field($new_instance['button_label']);
        $instance['button_url'] = esc_url_raw($new_instance['button_url']);
        
        return $instance;
    }
}