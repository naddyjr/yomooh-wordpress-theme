<?php
namespace Yomooh\Backend\settings\Options;
use Redux;

use Yomooh\Backend\settings\AdminOptions;

class Typography extends AdminOptions
{
    protected $options;

    public function __construct($opt_name)
    {
        $this->opt_name = $opt_name;
        $this->options = $this->typography_fields();
        $this->set_widget_option();
    }

    protected function typography_fields()
    {
        $google_fonts = [
            'Roboto' => 'Roboto',
            'Open Sans' => 'Open Sans',
            'Poppins' => 'Poppins',
            'Montserrat' => 'Montserrat',
            'Lato' => 'Lato',
            'Nunito' => 'Nunito',
            'Playfair Display' => 'Playfair Display',
            'Merriweather' => 'Merriweather',
        ];

        return [
            [
                'id'       => 'typography_section_start',
                'type'     => 'section',
                'subtitle' => esc_html__('Configure global typography settings', 'yomooh-core'),
                'indent'   => true,
            ],
            [
                'id'       => 'enable_font_changes',
                'type'     => 'switch',
                'title'    => esc_html__('Enable Font Customization', 'yomooh-core'),
                'subtitle' => esc_html__('Allow changing fonts throughout the site', 'yomooh-core'),
                'default'  => false,
            ],
            [
                'id'       => 'body_typography',
                'type'     => 'typography',
                'title'    => esc_html__('Body Typography', 'yomooh-core'),
                'subtitle' => esc_html__('Main body text settings', 'yomooh-core'),
                'google'   => true,
                'font-style' => true,
                'font-weight' => true,
                'font-size' => true,
                'line-height' => true,
                'color' => false, // Color handled in GlobalColors
                'text-align' => false,
                'output'    => ['body'],
                'required' => ['enable_font_changes', '=', true],
            ],
            [
                'id'       => 'heading_typography',
                'type'     => 'typography',
                'title'    => esc_html__('Heading Typography', 'yomooh-core'),
                'subtitle' => esc_html__('Global heading settings (H1-H6)', 'yomooh-core'),
                'google'   => true,
                'font-style' => true,
                'font-weight' => true,
                'font-size' => false,
                'line-height' => false,
                'color' => false, // Color handled in GlobalColors
                'text-align' => false,
                'output'    => ['h1, h2, h3, h4, h5, h6'],
                'required' => ['enable_font_changes', '=', true],
            ],
            [
                'id'       => 'h1_typography',
                'type'     => 'typography',
                'title'    => esc_html__('H1 Typography', 'yomooh-core'),
                'subtitle' => esc_html__('H1 heading specific settings', 'yomooh-core'),
                'google'   => true,
                'font-style' => true,
                'font-weight' => true,
                'font-size' => true,
                'line-height' => true,
                'text-align' => true,
                'output'    => ['h1'],
                'required' => ['enable_font_changes', '=', true],
            ],
            [
                'id'       => 'h2_typography',
                'type'     => 'typography',
                'title'    => esc_html__('H2 Typography', 'yomooh-core'),
                'subtitle' => esc_html__('H2 heading specific settings', 'yomooh-core'),
                'google'   => true,
                'font-style' => true,
                'font-weight' => true,
                'font-size' => true,
                'line-height' => true,
                'text-align' => true,
                'output'    => ['h2'],
                'required' => ['enable_font_changes', '=', true],
            ],
            [
                'id'       => 'h3_typography',
                'type'     => 'typography',
                'title'    => esc_html__('H3 Typography', 'yomooh-core'),
                'subtitle' => esc_html__('H3 heading specific settings', 'yomooh-core'),
                'google'   => true,
                'font-style' => true,
                'font-weight' => true,
                'font-size' => true,
                'line-height' => true,
                'text-align' => true,
                'output'    => ['h3'],
                'required' => ['enable_font_changes', '=', true],
            ],
            [
                'id'       => 'menu_typography',
                'type'     => 'typography',
                'title'    => esc_html__('Menu Typography', 'yomooh-core'),
                'subtitle' => esc_html__('Navigation menu typography', 'yomooh-core'),
                'google'   => true,
                'font-style' => true,
                'font-weight' => true,
                'font-size' => true,
                'line-height' => true,
                'text-align' => false,
                'output'    => ['.main-navigation a'],
                'required' => ['enable_font_changes', '=', true],
            ],
            [
                'id'       => 'font_subsets',
                'type'     => 'checkbox',
                'title'    => esc_html__('Google Font Subsets', 'yomooh-core'),
                'subtitle' => esc_html__('Select subsets for Google Fonts', 'yomooh-core'),
                'options'  => [
                    'latin' => 'Latin',
                    'latin-ext' => 'Latin Extended',
                    'cyrillic' => 'Cyrillic',
                    'cyrillic-ext' => 'Cyrillic Extended',
                    'greek' => 'Greek',
                    'greek-ext' => 'Greek Extended',
                    'vietnamese' => 'Vietnamese',
                ],
                'default'  => [
                    'latin' => true,
                ],
                'required' => ['enable_font_changes', '=', true],
            ],
            [
                'id'       => 'custom_fonts',
                'type'     => 'multi_text',
                'title'    => esc_html__('Custom Fonts', 'yomooh-core'),
                'subtitle' => esc_html__('Add custom font families (name|font-weight|font-style)', 'yomooh-core'),
                'add_text' => 'Add Font',
                'default'  => [],
                'required' => ['enable_font_changes', '=', true],
            ],
            [
                'id'       => 'typography_section_end',
                'type'     => 'section',
                'indent'   => false,
            ],
            [
                'id'       => 'enable_color_changes',
                'type'     => 'switch',
                'title'    => esc_html__('Enable Font Customization', 'yomooh-core'),
                'subtitle' => esc_html__('Allow changing custom colors the site', 'yomooh-core'),
                'default'  => false,
            ],
			[
                'id'       => 'global_colors_section_start',
                'type'     => 'section',
                'title'    => esc_html__('Global Colors', 'yomooh-core'),
                'subtitle' => esc_html__('Configure global color scheme', 'yomooh-core'),
                'required' => ['enable_color_changes', '=', true],
                'indent'   => true,
            ],
            [
                'id'       => 'primary_color',
                'type'     => 'color',
                'title'    => esc_html__('Primary Color', 'yomooh-core'),
                'subtitle' => esc_html__('Main brand color (buttons, links)', 'yomooh-core'),
                'default'  => '#3a7bd5',
                'validate' => 'color',
                'output'   => [
                    'color' => 'a, .text-primary',
                    'background-color' => '.bg-primary, .btn-primary',
                    'border-color' => '.border-primary',
                ],
                'required' => ['enable_color_changes', '=', true],

            ],
            [
                'id'       => 'secondary_color',
                'type'     => 'color',
                'title'    => esc_html__('Secondary Color', 'yomooh-core'),
                'subtitle' => esc_html__('Secondary brand color', 'yomooh-core'),
                'default'  => '#00d2ff',
                'validate' => 'color',
                'output'   => [
                    'color' => '.text-secondary',
                    'background-color' => '.bg-secondary, .btn-secondary',
                    'border-color' => '.border-secondary',
                ],
               'required' => ['enable_color_changes', '=', true],

            ],
            [
                'id'       => 'body_text_color',
                'type'     => 'color',
                'title'    => esc_html__('Body Text Color', 'yomooh-core'),
                'subtitle' => esc_html__('Main text color for content', 'yomooh-core'),
                'default'  => '#333333',
                'validate' => 'color',
                'required' => ['enable_color_changes', '=', true],
                'output'   => [
                    'color' => 'body, .text-body',
                ],
            ],
            [
                'id'       => 'heading_color',
                'type'     => 'color',
                'title'    => esc_html__('Heading Color', 'yomooh-core'),
                'subtitle' => esc_html__('Color for all headings (H1-H6)', 'yomooh-core'),
                'default'  => '#222222',
                'validate' => 'color',
                'required' => ['enable_color_changes', '=', true],
                'output'   => [
                    'color' => 'h1, h2, h3, h4, h5, h6, .heading',
                ],
            ],
            [
                'id'       => 'success_color',
                'type'     => 'color',
                'title'    => esc_html__('Success Color', 'yomooh-core'),
                'subtitle' => esc_html__('Color for success messages', 'yomooh-core'),
                'default'  => '#28a745',
                'required' => ['enable_color_changes', '=', true],
                'validate' => 'color',
                'output'   => [
                    'color' => '.text-success',
                    'background-color' => '.bg-success, .btn-success',
                    'border-color' => '.border-success',
                ],
            ],
            [
                'id'       => 'error_color',
                'type'     => 'color',
                'title'    => esc_html__('Error Color', 'yomooh-core'),
                'subtitle' => esc_html__('Color for error messages', 'yomooh-core'),
                'default'  => '#dc3545',
                'required' => ['enable_color_changes', '=', true],
                'validate' => 'color',
                'output'   => [
                    'color' => '.text-error',
                    'background-color' => '.bg-error, .btn-error',
                    'border-color' => '.border-error',
                ],
            ],
            [
                'id'       => 'warning_color',
                'type'     => 'color',
                'title'    => esc_html__('Warning Color', 'yomooh-core'),
                'subtitle' => esc_html__('Color for warning messages', 'yomooh-core'),
                'default'  => '#ffc107',
                'required' => ['enable_color_changes', '=', true],
                'validate' => 'color',
                'output'   => [
                    'color' => '.text-warning',
                    'background-color' => '.bg-warning, .btn-warning',
                    'border-color' => '.border-warning',
                ],
            ],
            [
                'id'       => 'info_color',
                'type'     => 'color',
                'title'    => esc_html__('Info Color', 'yomooh-core'),
                'subtitle' => esc_html__('Color for informational messages', 'yomooh-core'),
                'default'  => '#17a2b8',
                'required' => ['enable_color_changes', '=', true],
                'validate' => 'color',
                'output'   => [
                    'color' => '.text-info',
                    'background-color' => '.bg-info, .btn-info',
                    'border-color' => '.border-info',
                ],
            ],
            [
                'id'       => 'light_color',
                'type'     => 'color',
                'title'    => esc_html__('Light Color', 'yomooh-core'),
                'subtitle' => esc_html__('Light background/text color', 'yomooh-core'),
                'default'  => '#f8f9fa',
                'required' => ['enable_color_changes', '=', true],
                'validate' => 'color',
                'output'   => [
                    'color' => '.text-light',
                    'background-color' => '.bg-light',
                    'border-color' => '.border-light',
                ],
            ],
            [
                'id'       => 'dark_color',
                'type'     => 'color',
                'title'    => esc_html__('Dark Color', 'yomooh-core'),
                'subtitle' => esc_html__('Dark background/text color', 'yomooh-core'),
                'default'  => '#343a40',
                'required' => ['enable_color_changes', '=', true],
                'validate' => 'color',
                'output'   => [
                    'color' => '.text-dark',
                    'background-color' => '.bg-dark',
                    'border-color' => '.border-dark',
                ],
            ],
            [
                'id'       => 'link_color',
                'type'     => 'color',
                'title'    => esc_html__('Link Color', 'yomooh-core'),
                'subtitle' => esc_html__('Color for regular links', 'yomooh-core'),
                'default'  => '#3a7bd5',
                'required' => ['enable_color_changes', '=', true],
                'validate' => 'color',
                'output'   => [
                    'color' => 'a',
                ],
            ],
            [
                'id'       => 'link_hover_color',
                'type'     => 'color',
                'title'    => esc_html__('Link Hover Color', 'yomooh-core'),
                'subtitle' => esc_html__('Color for hovered links', 'yomooh-core'),
                'default'  => '#2c5fb3',
                'required' => ['enable_color_changes', '=', true],
                'validate' => 'color',
                'output'   => [
                    'color' => 'a:hover, a:focus',
                ],
            ],
            [
                'id'       => 'border_color',
                'type'     => 'color',
                'required' => ['enable_color_changes', '=', true],
                'title'    => esc_html__('Border Color', 'yomooh-core'),
                'subtitle' => esc_html__('Default border color', 'yomooh-core'),
                'default'  => '#dee2e6',
                'validate' => 'color',
                'required' => ['enable_color_changes', '=', true],
                'output'   => [
                    'border-color' => '.border, input, textarea, select',
                ],
            ],
            [
                'id'       => 'global_colors_section_end',
                'type'     => 'section',
                'indent'   => false,
            ],
        ];
    }

    protected function set_widget_option()
    {
        \Redux::setSection($this->opt_name, [
            'title'            => esc_html__('Typography', 'yomooh-core'),
            'id'               => 'typography_settings',
            'icon'             => 'el el-font',
            'customizer_width' => '500px',
            'fields'           => $this->options,
        ]);
    }
}