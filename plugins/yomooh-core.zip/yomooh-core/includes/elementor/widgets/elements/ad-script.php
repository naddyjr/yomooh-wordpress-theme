<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;

if (!defined('ABSPATH')) exit;

class Yomooh_Widget_Ad_Script extends Widget_Base {

    public function get_name() {
        return 'yomooh_ad_script';
    }

    public function get_title() {
        return __('Yomooh Ad Script', 'yomooh-core');
    }

    public function get_icon() {
        return 'eicon-code';
    }

    public function get_categories() {
        return ['yomooh-elements'];
    }

    protected function register_controls() {
        // Content Tab
        $this->start_controls_section('content_section', [
            'label' => __('Ad Settings', 'yomooh-core'),
            'tab' => Controls_Manager::TAB_CONTENT,
        ]);

        $this->add_control('ad_description', [
            'label' => __('Description', 'yomooh-core'),
            'type' => Controls_Manager::TEXT,
            'default' => __('Advertisement', 'yomooh-core'),
            'placeholder' => __('Enter ad description', 'yomooh-core'),
        ]);

        $this->add_control('ad_code', [
            'label' => __('Ad Code', 'yomooh-core'),
            'type' => Controls_Manager::TEXTAREA,
            'description' => __('Paste your Google AdSense or other ad code here', 'yomooh-core'),
            'placeholder' => __('<script>...</script> or <ins>...</ins>', 'yomooh-core'),
        ]);

        $this->add_control('ad_size', [
            'label' => __('Ad Size', 'yomooh-core'),
            'type' => Controls_Manager::SELECT,
            'default' => 'banner',
            'options' => [
                'auto' => __('Auto', 'yomooh-core'),
                'banner' => __('Banner (728x90)', 'yomooh-core'),
                'half-banner' => __('Half Banner (468x60)', 'yomooh-core'),
                'leaderboard' => __('Leaderboard (970x90)', 'yomooh-core'),
                'medium-rectangle' => __('Medium Rectangle (300x250)', 'yomooh-core'),
                'large-rectangle' => __('Large Rectangle (336x280)', 'yomooh-core'),
                'skyscraper' => __('Skyscraper (120x600)', 'yomooh-core'),
                'wide-skyscraper' => __('Wide Skyscraper (160x600)', 'yomooh-core'),
                'responsive' => __('Responsive', 'yomooh-core'),
            ],
        ]);

        $this->add_control('hide_desktop', [
            'label' => __('Hide on Desktop', 'yomooh-core'),
            'type' => Controls_Manager::SWITCHER,
            'default' => '',
            'label_on' => __('Hide', 'yomooh-core'),
            'label_off' => __('Show', 'yomooh-core'),
            'return_value' => 'yes',
            'prefix_class' => 'yomooh-hide-desktop-',
        ]);

        $this->add_control('hide_tablet', [
            'label' => __('Hide on Tablet', 'yomooh-core'),
            'type' => Controls_Manager::SWITCHER,
            'default' => '',
            'label_on' => __('Hide', 'yomooh-core'),
            'label_off' => __('Show', 'yomooh-core'),
            'return_value' => 'yes',
            'prefix_class' => 'yomooh-hide-tablet-',
        ]);

        $this->add_control('hide_mobile', [
            'label' => __('Hide on Mobile', 'yomooh-core'),
            'type' => Controls_Manager::SWITCHER,
            'default' => '',
            'label_on' => __('Hide', 'yomooh-core'),
            'label_off' => __('Show', 'yomooh-core'),
            'return_value' => 'yes',
            'prefix_class' => 'yomooh-hide-mobile-',
        ]);

        $this->end_controls_section();

        // Style Tab
        $this->start_controls_section('style_section', [
            'label' => __('Style', 'yomooh-core'),
            'tab' => Controls_Manager::TAB_STYLE,
        ]);

        $this->add_control('description_color', [
            'label' => __('Description Color', 'yomooh-core'),
            'type' => Controls_Manager::COLOR,
            'default' => '#999999',
            'selectors' => [
                '{{WRAPPER}} .yomooh-ad-description' => 'color: {{VALUE}};',
            ],
        ]);

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'description_typography',
                'selector' => '{{WRAPPER}} .yomooh-ad-description',
            ]
        );

        $this->add_responsive_control('description_margin', [
            'label' => __('Description Margin', 'yomooh-core'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%', 'em'],
            'selectors' => [
                '{{WRAPPER}} .yomooh-ad-description' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->add_responsive_control('ad_padding', [
            'label' => __('Ad Container Padding', 'yomooh-core'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%', 'em'],
            'selectors' => [
                '{{WRAPPER}} .yomooh-ad-container' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'ad_border',
                'selector' => '{{WRAPPER}} .yomooh-ad-container',
            ]
        );

        $this->add_responsive_control('ad_border_radius', [
            'label' => __('Border Radius', 'yomooh-core'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%'],
            'selectors' => [
                '{{WRAPPER}} .yomooh-ad-container' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->add_control('ad_bg_color', [
            'label' => __('Background Color', 'yomooh-core'),
            'type' => Controls_Manager::COLOR,
            'default' => '#f5f5f5',
            'selectors' => [
                '{{WRAPPER}} .yomooh-ad-container' => 'background-color: {{VALUE}};',
            ],
        ]);

        $this->add_responsive_control('ad_alignment', [
            'label' => __('Alignment', 'yomooh-core'),
            'type' => Controls_Manager::CHOOSE,
            'options' => [
                'left' => [
                    'title' => __('Left', 'yomooh-core'),
                    'icon' => 'eicon-text-align-left',
                ],
                'center' => [
                    'title' => __('Center', 'yomooh-core'),
                    'icon' => 'eicon-text-align-center',
                ],
                'right' => [
                    'title' => __('Right', 'yomooh-core'),
                    'icon' => 'eicon-text-align-right',
                ],
            ],
            'default' => 'center',
            'selectors' => [
                '{{WRAPPER}} .yomooh-ad-container' => 'text-align: {{VALUE}};',
            ],
        ]);

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        if (empty($settings['ad_code'])) {
            return;
        }

        // Add size class
        $size_class = 'yomooh-ad-size-' . $settings['ad_size'];
        ?>
        <div class="yomooh-ad-container <?php echo esc_attr($size_class); ?>">
            <?php if ($settings['ad_description']) : ?>
                <div class="yomooh-ad-description"><?php echo esc_html($settings['ad_description']); ?></div>
            <?php endif; ?>
            
            <div class="yomooh-ad-code">
                <?php echo $settings['ad_code']; ?>
            </div>
        </div>
        <?php
    }
}