<?php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class Yomooh_Posts_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct(
            'yomooh_listing_posts',
            __('Yomooh Listing Posts', 'yomooh-core'),
            array(
                'description' => __('A customizable Listing posts widget with advanced options.', 'yomooh-core'),
                'customize_selective_refresh' => true,
            )
        );
    }

    public function widget($args, $instance) {
        $title = apply_filters('widget_title', empty($instance['title']) ? __('Recent Posts', 'yomooh-core') : $instance['title'], $instance, $this->id_base);
        $number = empty($instance['number']) ? 5 : absint($instance['number']);
        $orderby = empty($instance['orderby']) ? 'date' : $instance['orderby'];
        $category = empty($instance['category']) ? '' : $instance['category'];
        $tags = empty($instance['tags']) ? '' : $instance['tags'];
        $post_format = empty($instance['post_format']) ? '' : $instance['post_format'];
        $meta_tags = empty($instance['meta_tags']) ? array() : explode(',', str_replace(' ', '', $instance['meta_tags']));
        $featured_image_position = empty($instance['featured_image_position']) ? 'right' : $instance['featured_image_position'];
        $show_featured_image = !empty($instance['show_featured_image']);

        $query_args = array(
            'posts_per_page'      => $number,
            'no_found_rows'       => true,
            'post_status'         => 'publish',
            'ignore_sticky_posts' => true,
            'orderby'             => $orderby,
        );

        if (!empty($category)) {
            $query_args['category_name'] = $category;
        }

        if (!empty($tags)) {
            $query_args['tag'] = $tags;
        }

        if (!empty($post_format)) {
            $query_args['tax_query'] = array(
                array(
                    'taxonomy' => 'post_format',
                    'field'    => 'slug',
                    'terms'    => array('post-format-' . $post_format),
                ),
            );
        }

        $r = new WP_Query($query_args);

        if ($r->have_posts()) {
            echo $args['before_widget'];

            if ($title) {
                echo $args['before_title'] . $title . $args['after_title'];
            }

            echo '<ul class="Listing-recent-posts-list">';

            while ($r->have_posts()) {
                $r->the_post();
                $post_id = get_the_ID();
                $classes = 'Listing-recent-post';
                $classes .= $show_featured_image ? ' has-featured-image' : '';
                $classes .= ' featured-image-' . $featured_image_position;

                echo '<li class="' . esc_attr($classes) . '">';

                if ($show_featured_image && has_post_thumbnail()) {
                    echo '<div class="Listing-post-thumbnail">';
                    echo '<a href="' . esc_url(get_permalink()) . '">';
                    the_post_thumbnail('thumbnail');
                    echo '</a>';
                    echo '</div>';
                }

                echo '<div class="Listing-post-content">';
                echo '<h2 class="Listing-post-title"><a href="' . esc_url(get_permalink()) . '">' . get_the_title() . '</a></h2>';

                if (!empty($meta_tags)) {
                    echo '<div class="Listing-post-meta">';
                    foreach ($meta_tags as $tag) {
                        switch (trim($tag)) {
                            case 'avatar':
                                echo '<span class="meta-avatar">' . get_avatar(get_the_author_meta('ID'), 32) . '</span>';
                                break;
                            case 'author':
                                echo '<span class="meta-author"><span class="by">' . __('By', 'yomooh-core') . '</span> ' . get_the_author() . '</span>';
                                break;
                            case 'date':
                                echo '<span class="meta-date">' . get_the_date() . '</span>';
                                break;
                            case 'category':
                                $categories = get_the_category();
                                if (!empty($categories)) {
                                    echo '<span class="meta-category">';
                                    the_category(', ');
                                    echo '</span>';
                                }
                                break;
                            case 'tag':
                                $tags_list = get_the_tag_list('', ', ');
                                if ($tags_list) {
                                    echo '<span class="meta-tags">' . $tags_list . '</span>';
                                }
                                break;
                            case 'view':
                                if (function_exists('the_views')) {
                                    echo '<span class="meta-views">' . the_views(false) . '</span>';
                                }
                                break;
                            case 'comment':
                                if (comments_open()) {
                                    echo '<span class="meta-comment">';
                                    comments_number(__('No comments', 'yomooh-core'), __('1 comment', 'yomooh-core'), __('% comments', 'yomooh-core'));
                                    echo '</span>';
                                }
                                break;
                            case 'update':
                                if (get_the_time('U') !== get_the_modified_time('U')) {
                                    echo '<span class="meta-updated">' . sprintf(__('Updated on %s', 'yomooh-core'), get_the_modified_date()) . '</span>';
                                }
                                break;
                        }
                    }
                    echo '</div>'; // .Listing-post-meta
                }

                echo '</div>'; // .Listing-post-content
                echo '</li>';
            }

            echo '</ul>';
            echo $args['after_widget'];

            wp_reset_postdata();
        }
    }

    public function form($instance) {
        $defaults = array(
            'title' => __('Recent Posts', 'yomooh-core'),
            'number' => 5,
            'orderby' => 'date',
            'category' => '',
            'tags' => '',
            'post_format' => '',
            'meta_tags' => 'author,date,comment',
            'show_featured_image' => true,
            'featured_image_position' => 'right',
        );

        $instance = wp_parse_args((array) $instance, $defaults);
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:', 'yomooh-core'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($instance['title']); ?>" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('number'); ?>"><?php _e('Number of posts to show:', 'yomooh-core'); ?></label>
            <input class="tiny-text" id="<?php echo $this->get_field_id('number'); ?>" name="<?php echo $this->get_field_name('number'); ?>" type="number" step="1" min="1" value="<?php echo absint($instance['number']); ?>" size="3" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('orderby'); ?>"><?php _e('Order by:', 'yomooh-core'); ?></label>
            <select class="widefat" id="<?php echo $this->get_field_id('orderby'); ?>" name="<?php echo $this->get_field_name('orderby'); ?>">
                <option value="date" <?php selected($instance['orderby'], 'date'); ?>><?php _e('Date', 'yomooh-core'); ?></option>
                <option value="rand" <?php selected($instance['orderby'], 'rand'); ?>><?php _e('Random', 'yomooh-core'); ?></option>
                <option value="comment_count" <?php selected($instance['orderby'], 'comment_count'); ?>><?php _e('Comments', 'yomooh-core'); ?></option>
                <option value="modified" <?php selected($instance['orderby'], 'modified'); ?>><?php _e('Modified', 'yomooh-core'); ?></option>
            </select>
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('category'); ?>"><?php _e('Category (slug):', 'yomooh-core'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('category'); ?>" name="<?php echo $this->get_field_name('category'); ?>" type="text" value="<?php echo esc_attr($instance['category']); ?>" placeholder="<?php _e('e.g. news, blog', 'yomooh-core'); ?>" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('tags'); ?>"><?php _e('Tags (slug):', 'yomooh-core'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('tags'); ?>" name="<?php echo $this->get_field_name('tags'); ?>" type="text" value="<?php echo esc_attr($instance['tags']); ?>" placeholder="<?php _e('e.g. featured, popular', 'yomooh-core'); ?>" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('post_format'); ?>"><?php _e('Post Format:', 'yomooh-core'); ?></label>
            <select class="widefat" id="<?php echo $this->get_field_id('post_format'); ?>" name="<?php echo $this->get_field_name('post_format'); ?>">
                <option value=""><?php _e('All Formats', 'yomooh-core'); ?></option>
                <option value="aside" <?php selected($instance['post_format'], 'aside'); ?>><?php _e('Aside', 'yomooh-core'); ?></option>
                <option value="gallery" <?php selected($instance['post_format'], 'gallery'); ?>><?php _e('Gallery', 'yomooh-core'); ?></option>
                <option value="link" <?php selected($instance['post_format'], 'link'); ?>><?php _e('Link', 'yomooh-core'); ?></option>
                <option value="image" <?php selected($instance['post_format'], 'image'); ?>><?php _e('Image', 'yomooh-core'); ?></option>
                <option value="quote" <?php selected($instance['post_format'], 'quote'); ?>><?php _e('Quote', 'yomooh-core'); ?></option>
                <option value="status" <?php selected($instance['post_format'], 'status'); ?>><?php _e('Status', 'yomooh-core'); ?></option>
                <option value="video" <?php selected($instance['post_format'], 'video'); ?>><?php _e('Video', 'yomooh-core'); ?></option>
                <option value="audio" <?php selected($instance['post_format'], 'audio'); ?>><?php _e('Audio', 'yomooh-core'); ?></option>
                <option value="chat" <?php selected($instance['post_format'], 'chat'); ?>><?php _e('Chat', 'yomooh-core'); ?></option>
            </select>
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('meta_tags'); ?>"><?php _e('Entry Meta Tags: avatar,author,date, category,tag,view,comment,update', 'yomooh-core'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('meta_tags'); ?>" name="<?php echo $this->get_field_name('meta_tags'); ?>" type="text" value="<?php echo esc_attr($instance['meta_tags']); ?>" placeholder="<?php _e('e.g. avatar,author,date,category,tag,view,comment,update', 'yomooh-core'); ?>" />
            <small><?php _e('Separate by comma', 'yomooh-core'); ?></small>
        </p>

        <p>
            <input class="checkbox" type="checkbox" id="<?php echo $this->get_field_id('show_featured_image'); ?>" name="<?php echo $this->get_field_name('show_featured_image'); ?>" <?php checked($instance['show_featured_image'], true); ?> />
            <label for="<?php echo $this->get_field_id('show_featured_image'); ?>"><?php _e('Show featured image', 'yomooh-core'); ?></label>
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('featured_image_position'); ?>"><?php _e('Featured Image Position:', 'yomooh-core'); ?></label>
            <select class="widefat" id="<?php echo $this->get_field_id('featured_image_position'); ?>" name="<?php echo $this->get_field_name('featured_image_position'); ?>">
                <option value="left" <?php selected($instance['featured_image_position'], 'left'); ?>><?php _e('Left', 'yomooh-core'); ?></option>
                <option value="right" <?php selected($instance['featured_image_position'], 'right'); ?>><?php _e('Right', 'yomooh-core'); ?></option>
            </select>
        </p>
        <?php
    }

    public function update($new_instance, $old_instance) {
        $instance = $old_instance;
        $instance['title'] = sanitize_text_field($new_instance['title']);
        $instance['number'] = absint($new_instance['number']);
        $instance['orderby'] = sanitize_text_field($new_instance['orderby']);
        $instance['category'] = sanitize_text_field($new_instance['category']);
        $instance['tags'] = sanitize_text_field($new_instance['tags']);
        $instance['post_format'] = sanitize_text_field($new_instance['post_format']);
        $instance['meta_tags'] = sanitize_text_field($new_instance['meta_tags']);
        $instance['show_featured_image'] = isset($new_instance['show_featured_image']) ? (bool) $new_instance['show_featured_image'] : false;
        $instance['featured_image_position'] = sanitize_text_field($new_instance['featured_image_position']);

        return $instance;
    }
}
