<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;

if (!defined('ABSPATH')) exit;

class Yomooh_Widget_Banner extends Widget_Base {

    public function get_name() {
        return 'yomooh_banner';
    }

    public function get_title() {
        return __('Yomooh Banner', 'yomooh-core');
    }

    public function get_icon() {
        return 'eicon-banner';
    }

    public function get_categories() {
        return ['yomooh-elements'];
    }

    protected function register_controls() {
        // Content Tab
        $this->start_controls_section('content_section', [
            'label' => __('Content', 'yomooh-core'),
            'tab' => Controls_Manager::TAB_CONTENT,
        ]);

        $this->add_control('title', [
            'label' => __('Title', 'yomooh-core'),
            'type' => Controls_Manager::TEXT,
            'default' => __('Banner Title', 'yomooh-core'),
            'placeholder' => __('Enter banner title', 'yomooh-core'),
            'label_block' => true,
        ]);

        $this->add_control('description', [
            'label' => __('Description', 'yomooh-core'),
            'type' => Controls_Manager::TEXTAREA,
            'default' => __('This is a banner description. You can add your text here.', 'yomooh-core'),
            'placeholder' => __('Enter banner description', 'yomooh-core'),
        ]);

        $this->add_control('button_label', [
            'label' => __('Button Label', 'yomooh-core'),
            'type' => Controls_Manager::TEXT,
            'default' => __('Click Here', 'yomooh-core'),
            'placeholder' => __('Enter button text', 'yomooh-core'),
        ]);

        $this->add_control('button_link', [
            'label' => __('Button Link', 'yomooh-core'),
            'type' => Controls_Manager::URL,
            'placeholder' => __('https://your-link.com', 'yomooh-core'),
            'default' => [
                'url' => '#',
            ],
        ]);

        $this->end_controls_section();

        // Style Tab - Banner
        $this->start_controls_section('style_banner_section', [
            'label' => __('Banner', 'yomooh-core'),
            'tab' => Controls_Manager::TAB_STYLE,
        ]);

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'background',
                'label' => __('Background', 'yomooh-core'),
                'types' => ['classic', 'gradient'],
                'selector' => '{{WRAPPER}} .yomooh-banner',
            ]
        );

        $this->add_responsive_control('banner_padding', [
            'label' => __('Padding', 'yomooh-core'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%', 'em'],
            'selectors' => [
                '{{WRAPPER}} .yomooh-banner-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->add_responsive_control('banner_border_radius', [
            'label' => __('Border Radius', 'yomooh-core'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%'],
            'selectors' => [
                '{{WRAPPER}} .yomooh-banner' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'banner_border',
                'selector' => '{{WRAPPER}} .yomooh-banner',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'banner_box_shadow',
                'selector' => '{{WRAPPER}} .yomooh-banner',
            ]
        );

        $this->end_controls_section();

        // Style Tab - Title
        $this->start_controls_section('style_title_section', [
            'label' => __('Title', 'yomooh-core'),
            'tab' => Controls_Manager::TAB_STYLE,
        ]);

        $this->add_control('title_color', [
            'label' => __('Color', 'yomooh-core'),
            'type' => Controls_Manager::COLOR,
            'default' => '#ffffff',
            'selectors' => [
                '{{WRAPPER}} .yomooh-banner-title' => 'color: {{VALUE}};',
            ],
        ]);

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .yomooh-banner-title',
            ]
        );

        $this->add_responsive_control('title_margin', [
            'label' => __('Margin', 'yomooh-core'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%', 'em'],
            'selectors' => [
                '{{WRAPPER}} .yomooh-banner-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->end_controls_section();

        // Style Tab - Description
        $this->start_controls_section('style_description_section', [
            'label' => __('Description', 'yomooh-core'),
            'tab' => Controls_Manager::TAB_STYLE,
        ]);

        $this->add_control('description_color', [
            'label' => __('Color', 'yomooh-core'),
            'type' => Controls_Manager::COLOR,
            'default' => '#f5f5f5',
            'selectors' => [
                '{{WRAPPER}} .yomooh-banner-description' => 'color: {{VALUE}};',
            ],
        ]);

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'description_typography',
                'selector' => '{{WRAPPER}} .yomooh-banner-description',
            ]
        );

        $this->add_responsive_control('description_margin', [
            'label' => __('Margin', 'yomooh-core'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%', 'em'],
            'selectors' => [
                '{{WRAPPER}} .yomooh-banner-description' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->end_controls_section();

        // Style Tab - Button
        $this->start_controls_section('style_button_section', [
            'label' => __('Button', 'yomooh-core'),
            'tab' => Controls_Manager::TAB_STYLE,
        ]);

        $this->add_responsive_control('button_width', [
            'label' => __('Width', 'yomooh-core'),
            'type' => Controls_Manager::SLIDER,
            'size_units' => ['px', '%'],
            'range' => [
                'px' => ['min' => 50, 'max' => 500],
                '%' => ['min' => 5, 'max' => 100],
            ],
            'default' => ['unit' => 'px', 'size' => 150],
            'selectors' => [
                '{{WRAPPER}} .yomooh-banner-button' => 'width: {{SIZE}}{{UNIT}};',
            ],
        ]);

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'button_typography',
                'selector' => '{{WRAPPER}} .yomooh-banner-button',
            ]
        );

        $this->add_responsive_control('button_padding', [
            'label' => __('Padding', 'yomooh-core'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%', 'em'],
            'selectors' => [
                '{{WRAPPER}} .yomooh-banner-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->add_responsive_control('button_border_radius', [
            'label' => __('Border Radius', 'yomooh-core'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%'],
            'selectors' => [
                '{{WRAPPER}} .yomooh-banner-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        $this->add_responsive_control('button_margin', [
            'label' => __('Margin', 'yomooh-core'),
            'type' => Controls_Manager::DIMENSIONS,
            'size_units' => ['px', '%', 'em'],
            'selectors' => [
                '{{WRAPPER}} .yomooh-banner-button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
            ],
        ]);

        // Normal State
        $this->start_controls_tab('button_normal', [
            'label' => __('Normal', 'yomooh-core'),
        ]);

        $this->add_control('button_text_color', [
            'label' => __('Text Color', 'yomooh-core'),
            'type' => Controls_Manager::COLOR,
            'default' => '#ffffff',
            'selectors' => [
                '{{WRAPPER}} .yomooh-banner-button' => 'color: {{VALUE}};',
            ],
        ]);

        $this->add_control('button_bg_color', [
            'label' => __('Background Color', 'yomooh-core'),
            'type' => Controls_Manager::COLOR,
            'default' => '#3a7bd5',
            'selectors' => [
                '{{WRAPPER}} .yomooh-banner-button' => 'background-color: {{VALUE}};',
            ],
        ]);

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'button_border',
                'selector' => '{{WRAPPER}} .yomooh-banner-button',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_box_shadow',
                'selector' => '{{WRAPPER}} .yomooh-banner-button',
            ]
        );

        $this->end_controls_tab();

        // Hover State
        $this->start_controls_tab('button_hover', [
            'label' => __('Hover', 'yomooh-core'),
        ]);

        $this->add_control('button_text_color_hover', [
            'label' => __('Text Color', 'yomooh-core'),
            'type' => Controls_Manager::COLOR,
            'default' => '#ffffff',
            'selectors' => [
                '{{WRAPPER}} .yomooh-banner-button:hover' => 'color: {{VALUE}};',
            ],
        ]);

        $this->add_control('button_bg_color_hover', [
            'label' => __('Background Color', 'yomooh-core'),
            'type' => Controls_Manager::COLOR,
            'default' => '#2c5fb3',
            'selectors' => [
                '{{WRAPPER}} .yomooh-banner-button:hover' => 'background-color: {{VALUE}};',
            ],
        ]);

        $this->add_control('button_border_color_hover', [
            'label' => __('Border Color', 'yomooh-core'),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .yomooh-banner-button:hover' => 'border-color: {{VALUE}};',
            ],
        ]);

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_box_shadow_hover',
                'selector' => '{{WRAPPER}} .yomooh-banner-button:hover',
            ]
        );

        $this->add_control('button_hover_animation', [
            'label' => __('Hover Animation', 'yomooh-core'),
            'type' => Controls_Manager::HOVER_ANIMATION,
        ]);

        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        $this->add_render_attribute('button', 'class', [
            'yomooh-banner-button',
            'elementor-button',
            'elementor-size-md',
            !empty($settings['button_hover_animation']) ? 'elementor-animation-' . $settings['button_hover_animation'] : '',
        ]);

        if (!empty($settings['button_link']['url'])) {
            $this->add_render_attribute('button', 'href', $settings['button_link']['url']);

            if ($settings['button_link']['is_external']) {
                $this->add_render_attribute('button', 'target', '_blank');
            }

            if ($settings['button_link']['nofollow']) {
                $this->add_render_attribute('button', 'rel', 'nofollow');
            }
        }
        ?>
        <div class="yomooh-banner">
            <div class="yomooh-banner-content">
                <?php if ($settings['title']) : ?>
                    <h3 class="yomooh-banner-title"><?php echo esc_html($settings['title']); ?></h3>
                <?php endif; ?>
                
                <?php if ($settings['description']) : ?>
                    <div class="yomooh-banner-description"><?php echo wp_kses_post($settings['description']); ?></div>
                <?php endif; ?>
                
                <?php if ($settings['button_label']) : ?>
                    <a <?php echo $this->get_render_attribute_string('button'); ?>>
                        <?php echo esc_html($settings['button_label']); ?>
                    </a>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }
}